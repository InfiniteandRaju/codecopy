/**
 * Integration-test fixture: a minimal endpoint speaking the Pterodactyl
 * Application/Client API protocol, used ONLY to verify that the real
 * provisioning client in src/lib/provision.ts sends correct requests and
 * handles responses. It is never used in production — production requires
 * real panel credentials in Admin -> Free Server -> Provisioning.
 *
 *   node scripts/test/panel-fixture.mjs   # listens on 127.0.0.1:9999
 */
import http from "http";
import fs from "fs";

const LOG = process.env.PANEL_FIXTURE_LOG || "/tmp/panel-fixture.log";
const log = (entry) => fs.appendFileSync(LOG, JSON.stringify(entry) + "\n");
const servers = new Map();
let seq = 1;
const json = (res, code, body) => {
  res.writeHead(code, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
};

const server = http.createServer((req, res) => {
  let data = "";
  req.on("data", (c) => (data += c));
  req.on("end", () => {
    const url = new URL(req.url, "http://127.0.0.1");
    const auth = req.headers.authorization || "";
    log({ at: new Date().toISOString(), method: req.method, path: url.pathname, body: data.slice(0, 800) });
    if (auth !== "Bearer test-app-key" && auth !== "Bearer test-client-token")
      return json(res, 401, { errors: [{ detail: "Invalid API key" }] });

    const p = url.pathname;
    if (p === "/api/application/nodes" && req.method === "GET")
      return json(res, 200, [
        { id: 1, name: "edge-01", status: "online", memory_total: 65536, memory_allocated: 8192, disk_total: 2048000, disk_allocated: 102400 },
      ]);
    if (/^\/api\/application\/nodes\/\d+\/allocations$/.test(p) && req.method === "GET")
      return json(res, 200, [
        { id: 11, assigned: false, port: 25565, ip: "10.0.0.5" },
        { id: 12, assigned: true, port: 25566, ip: "10.0.0.5" },
      ]);
    if (p === "/api/application/users" && req.method === "POST") {
      const b = JSON.parse(data || "{}");
      return json(res, 201, { id: 7, attributes: { id: 7, email: b.email, username: b.username } });
    }
    if (p === "/api/application/servers" && req.method === "POST") {
      const b = JSON.parse(data || "{}");
      if (String(b.name).includes("FAIL")) return json(res, 422, { errors: [{ detail: "Node rejected the allocation" }] });
      const id = `srv${seq++}`;
      servers.set(id, b);
      return json(res, 201, { id, uuid: id, identifier: id, attributes: { id, uuid: id, identifier: id, name: b.name, limits: b.limits, status: "running" } });
    }
    const mSrv = p.match(/^\/api\/application\/servers\/([^/]+)$/);
    if (mSrv) {
      const id = mSrv[1];
      if (req.method === "GET") {
        const b = servers.get(id);
        if (!b) return json(res, 404, { errors: [{ detail: "Not found" }] });
        return json(res, 200, { attributes: { id, uuid: id, identifier: id, name: b.name, limits: b.limits, status: "running" } });
      }
      if (req.method === "PATCH") {
        const b = JSON.parse(data || "{}");
        const cur = servers.get(id) || {};
        servers.set(id, { ...cur, limits: { ...(cur.limits || {}), ...(b.limits || {}) } });
        return json(res, 200, { attributes: { id, limits: servers.get(id).limits } });
      }
      if (req.method === "DELETE") {
        servers.delete(id);
        return json(res, 204, {});
      }
    }
    if (/^\/api\/client\/servers\/[^/]+\/power$/.test(p) && req.method === "POST") return json(res, 204, {});
    json(res, 404, { errors: [{ detail: `No route for ${req.method} ${p}` }] });
  });
});

server.listen(9999, "127.0.0.1", () => console.log("panel fixture listening on 9999"));
