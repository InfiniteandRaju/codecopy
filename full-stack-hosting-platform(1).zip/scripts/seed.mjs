/* Seed script — run with: node scripts/seed.mjs */
import { Pool } from "pg";
import { randomBytes, scryptSync } from "crypto";
import { config } from "dotenv";

config();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const q = (text, params) => pool.query(text, params);


function hash(password) {
  const salt = randomBytes(16).toString("hex");
  return `scrypt$${salt}$${scryptSync(password, salt, 64).toString("hex")}`;
}
const now = () => new Date();

async function ins(table, obj) {
  const keys = Object.keys(obj);
  const cols = keys.map((k) => `"${k}"`).join(", ");
  const ph = keys.map((_, i) => `$${i + 1}`).join(", ");
  const res = await q(
    `INSERT INTO "${table}" (${cols}) VALUES (${ph}) ON CONFLICT DO NOTHING RETURNING *`,
    keys.map((k) => obj[k]),
  );
  return res.rows[0] ?? (await q(`SELECT * FROM "${table}" WHERE "${keys[0]}" = $1`, [obj[keys[0]]])).rows[0];
}

/** Idempotent demo accounts — never resets an account that already exists. */
const ensureDemoAccounts = async () => {
  if (process.env.SEED_DEMO_ACCOUNTS === "false") return;
  const defs = [
    { name: "Theme Administrator", email: "admin@theme.com", password: "Admin@1234", role: "super_admin" },
    { name: "Rohan", email: "rohan@theme.com", password: "Rohan@1234", role: "customer" },
  ];
  for (const d of defs) {
    const existing = await q("SELECT id FROM users WHERE email = $1", [d.email]);
    if (existing.rows.length) continue; // do not recreate or reset existing accounts
    const inserted = await q(
      `INSERT INTO users (name, email, password_hash, role, status, must_change_password)
       VALUES ($1, $2, $3, $4, 'active', true) RETURNING id`,
      [d.name, d.email, hash(d.password), d.role],
    );
    await q("INSERT INTO wallet_accounts (user_id, balance) VALUES ($1, '0') ON CONFLICT DO NOTHING", [
      inserted.rows[0].id,
    ]);
    console.log(`Seeded ${d.role} account ${d.email} (password must be changed on first login)`);
  }
};

/** Server locations latency is measured against real endpoints — seeded without endpoints on purpose. */
const ensureLocations = async () => {
  const defs = [
    ["Mumbai", "Mumbai", "India", "BOM1", "Core", 1],
    ["Singapore", "Singapore", "Singapore", "SIN2", "Core", 2],
    ["Frankfurt", "Frankfurt", "Germany", "FRA3", "Core", 3],
    ["Ashburn", "Ashburn", "United States", "IAD1", "Edge", 4],
    ["London", "London", "United Kingdom", "LHR2", "Edge", 5],
    ["Tokyo", "Tokyo", "Japan", "NRT1", "Edge", 6],
  ];
  for (const [name, city, country, code, tier, order] of defs) {
    await q(
      `INSERT INTO server_locations (name, city, country, code, tier, endpoint, sort_order, active)
       VALUES ($1, $2, $3, $4, $5, NULL, $6, true)
       ON CONFLICT DO NOTHING`,
      [name, city, country, code, tier, order],
    );
  }
};

const run = async () => {
  await ensureDemoAccounts();
  await ensureLocations();

  const { rows: existing } = await q('SELECT count(*)::int AS c FROM "categories"');
  if (existing[0].c > 0) {
    console.log("Seed skipped: categories already present.");
    process.exit(0);
  }

  /* ------------------------------ users ------------------------------ */
  const admin = await ins("users", {
    name: "Aarav Mehta",
    email: "admin@obsidiannode.io",
    password_hash: hash("Admin@1234"),
    role: "super_admin",
  });
  const finance = await ins("users", {
    name: "Neha Rao",
    email: "finance@obsidiannode.io",
    password_hash: hash("Finance@1234"),
    role: "finance_manager",
  });
  const customers = [];
  const names = [
    ["Rohan Das", "rohan@playforge.gg"],
    ["Ishita Kapoor", "ishita@vellum.dev"],
    ["Kabir Nair", "kabir@nightjar.io"],
    ["Meera Iyer", "meera@lumenlabs.co"],
    ["Dev Sharma", "dev@arcadeloop.in"],
    ["Sana Qureshi", "sana@pixelforge.dev"],
  ];
  for (const [name, email] of names) {
    customers.push(
      await ins("users", { name, email, password_hash: hash("Customer@1234"), role: "customer" }),
    );
  }

  /* ---------------------------- categories --------------------------- */
  const cat = async (name, slug, parent, icon, desc, order) =>
    ins("categories", {
      name,
      slug,
      parent_id: parent ?? null,
      icon,
      description: desc,
      sort_order: order,
      active: true,
      seo_title: `${name} — Obsidian Node`,
      seo_description: desc,
    });

  const game = await cat("Game Hosting", "game-hosting", null, "gamepad-2", "High-clock Ryzen game servers with one-click modpacks and always-on DDoS filtering.", 1);
  const minecraft = await cat("Minecraft Hosting", "minecraft-hosting", game.id, "blocks", "Java and Bedrock servers on 5.7 GHz Ryzen silicon with automatic world backups.", 1);
  const mcJava = await cat("Java Edition", "minecraft-java", minecraft.id, "coffee", "Paper, Purpur, Fabric and vanilla Java servers.", 1);
  const mcBedrock = await cat("Bedrock Edition", "minecraft-bedrock", minecraft.id, "box", "Bedrock Dedicated Server with cross-play support.", 2);
  const mcModded = await cat("Modded Minecraft", "minecraft-modded", minecraft.id, "package", "Forge and NeoForge modpacks pre-installed, ATLauncher and CurseForge sync.", 3);
  const rust = await cat("Rust Hosting", "rust-hosting", game.id, "shield", "Oxide/uMod Rust servers with 32 GB RAM nodes and wide map support.", 2);
  await cat("FiveM Hosting", "fivm-hosting", game.id, "car", "FXServer instances with txAdmin, built for roleplay communities.", 3);
  await cat("ARK Hosting", "ark-hosting", game.id, "dinosaur" in {} ? "dino" : "leaf", "ARK: Survival Ascended and Evolved clusters with cross-server transfers.", 4);
  await cat("Terraria Hosting", "terraria-hosting", game.id, "mountain", "Terraria and tModLoader servers with automatic world saves.", 5);

  const bots = await cat("Bot Hosting", "bot-hosting", null, "bot", "Always-on runtimes for Discord, Telegram and custom bots.", 2);
  await cat("Discord Bot Hosting", "discord-bot-hosting", bots.id, "message-circle", "Node.js, Python and Java bots with 24/7 uptime monitoring.", 1);
  await cat("Telegram Bot Hosting", "telegram-bot-hosting", bots.id, "send", "Long-polling and webhook bot deployments with managed TLS.", 2);
  await cat("Node.js Bot Hosting", "node-bot-hosting", bots.id, "hexagon", "PM2-managed Node runtimes with dedicated process limits.", 3);
  await cat("Python Bot Hosting", "python-bot-hosting", bots.id, "terminal", "Python 3.12 runtimes with virtualenv isolation.", 4);

  const web = await cat("Web Hosting", "web-hosting", null, "globe", "cPanel-grade shared and managed WordPress hosting on LiteSpeed.", 3);
  await cat("Shared Hosting", "shared-hosting", web.id, "layers", "Entry-level hosting for portfolios, docs and small sites.", 1);
  await cat("Premium Web Hosting", "premium-web-hosting", web.id, "sparkles", "Isolated accounts, unmetered bandwidth and priority CPU shares.", 2);
  await cat("WordPress Hosting", "wordpress-hosting", web.id, "layout", "Managed WordPress with staging, caching and hardening.", 3);

  const vps = await cat("VPS Hosting", "vps-hosting", null, "server", "KVM virtual private servers on NVMe with root access in 45 seconds.", 4);
  await cat("Linux VPS", "linux-vps", vps.id, "terminal", "Ubuntu, Debian, AlmaLinux and Rocky images.", 1);
  await cat("Windows VPS", "windows-vps", vps.id, "monitor", "Licensed Windows Server with RDP and GPU passthrough options.", 2);
  await cat("High Performance VPS", "high-performance-vps", vps.id, "gauge", "Dedicated vCPU allocations on EPYC 9004 silicon.", 3);

  const dedi = await cat("Dedicated Servers", "dedicated-servers", null, "rack", "Single-tenant bare metal, remote hands included.", 5);
  await cat("Database Hosting", "database-hosting", null, "database", "Managed PostgreSQL, MySQL and Redis with daily snapshots.", 6);
  await cat("Cloud Hosting", "cloud-hosting", null, "cloud", "Elastic clusters with autoscaling node groups and load balancers.", 7);

  /* -------------------------------- tags ------------------------------ */
  const tagRows = {};
  const tagDefs = [
    ["Best Seller", "#FF6B18", true],
    ["Most Popular", "#39D7E6", true],
    ["Budget Friendly", "#3DDC84", true],
    ["Premium", "#F5B942", true],
    ["High Performance", "#FF4D6D", true],
    ["Ryzen", "#7C9BFF", false],
    ["AMD EPYC", "#B07CFF", false],
    ["DDoS Protected", "#39D7E6", true],
    ["NVMe", "#8A94A8", false],
    ["Instant Setup", "#3DDC84", true],
    ["Limited Offer", "#FF6B18", true],
  ];
  for (let i = 0; i < tagDefs.length; i++) {
    const [name, color, show] = tagDefs[i];
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    tagRows[slug] = await ins("tags", { name, slug, color, show_on_cards: show, sort_order: i, active: true });
  }

  /* ------------------------------- plans ------------------------------ */
  const plans = [
    {
      name: "Minecraft Java Starter",
      slug: "minecraft-java-starter",
      cat: mcJava.id,
      short: "Vanilla & Paper servers for small communities up to 40 players.",
      desc: "A right-sized entry point for survival servers. Runs Paper or Purpur on a 5.7 GHz Ryzen 9 core with NVMe world storage, automatic daily backups and a one-click switcher for server jars.",
      specs: [["RAM", "4 GB DDR5"], ["CPU", "2 × Ryzen 9 7950X @ 5.7 GHz"], ["Storage", "40 GB NVMe"], ["Player slots", "Unlimited"], ["Backups", "Daily, 7 days"], ["Panel", "Pterodactyl"]],
      features: ["One-click Paper / Purpur / Fabric install", "Automatic world backups", "Free subdomain play.yourname.gg", "Mod & plugin upload via SFTP", "DDoS protection included"],
      locations: ["Mumbai", "Singapore", "Frankfurt"],
      cycles: [["monthly", "Monthly", 1, 249, 349], ["quarterly", "Quarterly", 3, 699, 1047], ["annual", "Annual", 12, 2299, 4188]],
      tags: ["budget-friendly", "instant-setup", "ddos-protected"],
      price: [249, 349],
      featured: true,
      popular: true,
    },
    {
      name: "Minecraft Java Pro",
      slug: "minecraft-java-pro",
      cat: mcJava.id,
      short: "Modpack-ready flagship node for 200+ player networks.",
      desc: "Our best-selling game node. Dedicated Ryzen 9 threads, 8 GB of DDR5 and Gen4 NVMe keep TPS pinned at 20 even under heavy entity load. Includes proxy support, MySQL and priority support routing.",
      specs: [["RAM", "8 GB DDR5"], ["CPU", "4 × Ryzen 9 7950X @ 5.7 GHz"], ["Storage", "80 GB NVMe"], ["Network", "1 Gbit unmetered"], ["Backups", "Every 6h, 14 days"], ["Panel", "Pterodactyl"]],
      features: ["Dedicated vCPU threads — no oversell", "BungeeCord / Velocity proxy ready", "Included MySQL database", "Priority 15-minute support", "Free migration from any host"],
      locations: ["Mumbai", "Singapore", "Frankfurt", "Ashburn"],
      cycles: [["monthly", "Monthly", 1, 749, 999], ["quarterly", "Quarterly", 3, 1999, 2997], ["semiannual", "Semi-Annual", 6, 3749, 5994], ["annual", "Annual", 12, 6999, 11988]],
      tags: ["best-seller", "most-popular", "ryzen", "high-performance", "nvme", "ddos-protected"],
      price: [749, 999],
      featured: true,
      popular: true,
    },
    {
      name: "Bedrock Realms Node",
      slug: "bedrock-realms-node",
      cat: mcBedrock.id,
      short: "Cross-play Bedrock servers with Xbox and mobile support.",
      desc: "Bedrock Dedicated Server instances with cross-play enabled, permission management and automatic container updates.",
      specs: [["RAM", "6 GB DDR5"], ["CPU", "3 × Ryzen 9 7950X"], ["Storage", "60 GB NVMe"], ["Cross-play", "Yes, all platforms"], ["Panel", "Pterodactyl"]],
      features: ["Cross-play for Windows, mobile & console", "Automatic BDS updates", "Realms-style permission presets"],
      locations: ["Mumbai", "Singapore"],
      cycles: [["monthly", "Monthly", 1, 499, 649], ["annual", "Annual", 12, 4799, 7788]],
      tags: ["instant-setup", "ddos-protected"],
      price: [499, 649],
    },
    {
      name: "Modded Minecraft Forge",
      slug: "modded-minecraft-forge",
      cat: mcModded.id,
      short: "Pre-installed CurseForge & ATLauncher packs up to 400 mods.",
      desc: "Memory-tuned nodes for heavy modpacks. We pre-allocate heap, tune JVM flags per pack and keep a clean rollback snapshot of your world before every pack change.",
      specs: [["RAM", "12 GB DDR5"], ["CPU", "4 × Ryzen 9 7950X"], ["Storage", "120 GB NVMe"], ["Mod packs", "CurseForge, Modrinth, ATLauncher"], ["Java", "Temurin 21 tuned"]],
      features: ["One-click 400-mod pack install", "JVM flags tuned per pack", "Rollback snapshot before every change"],
      locations: ["Mumbai", "Frankfurt", "Ashburn"],
      cycles: [["monthly", "Monthly", 1, 1149, 1399], ["quarterly", "Quarterly", 3, 3149, 4197], ["annual", "Annual", 12, 11499, 16788]],
      tags: ["premium", "high-performance", "nvme"],
      price: [1149, 1399],
      featured: true,
    },
    {
      name: "Rust Oxide Node",
      slug: "rust-oxide-node",
      cat: rust.id,
      short: "32 GB RAM Rust servers with uMod and wipe scheduling.",
      desc: "Large-map Rust servers on dedicated DDR5 memory with oxide pre-installed, automatic map wipes and player analytics.",
      specs: [["RAM", "16 GB DDR5"], ["CPU", "6 × Ryzen 9 7950X"], ["Storage", "200 GB NVMe"], ["Map size", "Up to 4500"], ["Network", "1 Gbit unmetered"]],
      features: ["uMod + oxide pre-installed", "Scheduled wipes & seed rotation", "Player count analytics"],
      locations: ["Singapore", "Frankfurt", "London"],
      cycles: [["monthly", "Monthly", 1, 1899, 2299], ["quarterly", "Quarterly", 3, 5199, 6897]],
      tags: ["high-performance", "ddos-protected"],
      price: [1899, 2299],
    },
    {
      name: "FiveM Roleplay Server",
      slug: "fivm-roleplay-server",
      cat: (await q('SELECT id FROM categories WHERE slug = \'fivm-hosting\'')).rows[0].id,
      short: "FXServer with txAdmin, artifact auto-updates and 128 slots.",
      desc: "Roleplay-ready FXServer instances. OneSync Infinity, txAdmin scheduling, automatic artifact builds and MySQL included for framework-heavy servers.",
      specs: [["RAM", "16 GB DDR5"], ["CPU", "6 × Ryzen 9 7950X"], ["Storage", "150 GB NVMe"], ["Slots", "128 (OneSync Infinity)"], ["Database", "MySQL 8 included"]],
      features: ["Automatic artifact updates", "txAdmin scheduled restarts", "Included MySQL for frameworks", "Free resource migration"],
      locations: ["Frankfurt", "Ashburn", "London"],
      cycles: [["monthly", "Monthly", 1, 2499, 2999], ["quarterly", "Quarterly", 3, 6899, 8997]],
      tags: ["premium", "high-performance", "most-popular"],
      price: [2499, 2999],
      featured: true,
    },
    {
      name: "Discord Bot Runtime S1",
      slug: "discord-bot-runtime-s1",
      cat: (await q('SELECT id FROM categories WHERE slug = \'discord-bot-hosting\'')).rows[0].id,
      short: "PM2-managed Node.js and Python bots with 99.9% uptime SLA.",
      desc: "Deploy from Git or drag-and-drop upload. PM2 keeps your bot alive, restarts on crash and streams logs to a live console with alerting to Discord.",
      specs: [["RAM", "1 GB DDR5"], ["CPU", "1 dedicated vCPU"], ["Storage", "10 GB NVMe"], ["Processes", "3 PM2 slots"], ["Runtimes", "Node 22 · Python 3.12"]],
      features: ["Live log streaming to Discord", "Auto-restart on crash", "Git pull deploy webhooks", "Free MySQL database"],
      locations: ["Mumbai", "Singapore", "Frankfurt"],
      cycles: [["monthly", "Monthly", 1, 99, 149], ["annual", "Annual", 12, 949, 1788]],
      tags: ["budget-friendly", "instant-setup"],
      price: [99, 149],
    },
    {
      name: "Telegram Bot Worker",
      slug: "telegram-bot-worker",
      cat: (await q('SELECT id FROM categories WHERE slug = \'telegram-bot-hosting\'')).rows[0].id,
      short: "Webhook & long-polling bots with managed TLS certificates.",
      desc: "Persistent Python or Node workers for Telegram bots, with automatic webhook certificates, rate-limit aware retry queues and cron scheduling.",
      specs: [["RAM", "1 GB DDR5"], ["CPU", "1 dedicated vCPU"], ["Storage", "10 GB NVMe"], ["Webhook TLS", "Automatic, auto-renewed"], ["Cron", "Included"]],
      features: ["Managed webhook TLS", "Retry queue for API limits", "Scheduled jobs"],
      locations: ["Mumbai", "Frankfurt"],
      cycles: [["monthly", "Monthly", 1, 129, 179], ["quarterly", "Quarterly", 3, 349, 537]],
      tags: ["budget-friendly", "instant-setup"],
      price: [129, 179],
    },
    {
      name: "Shared Hosting Starter",
      slug: "shared-hosting-starter",
      cat: (await q('SELECT id FROM categories WHERE slug = \'shared-hosting\'')).rows[0].id,
      short: "LiteSpeed shared hosting for portfolios and small business sites.",
      desc: "cPanel-compatible shared hosting with LiteSpeed caching, free SSL, daily backups and a softaculous one-click installer for 400+ applications.",
      specs: [["Websites", "1"], ["Storage", "10 GB NVMe"], ["Bandwidth", "Unmetered"], ["Databases", "5"], ["Email accounts", "10"], ["SSL", "Free, auto-renewed"]],
      features: ["LiteSpeed + LSCache", "Free .com domain on annual", "Daily off-site backups", "400+ one-click installers"],
      locations: ["Mumbai", "Singapore"],
      cycles: [["monthly", "Monthly", 1, 149, 249], ["annual", "Annual", 12, 1499, 2988]],
      tags: ["budget-friendly", "instant-setup"],
      price: [149, 249],
    },
    {
      name: "Managed WordPress Pro",
      slug: "managed-wordpress-pro",
      cat: (await q('SELECT id FROM categories WHERE slug = \'wordpress-hosting\'')).rows[0].id,
      short: "Staging, caching and hardening for client and commerce sites.",
      desc: "Managed WordPress with one-click staging, edge caching, malware scanning, automatic core updates and a WAF tuned for WooCommerce.",
      specs: [["Websites", "10"], ["Storage", "50 GB NVMe"], ["Bandwidth", "Unmetered"], ["Staging", "Unlimited"], ["PHP workers", "16"], ["WAF", "Included"]],
      features: ["One-click staging & push live", "WooCommerce-tuned WAF", "Malware scanning & cleanup", "Edge cache in 12 regions"],
      locations: ["Mumbai", "Frankfurt", "Ashburn"],
      cycles: [["monthly", "Monthly", 1, 649, 899], ["quarterly", "Quarterly", 3, 1749, 2697], ["annual", "Annual", 12, 6299, 10788]],
      tags: ["premium", "ddos-protected", "most-popular"],
      price: [649, 899],
      featured: true,
    },
    {
      name: "Linux VPS KVM-2",
      slug: "linux-vps-kvm-2",
      cat: (await q('SELECT id FROM categories WHERE slug = \'linux-vps\'')).rows[0].id,
      short: "KVM virtualisation, full root, Ubuntu/Debian/Alma in 45 seconds.",
      desc: "A general-purpose KVM VPS with guaranteed vCPU allocation, snapshottable NVMe volumes and a recovery console that works even if you break networking.",
      specs: [["vCPU", "2 dedicated"], ["RAM", "4 GB DDR5"], ["Storage", "60 GB NVMe"], ["Bandwidth", "4 TB @ 1 Gbit"], ["IPv4", "1 + /64 IPv6"], ["Access", "Full root + VNC console"]],
      features: ["Dedicated vCPU — never shared", "Snapshots & reinstall in 45s", "Rescue console over HTTPS", "Free reverse DNS"],
      locations: ["Mumbai", "Singapore", "Frankfurt", "Ashburn", "Tokyo"],
      cycles: [["monthly", "Monthly", 1, 799, 999], ["quarterly", "Quarterly", 3, 2199, 2997], ["annual", "Annual", 12, 7999, 11988]],
      tags: ["instant-setup", "nvme", "ddos-protected"],
      price: [799, 999],
      popular: true,
    },
    {
      name: "Windows VPS RDP-4",
      slug: "windows-vps-rdp-4",
      cat: (await q('SELECT id FROM categories WHERE slug = \'windows-vps\'')).rows[0].id,
      short: "Licensed Windows Server with RDP and optional GPU passthrough.",
      desc: "Genuine Windows Server 2022 licensing, RDP access on port 3389, .NET runtimes and optional NVIDIA passthrough for CAD and rendering workloads.",
      specs: [["vCPU", "4 dedicated"], ["RAM", "8 GB DDR5"], ["Storage", "120 GB NVMe"], ["Bandwidth", "5 TB @ 1 Gbit"], ["OS", "Windows Server 2022 (licensed)"], ["Access", "RDP + PowerShell remoting"]],
      features: ["Genuine included licence", "Optional NVIDIA GPU passthrough", ".NET Framework & Core preinstalled"],
      locations: ["Frankfurt", "Ashburn", "London"],
      cycles: [["monthly", "Monthly", 1, 2499, 2999], ["annual", "Annual", 12, 24999, 35988]],
      tags: ["premium", "high-performance"],
      price: [2499, 2999],
    },
    {
      name: "EPYC Cloud VPS C-8",
      slug: "epyc-cloud-vps-c-8",
      cat: (await q('SELECT id FROM categories WHERE slug = \'high-performance-vps\'')).rows[0].id,
      short: "AMD EPYC 9354 compute instances for databases and APIs.",
      desc: "Compute-optimised instances on EPYC 9354 with PCIe Gen5 NVMe, 10 Gbit east-west networking and per-second billing granularity on annual terms.",
      specs: [["vCPU", "8 dedicated EPYC"], ["RAM", "32 GB DDR5"], ["Storage", "240 GB Gen5 NVMe"], ["Network", "10 Gbit internal"], ["Bandwidth", "10 TB"], ["SLA", "99.99%"]],
      features: ["EPYC 9354 @ 3.25 GHz base", "PCIe Gen5 NVMe arrays", "Private network between instances"],
      locations: ["Frankfurt", "Ashburn", "Singapore"],
      cycles: [["monthly", "Monthly", 1, 4999, 5999], ["quarterly", "Quarterly", 3, 13499, 17997], ["annual", "Annual", 12, 49999, 71988]],
      tags: ["amd-epyc", "high-performance", "nvme", "premium"],
      price: [4999, 5999],
      featured: true,
    },
    {
      name: "Bare Metal — Ryzen 9 7950X",
      slug: "bare-metal-ryzen-9-7950x",
      cat: dedi.id,
      short: "Single-tenant 16-core/32-thread machine with remote hands.",
      desc: "Your own chassis. 16 Zen 4 cores boosting to 5.7 GHz, 64 GB DDR5, 2 × 1 TB Gen4 NVMe in RAID-1 and dual 25 Gbit uplinks. Set up within 4 business hours.",
      specs: [["CPU", "Ryzen 9 7950X · 16C/32T @ 5.7 GHz"], ["RAM", "64 GB DDR5-5600 ECC"], ["Storage", "2 × 1 TB Gen4 NVMe (RAID-1)"], ["Network", "2 × 25 Gbit · 50 TB transfer"], ["RAID", "Hardware RAID-1"], ["Setup", "Within 4 business hours"]],
      features: ["Single-tenant, no virtualisation", "Remote hands included", "IPMI / KVM over IP", "Replacement parts on-site"],
      locations: ["Frankfurt", "Ashburn"],
      cycles: [["monthly", "Monthly", 1, 18999, 21999], ["annual", "Annual", 12, 199999, 263988]],
      tags: ["premium", "high-performance", "ryzen"],
      price: [18999, 21999],
    },
    {
      name: "Managed PostgreSQL Cluster",
      slug: "managed-postgresql-cluster",
      cat: (await q('SELECT id FROM categories WHERE slug = \'database-hosting\'')).rows[0].id,
      short: "HA PostgreSQL with streaming replica, PITR and connection pooling.",
      desc: "Production PostgreSQL with a synchronous standby, point-in-time recovery, PgBouncer pooling and a read endpoint you can hand straight to your app.",
      specs: [["Version", "PostgreSQL 16"], ["RAM", "8 GB dedicated"], ["Storage", "100 GB NVMe"], ["Replica", "1 synchronous standby"], ["PITR", "Continuous WAL archiving"], ["Pooling", "PgBouncer included"]],
      features: ["Point-in-time recovery (7 days)", "Automatic minor-version upgrades", "Read replica endpoint", "Slow-query insights"],
      locations: ["Mumbai", "Frankfurt"],
      cycles: [["monthly", "Monthly", 1, 3499, 4299], ["quarterly", "Quarterly", 3, 9499, 12897]],
      tags: ["most-popular", "nvme", "ddos-protected"],
      price: [3499, 4299],
    },
    {
      name: "Cloud Cluster — Autoscale",
      slug: "cloud-cluster-autoscale",
      cat: (await q('SELECT id FROM categories WHERE slug = \'cloud-hosting\'')).rows[0].id,
      short: "Elastic node group with load balancer and horizontal autoscaling.",
      desc: "A managed cluster of compute instances behind a health-checked load balancer. Scale from two to twenty nodes on CPU or queue depth, with rolling deploys.",
      specs: [["Base nodes", "2 × KVM-4"], ["Load balancer", "Included, L4 + L7"], ["Autoscaling", "CPU / queue depth"], ["Storage", "200 GB distributed NVMe"], ["Deployments", "Rolling, zero downtime"], ["Monitoring", "Metrics + alerting"]],
      features: ["Scale 2 → 20 nodes automatically", "Health-checked rolling deploys", "Centralised logs & metrics", "Private inter-node network"],
      locations: ["Singapore", "Frankfurt", "Ashburn"],
      cycles: [["monthly", "Monthly", 1, 8999, 11499], ["quarterly", "Quarterly", 3, 24499, 34497], ["annual", "Annual", 12, 89999, 137988]],
      tags: ["high-performance", "ddos-protected", "premium"],
      price: [8999, 11499],
      featured: true,
    },
  ];

  let order = 0;
  const planIds = {};
  for (const p of plans) {
    order += 1;
    const prod = await ins("products", {
      name: p.name,
      slug: p.slug,
      short_description: p.short,
      description: p.desc,
      category_id: p.cat,
      icon: "server",
      specs: JSON.stringify(p.specs.map(([label, value]) => ({ label, value }))),
      features: JSON.stringify(p.features),
      locations: JSON.stringify(p.locations),
      faqs: JSON.stringify([
        { q: "How fast is deployment?", a: "Instances are provisioned automatically within 60 seconds of payment confirmation." },
        { q: "Can I upgrade later?", a: "Yes — upgrades are prorated to your current billing cycle and applied immediately." },
      ]),
      setup_fee: "0",
      tax_rate: "18",
      currency: "INR",
      sort_order: order,
      active: true,
      featured: !!p.featured,
      best_seller: p.slug === "minecraft-java-pro",
      popularity: Math.floor(Math.random() * 400) + 60,
      seo_title: `${p.name} — Obsidian Node`,
      seo_description: p.short,
    });
    planIds[p.slug] = prod.id;
    let s = 0;
    for (const [key, label, months, price, compare] of p.cycles) {
      await ins("billing_cycles", {
        product_id: prod.id,
        key,
        label,
        months,
        price: String(price),
        compare_at: String(compare),
        active: true,
        sort_order: (s += 1),
      });
    }
    await ins("billing_configurations", {
      product_id: prod.id,
      ordering_enabled: true,
      billing_type: "external",
      destination_url: `https://billing.obsidiannode.io/order/${p.slug}`,
      url_params: JSON.stringify({ source: "storefront" }),
      open_in: "same",
      button_text: "Order Now",
      trusted_hosts: "billing.obsidiannode.io",
    });
    for (const t of p.tags) {
      if (tagRows[t]) await ins("product_tags", { product_id: prod.id, tag_id: tagRows[t].id });
    }
  }

  /* ---------------------------- CMS content --------------------------- */
  const quotes = [
    ["Rohan Das", "Owner, PlayForge", "playforge.gg", "We moved 40 Minecraft servers over on a Sunday night. Migration team handled every world and plugin — TPS never dropped below 19.8 during the swap."],
    ["Ishita Kapoor", "CTO, Vellum Labs", "vellum.dev", "Our PostgreSQL cluster has been up for 311 days. PITR saved us twice after bad migrations. That alone paid for the year."],
    ["Kabir Nair", "Community Lead, Nightjar RP", "nightjar.io", "FiveM with 120 concurrent players and no hitching since we moved. txAdmin scheduling means nobody has to be awake at 4am for restarts."],
    ["Meera Iyer", "Founder, Lumen Labs", "lumenlabs.co", "Support answered at 2am with an actual engineer who knew what a segmentation fault was. Unheard of at this price point."],
  ];
  for (let i = 0; i < quotes.length; i++) {
    const [name, role, company, quote] = quotes[i];
    await ins("testimonials", { name, role, company, quote, rating: 5, sort_order: i, active: true });
  }
  const faqDefs = [
    ["General", "How quickly are servers deployed?", "Payment-confirmed orders are provisioned automatically, usually in under 60 seconds. Dedicated servers are handed over within 4 business hours."],
    ["General", "Do you offer a money-back guarantee?", "Yes. All shared, bot and game hosting plans carry a 7-day money-back guarantee. Dedicated servers are excluded due to reserved hardware."],
    ["Billing", "Which payment methods do you accept?", "UPI, credit and debit cards, net banking and wallets via Razorpay, cryptocurrency through our crypto provider, direct wallet balance and manual QR / bank transfer."],
    ["Billing", "Can I switch billing cycles later?", "You can move between monthly, quarterly, semi-annual and annual at any time. The remainder of your current cycle is credited automatically."],
    ["Network", "Is DDoS protection really included?", "Every IP we announce sits behind always-on 40 Tbit/s scrubbing. There is no filtered/unfiltered tier — protection is on by default and free."],
    ["Support", "Can you migrate my existing server?", "Yes, free of charge. Send us panel or SSH credentials and our team migrates worlds, databases and configurations, then validate before cutover."],
  ];
  for (let i = 0; i < faqDefs.length; i++) {
    const [group, question, answer] = faqDefs[i];
    await ins("faqs", { group, question, answer, sort_order: i, active: true });
  }

  await ins("payment_methods", {
    key: "wallet",
    name: "Wallet",
    enabled: true,
    config: JSON.stringify({ topups: [500, 1000, 2500, 5000], instructions: "Pay instantly from your Obsidian Node wallet balance." }),
    sort_order: 1,
  });
  await ins("payment_methods", {
    key: "razorpay",
    name: "Razorpay",
    enabled: true,
    config: JSON.stringify({ keyId: "", keySecret: "", webhookSecret: "", mode: "test" }),
    sort_order: 2,
  });
  await ins("payment_methods", {
    key: "crypto",
    name: "Cryptocurrency",
    enabled: false,
    config: JSON.stringify({ provider: "nowpayments", apiKey: "", ipnSecret: "", coins: ["BTC", "ETH", "USDT-TRC20", "LTC"] }),
    sort_order: 3,
  });
  await ins("payment_methods", {
    key: "qr",
    name: "QR / Bank Transfer",
    enabled: true,
    config: JSON.stringify({ upiId: "obsidiannode@upi", qrImage: "", instructions: "Scan the QR, pay, then submit the UTR / reference for verification.", requireScreenshot: true }),
    sort_order: 4,
  });
  await ins("coupons", { code: "LAUNCH20", type: "percent", value: "20", max_uses: 500, used: 42, active: true });
  await ins("coupons", { code: "FLAT500", type: "fixed", value: "500", max_uses: 100, used: 11, active: true });

  /* ------------------------------- orders ----------------------------- */
  const planList = Object.entries(planIds);
  const methods = ["wallet", "razorpay", "qr", "crypto"];
  const statuses = ["paid", "active", "pending", "awaiting_payment", "failed", "refunded", "processing", "cancelled"];
  const cycleOptions = [
    ["monthly", "Monthly", 1],
    ["quarterly", "Quarterly", 3],
    ["annual", "Annual", 12],
  ];
  for (let i = 0; i < 64; i++) {
    const [slug, pid] = planList[Math.floor(Math.random() * planList.length)];
    const planName = plans.find((p) => p.slug === slug)?.name ?? slug;
    const cyc = cycleOptions[Math.floor(Math.random() * cycleOptions.length)];
    const base = plans.find((p) => p.slug === slug)?.price?.[0] ?? 499;
    const total = base * cyc[2];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const created = new Date(Date.now() - Math.floor(Math.random() * 30) * 864e5 - Math.floor(Math.random() * 864e5));
    const customer = customers[Math.floor(Math.random() * customers.length)];
    const method = methods[Math.floor(Math.random() * methods.length)];
    const order = await ins("orders", {
      reference: `ORD${randomBytes(5).toString("hex").toUpperCase()}`,
      user_id: customer.id,
      product_id: pid,
      plan_name: planName,
      cycle_key: cyc[0],
      cycle_label: cyc[1],
      location: ["Mumbai", "Singapore", "Frankfurt", "Ashburn"][Math.floor(Math.random() * 4)],
      subtotal: String(total),
      discount: "0",
      tax: String(Math.round(total * 0.18)),
      total: String(Math.round(total * 1.18)),
      currency: "INR",
      payment_method: method,
      status: ["paid", "active", "processing"].includes(status) ? "paid" : status === "awaiting_payment" ? "pending" : status,
      meta: JSON.stringify({ source: "seed" }),
      created_at: created,
      updated_at: created,
    });
    if (["paid", "active", "failed", "refunded"].includes(status)) {
      await ins("payments", {
        reference: `PAY${randomBytes(6).toString("hex").toUpperCase()}`,
        order_id: order.id,
        user_id: customer.id,
        method,
        provider: method === "razorpay" ? "razorpay" : method === "crypto" ? "nowpayments" : method,
        amount: String(Math.round(total * 1.18)),
        currency: "INR",
        status: status === "failed" ? "failed" : status === "refunded" ? "refunded" : "verified",
        external_id: method === "razorpay" ? `pay_${randomBytes(8).toString("hex")}` : randomBytes(6).toString("hex"),
        created_at: created,
        updated_at: created,
      });
    }
    if (status === "pending" && method === "qr") {
      await ins("payments", {
        reference: `PAY${randomBytes(6).toString("hex").toUpperCase()}`,
        order_id: order.id,
        user_id: customer.id,
        method: "qr",
        amount: String(Math.round(total * 1.18)),
        status: "awaiting_verification",
        note: "UTR submitted from seed queue",
        created_at: created,
        updated_at: created,
      });
    }
  }

  /* ------------------------------- wallets ---------------------------- */
  for (const c of customers) {
    const bal = (Math.floor(Math.random() * 8) + 2) * 500;
    await ins("wallet_accounts", { user_id: c.id, balance: String(bal) });
    await ins("wallet_transactions", {
      user_id: c.id,
      type: "topup",
      amount: String(bal),
      balance_after: String(bal),
      reference: `wc_${randomBytes(6).toString("hex")}`,
      note: "Wallet top-up via UPI",
      created_at: new Date(Date.now() - 20 * 864e5),
    });
  }

  console.log("Seed complete.");
  console.log("Admin  → admin@obsidiannode.io / Admin@1234");
  console.log("Finance→ finance@obsidiannode.io / Finance@1234");
  console.log("Customer → rohan@playforge.gg / Customer@1234");
  process.exit(0);
};

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
