import {
  pgTable,
  pgEnum,
  uuid,
  varchar,
  text,
  integer,
  boolean,
  numeric,
  jsonb,
  timestamp,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const userRole = pgEnum("user_role", [
  "super_admin",
  "product_manager",
  "finance_manager",
  "support",
  "customer",
]);
export const userStatus = pgEnum("user_status", ["active", "suspended"]);
export const orderStatus = pgEnum("order_status", [
  "pending",
  "awaiting_payment",
  "paid",
  "processing",
  "active",
  "cancelled",
  "failed",
  "refunded",
]);
export const paymentStatus = pgEnum("payment_status", [
  "pending",
  "awaiting_verification",
  "verified",
  "rejected",
  "failed",
  "refunded",
]);
export const walletTxType = pgEnum("wallet_tx_type", [
  "topup",
  "debit",
  "refund",
  "adjustment",
]);

/* ---------------------------------- users --------------------------------- */
export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    email: varchar("email", { length: 190 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: userRole("role").notNull().default("customer"),
    status: userStatus("status").notNull().default("active"),
    discord: varchar("discord", { length: 80 }),
    mustChangePassword: boolean("must_change_password").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_uq").on(t.email), index("users_role_idx").on(t.role)],
);

/* -------------------------------- categories ------------------------------ */
export const categories = pgTable(
  "categories",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    slug: varchar("slug", { length: 140 }).notNull(),
    description: text("description"),
    icon: varchar("icon", { length: 60 }).default("server"),
    image: varchar("image", { length: 400 }),
    parentId: uuid("parent_id").references((): any => categories.id, {
      onDelete: "set null",
    }),
    seoTitle: varchar("seo_title", { length: 190 }),
    seoDescription: varchar("seo_description", { length: 320 }),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("categories_slug_uq").on(t.slug), index("categories_parent_idx").on(t.parentId)],
);

/* ----------------------------------- tags --------------------------------- */
export const tags = pgTable(
  "tags",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 80 }).notNull(),
    slug: varchar("slug", { length: 90 }).notNull(),
    color: varchar("color", { length: 20 }).notNull().default("#FF6B18"),
    showOnCards: boolean("show_on_cards").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("tags_slug_uq").on(t.slug)],
);

/* --------------------------------- products ------------------------------- */
export const products = pgTable(
  "products",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    slug: varchar("slug", { length: 180 }).notNull(),
    shortDescription: varchar("short_description", { length: 320 }),
    description: text("description"),
    categoryId: uuid("category_id").references(() => categories.id, { onDelete: "set null" }),
    icon: varchar("icon", { length: 60 }).default("box"),
    image: varchar("image", { length: 400 }),
    specs: jsonb("specs").notNull().default([]),
    features: jsonb("features").notNull().default([]),
    locations: jsonb("locations").notNull().default([]),
    faqs: jsonb("faqs").notNull().default([]),
    setupFee: numeric("setup_fee", { precision: 10, scale: 2 }).notNull().default("0"),
    taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).notNull().default("0"),
    currency: varchar("currency", { length: 8 }).notNull().default("INR"),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean("active").notNull().default(true),
    featured: boolean("featured").notNull().default(false),
    bestSeller: boolean("best_seller").notNull().default(false),
    archived: boolean("archived").notNull().default(false),
    popularity: integer("popularity").notNull().default(0),
    seoTitle: varchar("seo_title", { length: 190 }),
    seoDescription: varchar("seo_description", { length: 320 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("products_slug_uq").on(t.slug),
    index("products_category_idx").on(t.categoryId),
    index("products_active_idx").on(t.active),
  ],
);

export const billingCycles = pgTable(
  "billing_cycles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    key: varchar("key", { length: 30 }).notNull(),
    label: varchar("label", { length: 60 }).notNull(),
    months: integer("months").notNull().default(1),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    compareAt: numeric("compare_at", { precision: 10, scale: 2 }),
    active: boolean("active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (t) => [uniqueIndex("billing_cycles_uq").on(t.productId, t.key)],
);

export const billingConfigurations = pgTable("billing_configurations", {
  id: uuid("id").defaultRandom().primaryKey(),
  productId: uuid("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" })
    .unique(),
  orderingEnabled: boolean("ordering_enabled").notNull().default(true),
  billingType: varchar("billing_type", { length: 30 }).notNull().default("external"),
  destinationUrl: text("destination_url"),
  urlParams: jsonb("url_params").notNull().default({}),
  openIn: varchar("open_in", { length: 10 }).notNull().default("same"),
  buttonText: varchar("button_text", { length: 60 }).default("Order Now"),
  trustedHosts: text("trusted_hosts"),
  /** Relative path on this site, e.g. /order/minecraft-premium — resolved against the canonical domain. */
  redirectPath: text("redirect_path"),
  redirectMode: varchar("redirect_mode", { length: 10 }).notNull().default("internal"),
});

export const productTags = pgTable(
  "product_tags",
  {
    productId: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    tagId: uuid("tag_id")
      .notNull()
      .references(() => tags.id, { onDelete: "cascade" }),
  },
  (t) => [uniqueIndex("product_tag_uq").on(t.productId, t.tagId), index("product_tag_tag_idx").on(t.tagId)],
);

/* --------------------------------- orders --------------------------------- */
export const orders = pgTable(
  "orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    reference: varchar("reference", { length: 24 }).notNull(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    productId: uuid("product_id").references(() => products.id, { onDelete: "set null" }),
    planName: varchar("plan_name", { length: 180 }).notNull(),
    cycleKey: varchar("cycle_key", { length: 30 }).notNull().default("monthly"),
    cycleLabel: varchar("cycle_label", { length: 60 }),
    location: varchar("location", { length: 80 }),
    couponCode: varchar("coupon_code", { length: 40 }),
    subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull().default("0"),
    discount: numeric("discount", { precision: 10, scale: 2 }).notNull().default("0"),
    tax: numeric("tax", { precision: 10, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 10, scale: 2 }).notNull().default("0"),
    currency: varchar("currency", { length: 8 }).notNull().default("INR"),
    paymentMethod: varchar("payment_method", { length: 30 }),
    status: orderStatus("status").notNull().default("pending"),
    billingUrl: text("billing_url"),
    meta: jsonb("meta").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("orders_reference_uq").on(t.reference),
    index("orders_user_idx").on(t.userId),
    index("orders_status_idx").on(t.status),
    index("orders_created_idx").on(t.createdAt),
  ],
);

export const payments = pgTable(
  "payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    reference: varchar("reference", { length: 28 }).notNull(),
    orderId: uuid("order_id").references(() => orders.id, { onDelete: "set null" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    method: varchar("method", { length: 30 }).notNull(),
    provider: varchar("provider", { length: 40 }),
    amount: numeric("amount", { precision: 10, scale: 2 }).notNull().default("0"),
    currency: varchar("currency", { length: 8 }).notNull().default("INR"),
    status: paymentStatus("status").notNull().default("pending"),
    externalId: varchar("external_id", { length: 120 }),
    proofUrl: text("proof_url"),
    note: text("note"),
    rejectReason: text("reject_reason"),
    verifiedBy: uuid("verified_by"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("payments_reference_uq").on(t.reference),
    index("payments_status_idx").on(t.status),
    index("payments_user_idx").on(t.userId),
  ],
);

/* ---------------------------------- wallet -------------------------------- */
export const walletAccounts = pgTable("wallet_accounts", {
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" })
    .primaryKey(),
  balance: numeric("balance", { precision: 12, scale: 2 }).notNull().default("0"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const walletTransactions = pgTable(
  "wallet_transactions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: walletTxType("type").notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    balanceAfter: numeric("balance_after", { precision: 12, scale: 2 }).notNull(),
    orderId: uuid("order_id").references(() => orders.id, { onDelete: "set null" }),
    paymentId: uuid("payment_id").references(() => payments.id, { onDelete: "set null" }),
    reference: varchar("reference", { length: 40 }),
    note: text("note"),
    actorId: uuid("actor_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("wallet_tx_user_idx").on(t.userId), uniqueIndex("wallet_tx_ref_uq").on(t.reference)],
);

/* --------------------------------- coupons -------------------------------- */
export const coupons = pgTable(
  "coupons",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: varchar("code", { length: 40 }).notNull(),
    type: varchar("type", { length: 10 }).notNull().default("percent"),
    value: numeric("value", { precision: 10, scale: 2 }).notNull().default("0"),
    maxUses: integer("max_uses").default(0),
    used: integer("used").notNull().default(0),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("coupons_code_uq").on(t.code)],
);

/* ---------------------------------- CMS ----------------------------------- */
export const settings = pgTable("settings", {
  key: varchar("key", { length: 60 }).primaryKey(),
  value: jsonb("value").notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const homepageSections = pgTable(
  "homepage_sections",
  {
    key: varchar("key", { length: 60 }).primaryKey(),
    value: jsonb("value").notNull().default({}),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
);

export const testimonials = pgTable(
  "testimonials",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    role: varchar("role", { length: 120 }),
    company: varchar("company", { length: 120 }),
    quote: text("quote").notNull(),
    rating: integer("rating").notNull().default(5),
    avatar: varchar("avatar", { length: 400 }),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean("active").notNull().default(true),
  },
);

export const faqs = pgTable(
  "faqs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    question: varchar("question", { length: 300 }).notNull(),
    answer: text("answer").notNull(),
    group: varchar("group", { length: 60 }).notNull().default("General"),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean("active").notNull().default(true),
  },
);

export const activityLogs = pgTable(
  "activity_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id"),
    actor: varchar("actor", { length: 120 }),
    action: varchar("action", { length: 80 }).notNull(),
    entity: varchar("entity", { length: 60 }),
    entityId: varchar("entity_id", { length: 60 }),
    meta: jsonb("meta").notNull().default({}),
    ip: varchar("ip", { length: 60 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("activity_created_idx").on(t.createdAt)],
);

/* ------------------------------ payment methods --------------------------- */
export const paymentMethods = pgTable(
  "payment_methods",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    key: varchar("key", { length: 30 }).notNull(),
    name: varchar("name", { length: 80 }).notNull(),
    enabled: boolean("enabled").notNull().default(false),
    config: jsonb("config").notNull().default({}),
    sortOrder: integer("sort_order").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("payment_methods_key_uq").on(t.key)],
);


/* ----------------------------- server locations --------------------------- */
export const serverLocations = pgTable(
  "server_locations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    city: varchar("city", { length: 80 }),
    country: varchar("country", { length: 80 }),
    code: varchar("code", { length: 20 }),
    tier: varchar("tier", { length: 20 }).default("Edge"),
    /** Health/ping endpoint actually measured. Null => latency is unavailable, never invented. */
    endpoint: text("endpoint"),
    timeoutMs: integer("timeout_ms").notNull().default(4000),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("server_locations_active_idx").on(t.active)],
);

/* ---------------------------- free demo servers --------------------------- */
export const demoServers = pgTable(
  "demo_servers",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    reference: varchar("reference", { length: 24 }).notNull(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 80 }).notNull(),
    software: varchar("software", { length: 60 }).notNull(),
    version: varchar("version", { length: 40 }),
    ramMb: integer("ram_mb").notNull().default(1024),
    cpuPercent: integer("cpu_percent").notNull().default(100),
    diskMb: integer("disk_mb").notNull().default(10240),
    durationMinutes: integer("duration_minutes").notNull().default(60),
    price: numeric("price", { precision: 10, scale: 2 }).notNull().default("0"),
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    externalId: varchar("external_id", { length: 60 }),
    panelUrl: text("panel_url"),
    lastError: text("last_error"),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    createdIp: varchar("created_ip", { length: 60 }),
    meta: jsonb("meta").notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    stoppedAt: timestamp("stopped_at", { withTimezone: true }),
  },
  (t) => [
    index("demo_servers_user_idx").on(t.userId),
    index("demo_servers_status_idx").on(t.status),
    uniqueIndex("demo_servers_reference_uq").on(t.reference),
  ],
);

/* ------------------------------ system config ----------------------------- */
/**
 * Private key/value store for operational secrets (database connection material,
 * console/API credentials). Never exposed by any public route; password fields
 * are AES-256-GCM encrypted at rest and masked in every response.
 */
export const systemConfig = pgTable("system_config", {
  key: varchar("key", { length: 60 }).primaryKey(),
  value: jsonb("value").notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  updatedBy: uuid("updated_by"),
});

export type User = typeof users.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Tag = typeof tags.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Payment = typeof payments.$inferSelect;
