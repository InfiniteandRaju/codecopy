import { db } from "@/db";
import { walletAccounts, walletTransactions, orders } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { ApiError } from "@/lib/api";
import { randomBytes } from "crypto";

export type TxType = "topup" | "debit" | "refund" | "adjustment";

export function newRef(prefix: string) {
  return `${prefix}_${randomBytes(8).toString("hex")}`;
}

export async function getBalance(userId: string): Promise<number> {
  const rows = await db
    .select({ balance: walletAccounts.balance })
    .from(walletAccounts)
    .where(eq(walletAccounts.userId, userId))
    .limit(1);
  if (rows[0]) return Number(rows[0].balance);
  await db
    .insert(walletAccounts)
    .values({ userId, balance: "0" })
    .onConflictDoNothing({ target: walletAccounts.userId });
  return 0;
}

export type LedgerInput = {
  userId: string;
  type: TxType;
  /** Always positive; direction is derived from type. */
  amount: number;
  note?: string;
  orderId?: string | null;
  paymentId?: string | null;
  actorId?: string | null;
  reference?: string;
};

const CREDIT: TxType[] = ["topup", "refund", "adjustment"];

/**
 * Atomic, idempotent ledger write. The wallet row is locked with SELECT ... FOR UPDATE
 * so concurrent debits cannot overdraw or double-spend. `reference` is unique, which
 * makes retried calls no-ops instead of duplicate deductions.
 */
export async function applyWalletTx(input: LedgerInput): Promise<{ balance: number; id: string }> {
  if (!Number.isFinite(input.amount) || input.amount <= 0) {
    throw new ApiError("Amount must be a positive number", 422);
  }
  const amount = Math.round(input.amount * 100) / 100;
  const reference = input.reference ?? newRef(input.type === "debit" ? "wd" : "wc");

  return db.transaction(async (tx) => {
    await tx
      .insert(walletAccounts)
      .values({ userId: input.userId, balance: "0" })
      .onConflictDoNothing({ target: walletAccounts.userId });

    const locked = await tx.execute(sql`
      SELECT balance FROM wallet_accounts WHERE user_id = ${input.userId} FOR UPDATE
    `);
    const current = Number((locked as any).rows?.[0]?.balance ?? 0);
    const credits = CREDIT.includes(input.type);
    const next = credits ? current + amount : current - amount;
    if (next < 0) throw new ApiError("Insufficient wallet balance", 402);

    const dupe = await tx
      .select({ id: walletTransactions.id })
      .from(walletTransactions)
      .where(eq(walletTransactions.reference, reference))
      .limit(1);
    if (dupe[0]) return { balance: current, id: dupe[0].id };

    await tx
      .update(walletAccounts)
      .set({ balance: String(next.toFixed(2)), updatedAt: new Date() })
      .where(eq(walletAccounts.userId, input.userId));

    const inserted = await tx
      .insert(walletTransactions)
      .values({
        userId: input.userId,
        type: input.type,
        amount: String(amount.toFixed(2)),
        balanceAfter: String(next.toFixed(2)),
        orderId: input.orderId ?? null,
        paymentId: input.paymentId ?? null,
        reference,
        note: input.note ?? null,
        actorId: input.actorId ?? null,
      })
      .returning({ id: walletTransactions.id });

    return { balance: next, id: inserted[0].id };
  });
}

export async function markOrderPaid(orderId: string, paymentMethod: string) {
  await db
    .update(orders)
    .set({ status: "paid", paymentMethod, updatedAt: new Date() })
    .where(eq(orders.id, orderId));
}
