import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import type { User } from "@/db/schema";

const SECRET = process.env.AUTH_SECRET || process.env.DATABASE_SECRET || "obsidian-node-dev-secret";
export const SESSION_COOKIE = "obs_session";
const TTL_MS = 1000 * 60 * 60 * 24 * 7;

/* ------------------------------- passwords -------------------------------- */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split("$");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const derived = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return expected.length === derived.length && timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

/* --------------------------------- tokens --------------------------------- */
function sign(payload: string): string {
  return createHmac("sha256", SECRET).update(payload).digest("base64url");
}

export type Session = { sub: string; role: string; name: string; email: string; exp: number };

export function createToken(user: User): string {
  const payload = Buffer.from(
    JSON.stringify({
      sub: user.id,
      role: user.role,
      name: user.name,
      email: user.email,
      exp: Date.now() + TTL_MS,
    }),
  ).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

export function parseToken(token: string | undefined): Session | null {
  if (!token) return null;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const session = JSON.parse(Buffer.from(payload, "base64url").toString()) as Session;
    if (!session.exp || session.exp < Date.now()) return null;
    return session;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<Session | null> {
  const jar = await cookies();
  return parseToken(jar.get(SESSION_COOKIE)?.value);
}

export async function setSessionCookie(user: User, req?: Request) {
  const jar = await cookies();
  // Only mark the cookie Secure when the request really arrived over HTTPS —
  // marking it Secure behind plain HTTP makes the browser silently drop the
  // session, which looks exactly like "login does not work".
  const proto =
    req?.headers.get("x-forwarded-proto")?.split(",")[0]?.trim() ||
    (req ? new URL(req.url).protocol.replace(":", "") : "");
  const secure = proto === "https" || process.env.AUTH_FORCE_SECURE === "true";
  jar.set(SESSION_COOKIE, createToken(user), {
    httpOnly: true,
    sameSite: "lax",
    secure,
    maxAge: TTL_MS / 1000,
    path: "/",
  });
}

export async function clearSessionCookie() {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: "lax", maxAge: 0, path: "/", expires: new Date(0) });
}

export const ADMIN_ROLES = ["super_admin", "product_manager", "finance_manager", "support"] as const;
export type AdminRole = (typeof ADMIN_ROLES)[number];

export function isAdminRole(role: string): role is AdminRole {
  return (ADMIN_ROLES as readonly string[]).includes(role);
}

/** Permissions per role — enforced server side, never trusted from the browser. */
const MATRIX: Record<AdminRole, string[]> = {
  super_admin: ["*"],
  product_manager: ["catalog", "cms"],
  finance_manager: ["orders", "payments", "customers", "settings"],
  support: ["orders", "customers", "cms"],
};

export function can(role: string, scope: string): boolean {
  if (!isAdminRole(role)) return false;
  const grants = MATRIX[role];
  return grants.includes("*") || grants.includes(scope);
}

export async function currentUser(): Promise<User | null> {
  const session = await getSession();
  if (!session) return null;
  const rows = await db.select().from(users).where(eq(users.id, session.sub)).limit(1);
  const user = rows[0] ?? null;
  if (!user || user.status !== "active") return null;
  return user;
}
