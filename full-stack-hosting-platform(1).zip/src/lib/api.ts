import { NextResponse } from "next/server";
import { currentUser, can, isAdminRole, type AdminRole } from "@/lib/auth";
import { db } from "@/db";
import { activityLogs } from "@/db/schema";

export const json = (data: unknown, init: ResponseInit = {}) =>
  NextResponse.json(data, { status: init.status ?? 200, headers: init.headers });

export const fail = (error: string, status = 400) => NextResponse.json({ error }, { status });

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export async function requireUser() {
  const user = await currentUser();
  if (!user) throw new ApiError("Not authenticated", 401);
  return user;
}

export async function requireAdmin(scope = "catalog") {
  const user = await currentUser();
  if (!user) throw new ApiError("Not authenticated", 401);
  if (!isAdminRole(user.role)) throw new ApiError("Forbidden", 403);
  if (!can(user.role, scope)) throw new ApiError("Your role does not permit this action", 403);
  return user;
}

export function handleError(err: unknown) {
  if (err instanceof ApiError) return fail(err.message, err.status);
  const message = err instanceof Error ? err.message : "Unexpected server error";
  console.error("[api]", message);
  return fail(message, 500);
}

export async function logActivity(
  actor: { id: string; name: string } | null,
  action: string,
  entity?: string,
  entityId?: string,
  meta: Record<string, unknown> = {},
  ip?: string | null,
) {
  try {
    await db.insert(activityLogs).values({
      userId: actor?.id ?? null,
      actor: actor?.name ?? "system",
      action,
      entity: entity ?? null,
      entityId: entityId ?? null,
      meta,
      ip: ip ?? null,
    });
  } catch (e) {
    console.error("[activity]", e);
  }
}

/** Rate limit: simple in-memory sliding window (per instance). */
const buckets = new Map<string, number[]>();
export function rateLimit(key: string, max = 20, windowMs = 60_000) {
  const now = Date.now();
  const hits = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (hits.length >= max) return false;
  hits.push(now);
  buckets.set(key, hits);
  return true;
}

/** Only http(s) URLs on explicitly trusted hosts may be used for redirects. */
export function validateRedirectUrl(raw: unknown, allowedHosts: string[] = []): string | null {
  if (typeof raw !== "string" || !raw.trim()) return null;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (url.username || url.password) return null;
  const host = url.hostname.toLowerCase();
  const allow = allowedHosts
    .concat((process.env.TRUSTED_BILLING_HOSTS || "").split(","))
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
  if (allow.length && !allow.includes(host) && !allow.some((h) => host === h || host.endsWith(`.${h}`))) {
    return null;
  }
  return url.toString();
}
