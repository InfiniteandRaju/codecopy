"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/Toast";

export type OrderOptions = {
  slug: string;
  cycleKey?: string;
  location?: string;
  coupon?: string;
};

/**
 * Creates the order server-side (prices are computed in the database layer) and
 * sends the customer to whatever billing destination the admin configured for
 * that plan — external provider, internal checkout or manual flow.
 */
export function useOrder() {
  const [busy, setBusy] = useState<string | null>(null);
  const router = useRouter();
  const { push } = useToast();

  const order = async (opts: OrderOptions, orderKey = "default") => {
    if (busy) return;
    setBusy(orderKey);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(opts),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Unable to start checkout");

      const billing = data.billing ?? {};
      if (billing.mode === "manual") {
        push("Manual order flow: your request is logged — an engineer will confirm availability and contact you.", "info");
        sessionStorage.setItem("obs_checkout", JSON.stringify(data));
        router.push(`/#support`);
        return data;
      }
      if (billing.mode === "redirect" && billing.url) {
        if (billing.openIn === "new") window.open(billing.url, "_blank", "noopener,noreferrer");
        else window.location.href = billing.url;
        return data;
      }
      // Internal checkout / manual flow → take the customer to the payment step.
      sessionStorage.setItem("obs_checkout", JSON.stringify(data));
      if (data.requiresAccount) {
        push("Sign in or create an account to complete payment.", "info");
        router.push(`/login?next=/checkout`);
        return data;
      }
      router.push(`/checkout`);
      return data;
    } catch (e: any) {
      push(e?.message ?? "Unable to start checkout", "err");
      return null;
    } finally {
      setBusy(null);
    }
  };

  return { order, busy };
}
