import { performance } from "perf_hooks";

export type MeasureResult = {
  ok: boolean;
  ms: number | null;
  status: number | null;
  error: string | null;
};

/**
 * Measures real round-trip time to a health endpoint with an actual network
 * request. Returns ms:null when the endpoint cannot be reached — the caller
 * must render "unavailable", never an invented number.
 */
export async function measureEndpoint(rawUrl: string, timeoutMs = 4000): Promise<MeasureResult> {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    return { ok: false, ms: null, status: null, error: "invalid endpoint URL" };
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { ok: false, ms: null, status: null, error: "unsupported protocol" };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const start = performance.now();
  try {
    const res = await fetch(url.toString(), {
      method: "GET",
      cache: "no-store",
      signal: controller.signal,
      headers: { accept: "*/*" },
      // Measure the endpoint itself, not through a proxy layer.
      redirect: "follow",
    } as any);
    const ms = Math.round(performance.now() - start);
    return { ok: res.ok || res.status < 500, ms, status: res.status, error: null };
  } catch (e: any) {
    const aborted = e?.name === "AbortError";
    return {
      ok: false,
      ms: null,
      status: null,
      error: aborted ? "timeout" : (e?.message ?? "connection failed"),
    };
  } finally {
    clearTimeout(timer);
  }
}
