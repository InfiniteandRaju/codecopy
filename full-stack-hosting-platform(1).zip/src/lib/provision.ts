import { db } from "@/db";
import { systemConfig } from "@/db/schema";
import { eq } from "drizzle-orm";
import { encryptSecret, decryptSecret } from "@/lib/secrets";
import { ApiError } from "@/lib/api";

/**
 * Provisioning driver for the free demo servers.
 *
 * It talks to a real Pterodactyl installation through the *server-side*
 * Application API (plus a client API token for power actions). Nothing here is
 * simulated: if no backend is configured, `isConfigured()` is false and every
 * provisioning attempt fails with an explicit message instead of inventing a
 * server. API keys are stored encrypted in `system_config` and never reach the
 * browser.
 */
export type ProvisionConfig = {
  enabled: boolean;
  driver: "pterodactyl";
  /** Panel base URL, e.g. https://panel.example.com */
  baseUrl: string;
  /** Application API key — encrypted at rest. */
  appKey: string;
  /** Client API token used for start/stop/restart — encrypted at rest. */
  clientToken: string;
  nodeStrategy: "auto" | "fixed";
  fixedNodeId: number;
  /** Optional egg override; falls back to the software record's egg. */
  defaultEgg: number;
  defaultDockerImage: string;
  allocationPort: number;
  environment: Record<string, string>;
};

const DEFAULTS: ProvisionConfig = {
  enabled: false,
  driver: "pterodactyl",
  baseUrl: "",
  appKey: "",
  clientToken: "",
  nodeStrategy: "auto",
  fixedNodeId: 0,
  defaultEgg: 0,
  defaultDockerImage: "",
  allocationPort: 25565,
  environment: {},
};

export async function getProvisionConfig(): Promise<ProvisionConfig & { configured: boolean }> {
  const rows = await db.select().from(systemConfig).where(eq(systemConfig.key, "provisioning")).limit(1);
  const stored = (rows[0]?.value ?? {}) as Partial<ProvisionConfig>;
  const cfg: ProvisionConfig = {
    ...DEFAULTS,
    ...stored,
    appKey: decryptSecret(stored.appKey as string),
    clientToken: decryptSecret(stored.clientToken as string),
    environment: (stored.environment ?? {}) as Record<string, string>,
  };
  return { ...cfg, configured: Boolean(cfg.enabled && cfg.baseUrl && cfg.appKey) };
}

export async function saveProvisionConfig(input: Partial<ProvisionConfig>, actorId?: string | null) {
  const current = await getProvisionConfig();
  const merged: ProvisionConfig = { ...current, ...input } as ProvisionConfig;
  if (input.appKey === undefined) merged.appKey = current.appKey;
  if (input.clientToken === undefined) merged.clientToken = current.clientToken;
  const stored: Record<string, any> = {
    ...merged,
    appKey: merged.appKey ? encryptSecret(merged.appKey) : "",
    clientToken: merged.clientToken ? encryptSecret(merged.clientToken) : "",
  };
  await db
    .insert(systemConfig)
    .values({ key: "provisioning", value: stored, updatedBy: actorId ?? null, updatedAt: new Date() })
    .onConflictDoUpdate({ target: systemConfig.key, set: { value: stored, updatedBy: actorId ?? null, updatedAt: new Date() } });
  return { ...merged, appKey: undefined, clientToken: undefined } as any;
}

export function isConfiguredStatic(cfg: { enabled: boolean; baseUrl: string; appKey: string }): boolean {
  return Boolean(cfg.enabled && cfg.baseUrl && cfg.appKey);
}

export async function provisioningStatus() {
  const cfg = await getProvisionConfig();
  if (!isConfiguredStatic(cfg)) {
    return {
      configured: false,
      baseUrl: cfg.baseUrl || null,
      message:
        "No provisioning backend configured. Add the panel URL and Application API key in Admin → Free Server → Provisioning before demos can be created.",
    };
  }
  try {
    const nodes = await panelFetch<any[]>(cfg, "/api/application/nodes", "GET");
    const list: any[] = Array.isArray(nodes) ? (nodes as any) : ((nodes as any)?.data ?? []);
    return {
      configured: true,
      baseUrl: safeHost(cfg.baseUrl),
      message: `Connected — ${list.length} node(s) visible.`,
      nodes: list.map((n: any) => ({
        id: n.id,
        name: n.name ?? n.attributes?.name,
        memory: n.memory_total ?? n.attributes?.memory_total,
        memoryUsed: n.memory_allocated ?? n.attributes?.memory_allocated,
        disk: n.disk_total ?? n.attributes?.disk_total,
        diskUsed: n.disk_allocated ?? n.attributes?.disk_allocated,
      })),
    };
  } catch (e: any) {
    return { configured: true, baseUrl: safeHost(cfg.baseUrl), message: `Configured but unreachable: ${e?.message}`, nodes: [] };
  }
}

function safeHost(u: string) {
  try {
    return new URL(u).host;
  } catch {
    return u;
  }
}

/** Authenticated transport to the panel. Never logs or returns credentials. */
async function panelFetch<T>(
  cfg: ProvisionConfig,
  path: string,
  method: "GET" | "POST" | "DELETE" | "PATCH",
  body?: any,
  client = false,
): Promise<T> {
  if (!cfg.baseUrl) throw new ApiError("Provisioning base URL is not configured.", 503);
  const base = cfg.baseUrl.replace(/\/+$/, "");
  const url = new URL(path.startsWith("/") ? path : `/${path}`, `${base}/`).toString();
  if (new URL(url).host !== new URL(base).host) throw new ApiError("Provisioning path points outside the panel host.", 422);

  const token = client ? cfg.clientToken : cfg.appKey;
  if (!token) {
    throw new ApiError(
      client
        ? "A client API token is required for start/stop/restart — add it in Admin → Free Server → Provisioning."
        : "A panel Application API key is required.",
      503,
    );
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(url, {
      method,
      cache: "no-store",
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.pterodactyl.v1+json",
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let data: any = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = text;
    }
    if (!res.ok) {
      const errors = Array.isArray(data?.errors) ? data.errors.map((e: any) => e.detail ?? e.code).join("; ") : null;
      const detail = errors || (typeof data === "string" ? data.slice(0, 200) : (data?.error ?? data?.message ?? ""));
      throw new ApiError(`Panel returned ${res.status}${detail ? `: ${detail}` : ""}`, res.status === 404 ? 404 : 502);
    }
    return data as T;
  } catch (e: any) {
    if (e instanceof ApiError) throw e;
    if (e?.name === "AbortError") throw new ApiError("The provisioning backend timed out.", 504);
    throw new ApiError(`Cannot reach the provisioning backend: ${e?.message ?? "network error"}`, 502);
  } finally {
    clearTimeout(timer);
  }
}

/* --------------------------------- nodes ---------------------------------- */
export async function pickNode(cfg: ProvisionConfig, memoryMb: number, diskMb: number) {
  const raw = await panelFetch<any[]>(cfg, "/api/application/nodes", "GET");
  const nodes = (Array.isArray(raw) ? raw : (raw as any)?.data ?? []).map((n: any) => n.attributes ?? n);
  if (!nodes.length) throw new ApiError("The panel reports no nodes — nothing can be provisioned.", 503);

  const usable = nodes.filter((n: any) => n.status === undefined || n.status === "online");
  const pool = usable.length ? usable : nodes;

  if (cfg.nodeStrategy === "fixed") {
    const fixed = pool.find((n: any) => Number(n.id) === Number(cfg.fixedNodeId));
    if (!fixed) throw new ApiError(`Configured node ${cfg.fixedNodeId} is not available on the panel.`, 502);
    return assertCapacity(fixed, memoryMb, diskMb);
  }

  const candidates = pool
    .map((n: any) => ({
      node: n,
      freeMem: Number(n.memory_total ?? 0) - Number(n.memory_allocated ?? 0),
      freeDisk: Number(n.disk_total ?? 0) - Number(n.disk_allocated ?? 0),
    }))
    .filter((c: any) => c.freeMem >= memoryMb && c.freeDisk >= diskMb)
    .sort((a: any, b: any) => b.freeMem - a.freeMem);

  if (!candidates.length) {
    throw new ApiError(
      `No node currently has ${memoryMb} MB RAM and ${diskMb} MB disk free. Reduce the allocation or free capacity.`,
      409,
    );
  }
  return candidates[0].node;
}

function assertCapacity(node: any, memoryMb: number, diskMb: number) {
  const freeMem = Number(node.memory_total ?? 0) - Number(node.memory_allocated ?? 0);
  const freeDisk = Number(node.disk_total ?? 0) - Number(node.disk_allocated ?? 0);
  if (freeMem < memoryMb || freeDisk < diskMb) {
    throw new ApiError(`Node "${node.name ?? node.id}" does not have enough free capacity for this allocation.`, 409);
  }
  return node;
}

async function pickAllocation(cfg: ProvisionConfig, nodeId: number | string): Promise<number> {
  const raw = await panelFetch<any[]>(cfg, `/api/application/nodes/${nodeId}/allocations`, "GET");
  const list = (Array.isArray(raw) ? raw : (raw as any)?.data ?? []).map((a: any) => a.attributes ?? a);
  const free = list.find((a: any) => !a.assigned && (!cfg.allocationPort || a.port === cfg.allocationPort)) ?? list.find((a: any) => !a.assigned);
  if (!free) throw new ApiError("No free IP:port allocation is available on the selected node.", 409);
  return Number(free.id);
}

/* --------------------------------- users ---------------------------------- */
async function ensurePanelUser(cfg: ProvisionConfig, email: string, name: string): Promise<number> {
  const username = email.split("@")[0].replace(/[^A-Za-z0-9_]/g, "_").slice(0, 24).toLowerCase();
  const first = (name.split(" ")[0] || "demo").slice(0, 40);
  const last = (name.split(" ").slice(1).join(" ") || "user").slice(0, 40);
  try {
    const created = await panelFetch<any>(cfg, "/api/application/users", "POST", {
      external_id: `demo_${email}`.slice(0, 60),
      username,
      email,
      first_name: first,
      last_name: last,
      password: `Dm${randomHex(18)}!`,
    });
    const attrs = created?.attributes ?? created;
    return Number(attrs.id);
  } catch (e: any) {
    if (!/422|409|already/i.test(String(e?.message ?? ""))) throw e;
    const existing = await panelFetch<any>(cfg, `/api/application/users?filter[email]=${encodeURIComponent(email)}`, "GET");
    const list = (existing as any)?.data ?? (Array.isArray(existing) ? existing : []);
    const match = list.map((u: any) => u.attributes ?? u).find((u: any) => u.email === email);
    if (!match) throw e;
    return Number(match.id);
  }
}

function randomHex(len: number) {
  let out = "";
  for (let i = 0; i < len; i++) out += Math.floor(Math.random() * 16).toString(16);
  return out;
}

/* ------------------------------- lifecycle -------------------------------- */
export type ProvisionInput = {
  reference: string;
  name: string;
  email: string;
  ownerName: string;
  ramMb: number;
  cpuPercent: number;
  diskMb: number;
  startup: string;
  dockerImage?: string;
  environment?: Record<string, string>;
};

/** Creates a real server on the panel: capacity check → allocation → create. */
export async function createDemoServer(input: ProvisionInput): Promise<{ externalId: string; url: string; nodeId: number }> {
  const cfg = await getProvisionConfig();
  if (!isConfiguredStatic(cfg)) {
    throw new ApiError(
      "Demo provisioning is unavailable: no hosting backend is configured. An administrator must add panel credentials first.",
      503,
    );
  }

  const node = await pickNode(cfg, input.ramMb, input.diskMb);
  const allocationId = await pickAllocation(cfg, node.id);
  const userId = await ensurePanelUser(cfg, input.email, input.ownerName);

  const env: Record<string, string> = {
    ...(cfg.environment ?? {}),
    ...(input.environment ?? {}),
    SERVER_MEMORY: String(input.ramMb),
  };

  const created = await panelFetch<any>(cfg, "/api/application/servers", "POST", {
    name: input.name.slice(0, 60),
    user: userId,
    egg: cfg.defaultEgg || 1,
    docker_image: input.dockerImage || cfg.defaultDockerImage || undefined,
    startup: input.startup.replace(/\{\{SERVER_MEMORY\}\}/g, String(input.ramMb)),
    environment: env,
    limits: {
      memory: input.ramMb,
      swap: 0,
      disk: input.diskMb,
      io: 500,
      cpu: input.cpuPercent,
      threads: null,
    },
    feature_limits: { databases: 1, allocations: 1, backups: 0 },
    allocation: { default: allocationId, additional: [] },
    start_on_completion: true,
    deploy: { locations: [], dedicated_ip: false, port_range: [] },
  });

  const attrs = created?.attributes ?? created;
  if (!attrs?.id) throw new ApiError("The panel accepted the request but returned no server identifier.", 502);

  return {
    externalId: String(attrs.uuid ?? attrs.id),
    url: String(attrs.identifier ? `${cfg.baseUrl.replace(/\/+$/, "")}/server/${attrs.identifier}` : cfg.baseUrl),
    nodeId: Number(node.id),
  };
}

export async function getExternalServer(externalId: string) {
  const cfg = await getProvisionConfig();
  if (!isConfiguredStatic(cfg)) throw new ApiError("Provisioning backend is not configured.", 503);
  const data = await panelFetch<any>(cfg, `/api/application/servers/${externalId}`, "GET");
  const attrs = data?.attributes ?? data;
  return {
    status: String(attrs?.status ?? "unknown"),
    name: String(attrs?.name ?? ""),
    identifier: String(attrs?.identifier ?? externalId),
    limits: attrs?.limits ?? null,
    node: attrs?.node ?? null,
  };
}

async function power(externalId: string, signal: "start" | "stop" | "restart") {
  const cfg = await getProvisionConfig();
  if (!isConfiguredStatic(cfg)) throw new ApiError("Provisioning backend is not configured.", 503);
  await panelFetch(cfg, `/api/client/servers/${externalId}/power`, "POST", { signal }, true);
}

export const startExternalServer = (id: string) => power(id, "start");
export const stopExternalServer = (id: string) => power(id, "stop");
export const restartExternalServer = (id: string) => power(id, "restart");

export async function deleteExternalServer(externalId: string) {
  const cfg = await getProvisionConfig();
  if (!isConfiguredStatic(cfg)) throw new ApiError("Provisioning backend is not configured.", 503);
  try {
    await panelFetch(cfg, `/api/application/servers/${externalId}`, "DELETE");
  } catch (e: any) {
    if (!/404/i.test(String(e?.message ?? ""))) throw e;
  }
}

/** Applies new resource limits to an existing server (admin reallocation). */
export async function updateServerLimits(
  externalId: string,
  limits: { memory?: number; cpu?: number; disk?: number },
) {
  const cfg = await getProvisionConfig();
  if (!isConfiguredStatic(cfg)) throw new ApiError("Provisioning backend is not configured.", 503);
  const current = await panelFetch<any>(cfg, `/api/application/servers/${externalId}`, "GET");
  const attrs = current?.attributes ?? current;
  const payload: any = { limits: { ...(attrs?.limits ?? {}), ...limits } };
  if (limits.memory !== undefined) payload.startup = String(attrs?.startup ?? "").replace(/-Xmx\d+M/g, `-Xmx${limits.memory}M`);
  const updated = await panelFetch<any>(cfg, `/api/application/servers/${externalId}`, "PATCH", payload);
  const after = updated?.attributes ?? updated;
  return { limits: after?.limits ?? payload.limits };
}
