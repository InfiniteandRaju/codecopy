import { getSettings, type Json } from "@/lib/data";

export type Destination = {
  mode: "redirect" | "internal" | "manual";
  url: string | null;
  openIn: "same" | "new";
  buttonText: string;
  /** Human-readable target used by the admin preview. */
  preview: string;
};

export type BillingSettings = { canonicalDomain: string; pathPrefix: string };

export function billingDefaults(settings?: Json): BillingSettings {
  const b = (settings?.billing ?? {}) as BillingSettings;
  return {
    canonicalDomain: (b.canonicalDomain || process.env.NEXT_PUBLIC_BASE_URL || "").replace(/\/+$/, ""),
    pathPrefix: normalizePrefix(b.pathPrefix || "/order/"),
  };
}

export function normalizePrefix(prefix: unknown): string {
  let p = String(prefix ?? "/order/").trim();
  if (!p.startsWith("/")) p = "/" + p;
  p = p.replace(/\/{2,}/g, "/");
  if (!p.endsWith("/")) p += "/";
  return p.slice(0, 60);
}

/** Auto-generated per-plan path: /order/<slug> */
export function defaultPath(prefix: string, slug: string): string {
  return `${normalizePrefix(prefix)}${String(slug).toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "")}`;
}

/**
 * Validates a relative redirect path. Rejects absolute URLs, protocol-relative
 * paths, traversal and control characters — this is the open-redirect guard.
 */
export function normalizePath(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  let p = raw.trim();
  if (!p) return null;
  // No scheme, no protocol-relative, no backslash tricks.
  if (/^[a-z][a-z0-9+.-]*:/i.test(p)) return null;
  if (p.startsWith("//") || p.includes("\\")) return null;
  if (!p.startsWith("/")) p = "/" + p;
  p = p.replace(/\/{2,}/g, "/");
  if (p.includes("..")) return null;
  if (/[\\\s<>"'`]/.test(p)) return null;
  if (p.length > 200) return null;
  // Strip trailing slash (except the root) so duplicates collapse consistently.
  if (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1);
  if (!/^\/[A-Za-z0-9/_.-]*$/.test(p)) return null;
  return p;
}

export function joinDomain(domain: string, path: string): string {
  const base = String(domain ?? "").replace(/\/+$/, "");
  if (!base) return path; // relative fallback — stays on the current origin
  return `${base}${path}`;
}

type ConfigLike = {
  billingType?: string;
  redirectMode?: string;
  destinationUrl?: string | null;
  redirectPath?: string | null;
  urlParams?: Json;
  openIn?: string;
  buttonText?: string | null;
  orderingEnabled?: boolean;
  trustedHosts?: string | null;
};

const PASSTHROUGH = ["plan", "plan_id", "plan_slug", "billing_cycle", "cycle", "location", "coupon"];

function withParams(base: string, config: ConfigLike, plan: any, params: Record<string, string>): string | null {
  try {
    const url = new URL(base, base.startsWith("http") ? undefined : "http://relative.invalid");
    const declared = (config.urlParams ?? {}) as Record<string, string>;
    for (const [k, v] of Object.entries({ ...declared, ...params })) {
      if (!k || v == null || v === "") continue;
      if (!/^[\w-]{1,40}$/.test(k)) continue;
      url.searchParams.set(k.slice(0, 40), String(v).slice(0, 120));
    }
    if (plan?.id) url.searchParams.set("plan_id", plan.id);
    if (plan?.slug) url.searchParams.set("plan_slug", plan.slug);
    if (base.startsWith("http")) return url.toString();
    return `${url.pathname}${url.search}`;
  } catch {
    return null;
  }
}

/**
 * Resolves where a plan's Order Now button sends the customer.
 *  - redirectMode "external" → validated absolute URL (trusted-host enforced upstream)
 *  - redirectMode "internal" → canonical domain + this plan's own stored path
 *  - ordering disabled       → manual flow
 */
export function resolveDestination(
  config: ConfigLike | null,
  plan: { id?: string; slug?: string },
  params: Record<string, string> = {},
  settings?: Json,
): Destination {
  const buttonText = config?.buttonText || "Order Now";
  const openIn: "same" | "new" = config?.openIn === "new" ? "new" : "same";
  const { canonicalDomain, pathPrefix } = billingDefaults(settings);

  if (!config || config.orderingEnabled === false) {
    return { mode: "manual", url: null, openIn, buttonText: "Contact sales", preview: "Manual order flow" };
  }

  const mode = config.redirectMode === "external" || (config.redirectPath ? config.redirectMode === "external" : config.billingType === "external");

  if (mode) {
    const base = config.destinationUrl;
    if (!base) return { mode: "manual", url: null, openIn, buttonText, preview: "No external destination set" };
    const built = withParams(base, config, plan, params);
    return { mode: built ? "redirect" : "manual", url: built, openIn, buttonText, preview: built ?? "Invalid URL" };
  }

  if (config.billingType === "manual" && !config.redirectPath) {
    return { mode: "manual", url: null, openIn, buttonText, preview: "Manual order flow" };
  }

  // Internal path redirect — path is per-plan, domain comes from settings.
  const path = normalizePath(config.redirectPath) ?? defaultPath(pathPrefix, plan.slug ?? "plan");
  const target = withParams(path, config, plan, params) ?? path;
  const absolute = joinDomain(canonicalDomain, target);
  return { mode: "redirect", url: absolute, openIn, buttonText, preview: absolute };
}

/** Back-compat wrapper used by the existing storefront code. */
export function resolveBilling(config: any, plan: any, params: Record<string, string>, settings?: Json): Destination {
  return resolveDestination(config, plan, params, settings);
}

export async function getBillingSettings(): Promise<BillingSettings> {
  const s = await getSettings().catch(() => ({}) as Json);
  return billingDefaults(s);
}
