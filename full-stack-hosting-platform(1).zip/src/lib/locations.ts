import { db } from "@/db";
import { serverLocations } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { measureEndpoint } from "@/lib/latency";

export type LocationStatus = "online" | "offline" | "timeout" | "unavailable";

export type LocationMeasurement = {
  id: string;
  name: string;
  city: string | null;
  country: string | null;
  code: string | null;
  tier: string | null;
  endpoint: string | null;
  active: boolean;
  ms: number | null;
  status: LocationStatus;
  httpStatus: number | null;
  error: string | null;
  checkedAt: string;
  source: "server" | null;
};

function classify(r: { ok: boolean; ms: number | null; error: string | null }): { status: LocationStatus; ms: number | null } {
  if (!r.ms) return { status: r.error === "timeout" ? "timeout" : "unavailable", ms: null };
  return { status: r.ok ? "online" : "offline", ms: r.ms };
}

/**
 * Measures every configured location endpoint with a real network request.
 * Locations without an endpoint (or that cannot be reached) report
 * status "unavailable" and ms:null — no value is ever invented.
 */
export async function measureAllLocations(): Promise<LocationMeasurement[]> {
  const rows = await db
    .select()
    .from(serverLocations)
    .where(eq(serverLocations.active, true))
    .orderBy(asc(serverLocations.sortOrder), asc(serverLocations.name));

  const checkedAt = new Date().toISOString();
  return Promise.all(
    rows.map(async (loc): Promise<LocationMeasurement> => {
      const base = {
        id: loc.id,
        name: loc.name,
        city: loc.city,
        country: loc.country,
        code: loc.code,
        tier: loc.tier,
        endpoint: loc.endpoint,
        active: loc.active,
        checkedAt,
        source: null as "server" | null,
      };
      if (!loc.endpoint) {
        return { ...base, ms: null, status: "unavailable", httpStatus: null, error: "No measurement endpoint configured" };
      }
      const r = await measureEndpoint(loc.endpoint, loc.timeoutMs || 4000);
      const { status, ms } = classify(r);
      return { ...base, ms, status, httpStatus: r.status, error: r.error, source: "server" };
    }),
  );
}
