import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";

/**
 * AES-256-GCM encryption for credentials held in system_config.
 * Key comes from APP_ENCRYPTION_KEY, falling back to a digest of AUTH_SECRET.
 * Plaintext never leaves the server and is never returned by any route.
 */
function key(): Buffer {
  const raw = process.env.APP_ENCRYPTION_KEY || process.env.AUTH_SECRET || "obsidian-node-dev-secret";
  return createHash("sha256").update(raw).digest();
}

export function encryptSecret(plain: string): string {
  if (!plain) return "";
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

export function decryptSecret(stored: string | null | undefined): string {
  if (!stored) return "";
  if (!String(stored).startsWith("enc:v1:")) return String(stored); // pre-encryption value
  try {
    const [, , ivB64, tagB64, dataB64] = String(stored).split(":");
    const decipher = createDecipheriv("aes-256-gcm", key(), Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

/** Replaces secret fields with a mask so they can never reach a browser. */
export function maskSecrets<T extends Record<string, any>>(obj: T, fields: string[]): T {
  const out: any = { ...obj };
  for (const f of fields) {
    if (out[f] === undefined) continue;
    out[f] = out[f] ? "••••••••" : "";
    out[`${f}_set`] = Boolean(obj[f]);
  }
  return out;
}
