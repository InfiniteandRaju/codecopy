import { db } from "@/db";
import {
  categories,
  tags,
  products,
  productTags,
  billingCycles,
  billingConfigurations,
  settings,
  homepageSections,
  testimonials,
  faqs,
  serverLocations,
} from "@/db/schema";
import { and, asc, desc, eq, gte, lte, ilike, or, sql, inArray } from "drizzle-orm";
import { resolveDestination, type Destination } from "@/lib/redirect";

export type Json = Record<string, any>;

export const DEFAULT_SETTINGS: Json = {
  siteName: "Obsidian Node",
  tagline: "Bare-metal performance. Instant deployment.",
  logoText: "OBSIDIAN",
  logoMark: "OBSIDIAN NODE",
  contactEmail: "sales@obsidiannode.io",
  supportDiscord: "https://discord.gg/obsidiannode",
  currency: "INR",
  currencySymbol: "₹",
  taxLabel: "GST",
  taxRate: 18,
  maintenanceMode: false,
  maintenanceMessage: "We are performing scheduled maintenance. Orders are temporarily paused.",
  theme: { primary: "#FF6B18", accent: "#39D7E6", surface: "#07090E" },
  social: {
    twitter: "https://x.com/obsidiannode",
    github: "https://github.com/obsidiannode",
    discord: "https://discord.gg/obsidiannode",
    youtube: "https://youtube.com/@obsidiannode",
  },
  seo: {
    title: "Obsidian Node — Game, VPS & Cloud Hosting",
    description:
      "High-frequency bare-metal game servers, NVMe VPS and DDoS-protected infrastructure deployed in 12 regions with instant setup.",
    ogImage: "/images/hero-aisle.jpg",
  },
  footer: {
    blurb:
      "Independent infrastructure provider operating high-frequency compute and DDoS-filtered network capacity across 12 regions.",
    legal: "© Obsidian Node Infrastructure Pvt. Ltd. All rights reserved.",
  },
  heroMetrics: { uptime: "99.99", nodes: 4128, blocked: "1.4M" },
  /** Centralised branding — read by Nav, Footer, login, both dashboards and the favicon. */
  branding: {
    siteName: "",
    wordmark: "",
    submark: "NODE · INFRA",
    logo: null,
    logoLight: null,
    logoDark: null,
    favicon: null,
    logoWidth: 132,
    logoHeight: 34,
  },
  /** Canonical domain + per-plan redirect path defaults. */
  billing: { canonicalDomain: "", pathPrefix: "/order/", trustedHosts: "" },
  plansSection: {
    title: "Hosting plans, priced individually",
    description: "Every card below is a real product from the catalogue with its own price, specifications and billing cycles.",
    mode: "category",
    limit: 12,
    perCategory: 3,
    showSpecs: true,
    showTags: true,
  },
};

export const DEFAULT_HOMEPAGE: Record<string, Json> = {
  hero: {
    eyebrow: "TRANSPARENT PRICING · 12 REGIONS · 40 Tbit/s MITIGATION",
    title: "Power Your\nNext Project",
    description:
      "High-performance hosting. Transparent pricing. No compromises. Every plan, every price and every specification below comes straight from the catalogue.",
    primaryCta: { label: "Explore Pricing", href: "/pricing" },
    secondaryCta: { label: "Try Free Server", href: "/free-server" },
    image: "/images/hero-aisle.jpg",
  },
  whyUs: {
    title: "Built by operators, for operators",
    items: [
      { icon: "zap", title: "60-second deployment", body: "Automated provisioning on every node. No queue, no ticket, no waiting room." },
      { icon: "shield", title: "40 Tbit/s DDoS filtering", body: "Layer 3/4/7 mitigation always on, tuned per game protocol at the edge." },
      { icon: "cpu", title: "Dedicated, not oversold", body: "Every vCPU is pinned to a physical core. No noisy-neighbour roulette." },
      { icon: "headphones", title: "Engineers on support", body: "Human replies in under 15 minutes, 24/7 — not scripted tier-one bots." },
    ],
  },
  locations: {
    title: "Twelve regions. One network.",
    description: "Anycast-protected edge with private backbone interconnect between core sites.",
    // Latency is intentionally absent: values come from real measurements taken
    // against the endpoints configured in Admin -> Server locations.
    items: [],
  },
  infrastructure: {
    title: "Infrastructure specifications",
    description: "The hardware every Obsidian Node plan is scheduled onto.",
    image: "/images/rack-macro.jpg",
    items: [
      { label: "Compute", value: "AMD Ryzen 9 7950X · EPYC 9354" },
      { label: "Storage", value: "Samsung PM9A3 Gen4 NVMe RAID-10" },
      { label: "Network", value: "2 × 25 Gbit uplink, 1 Gbit fair-use per instance" },
      { label: "Mitigation", value: "40 Tbit/s anycast scrubbing, sub-second signature" },
      { label: "Power", value: "N+1 UPS · dual utility feeds · 99.99% SLA" },
      { label: "Backups", value: "Off-site snapshots every 6h, 14-day retention" },
    ],
  },
  ddos: {
    title: "DDoS protection, on by default",
    description:
      "Every IP we announce sits behind always-on scrubbing. Game traffic is fingerprinted per protocol so legitimate players stay connected while volumetric floods are dropped at the edge.",
    image: "/images/fiber-splash.jpg",
    stats: [
      { value: "40 Tbit/s", label: "Mitigation capacity" },
      { value: "< 250 ms", label: "Detection to filter" },
      { value: "L3 · L4 · L7", label: "Attack layers" },
      { value: "0", label: "Cost to you" },
    ],
  },
  support: {
    title: "Talk to an engineer",
    description: "Sales, migrations and incident response — the same team runs the network.",
    image: "/images/noc-console.jpg",
    email: "support@obsidiannode.io",
    discord: "https://discord.gg/obsidiannode",
    responseTime: "Median first response: 11 minutes",
  },
};

async function readTable<T>(table: any, defaults: Record<string, any>): Promise<Record<string, any>> {
  const rows: T[] = await db.select().from(table);
  const out: Record<string, any> = { ...defaults };
  for (const row of rows as any[]) {
    if (row.key) out[row.key] = { ...(defaults[row.key] ?? {}), ...(row.value ?? {}) };
  }
  return out;
}

export async function getSettings(): Promise<Record<string, any>> {
  return readTable(settings, DEFAULT_SETTINGS);
}

export async function getHomepage() {
  const [sections, testimonialRows, faqRows, locationRows] = await Promise.all([
    readTable(homepageSections, DEFAULT_HOMEPAGE),
    db.select().from(testimonials).orderBy(asc(testimonials.sortOrder)),
    db.select().from(faqs).orderBy(asc(faqs.sortOrder)),
    db.select().from(serverLocations).orderBy(asc(serverLocations.sortOrder), asc(serverLocations.name)),
  ]);
  // The locations section is driven by the server_locations table (the same rows
  // latency is measured against) — never by static numbers in JSON.
  if (locationRows.length) {
    sections.locations = {
      ...sections.locations,
      items: locationRows
        .filter((l) => l.active)
        .map((l) => ({
          id: l.id,
          city: l.city || l.name,
          code: l.code,
          country: l.country,
          tier: l.tier,
          endpoint: l.endpoint,
        })),
    };
  }
  return {
    sections,
    testimonials: testimonialRows.filter((t: any) => t.active),
    faqs: faqRows.filter((f: any) => f.active),
  };
}

/* ------------------------------- categories ------------------------------- */
export type CategoryNode = any;

export async function getCategoryTree(includeInactive = false) {
  const rows = await db
    .select()
    .from(categories)
    .orderBy(asc(categories.sortOrder), asc(categories.name));
  const list = includeInactive ? rows : rows.filter((c) => c.active);
  const map = new Map<string, CategoryNode>();
  list.forEach((c) => map.set(c.id, { ...c, children: [] }));
  const roots: CategoryNode[] = [];
  for (const c of list) {
    const node = map.get(c.id)!;
    const parent = c.parentId ? map.get(c.parentId) : null;
    if (parent) parent.children.push(node);
    else roots.push(node);
  }
  return roots;
}

export async function getFlatCategories(includeInactive = false) {
  const rows = await db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name));
  return includeInactive ? rows : rows.filter((c) => c.active);
}

export async function getAllTags() {
  return db.select().from(tags).orderBy(asc(tags.sortOrder), asc(tags.name));
}

/* --------------------------------- plans ---------------------------------- */
export async function attachCycles(productIds: string[]) {
  if (!productIds.length) return new Map<string, any[]>();
  const cycles = await db
    .select()
    .from(billingCycles)
    .where(inArray(billingCycles.productId, productIds))
    .orderBy(asc(billingCycles.sortOrder));
  const map = new Map<string, any[]>();
  for (const c of cycles) {
    if (!c.active) continue;
    const arr = map.get(c.productId) ?? [];
    arr.push(c);
    map.set(c.productId, arr);
  }
  return map;
}

export async function attachTags(productIds: string[]) {
  if (!productIds.length) return new Map<string, any[]>();
  const rows = await db
    .select({ productId: productTags.productId, tag: tags })
    .from(productTags)
    .innerJoin(tags, eq(productTags.tagId, tags.id))
    .where(inArray(productTags.productId, productIds));
  const map = new Map<string, any[]>();
  for (const r of rows) {
    const arr = map.get(r.productId) ?? [];
    arr.push(r.tag);
    map.set(r.productId, arr);
  }
  return map;
}

export type PlanFilters = {
  category?: string;
  tag?: string;
  search?: string;
  sort?: string;
  minPrice?: number;
  maxPrice?: number;
  featured?: boolean;
  discounted?: boolean;
};

export async function listPlans(filters: PlanFilters = {}) {
  const conditions = [eq(products.active, true), eq(products.archived, false)];
  if (filters.search) {
    const q = `%${filters.search}%`;
    conditions.push(or(ilike(products.name, q), ilike(products.shortDescription, q))!);
  }
  if (filters.featured) conditions.push(eq(products.featured, true));

  let rows = await db
    .select({ product: products, categorySlug: categories.slug, categoryId: products.categoryId })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(and(...conditions))
    .orderBy(asc(products.sortOrder), asc(products.name));

  if (filters.category) {
    const catRows = await db.select().from(categories);
    const bySlug = new Map(catRows.map((c) => [c.slug, c]));
    const byId = new Map(catRows.map((c) => [c.id, c]));
    const target = bySlug.get(filters.category);
    if (target) {
      const descendantIds = new Set<string>([target.id]);
      let grew = true;
      while (grew) {
        grew = false;
        for (const c of catRows) {
          if (c.parentId && descendantIds.has(c.parentId) && !descendantIds.has(c.id)) {
            descendantIds.add(c.id);
            grew = true;
          }
        }
      }
      rows = rows.filter((r) => r.categoryId && descendantIds.has(r.categoryId));
    } else {
      rows = [];
    }
  }

  const ids = rows.map((r) => r.product.id);
  const [cycleMap, tagMap] = await Promise.all([attachCycles(ids), attachTags(ids)]);

  let plans = rows.map((r) => ({
    ...r.product,
    categorySlug: r.categorySlug,
    cycles: cycleMap.get(r.product.id) ?? [],
    tags: (tagMap.get(r.product.id) ?? []).filter((t) => t.active),
  }));

  if (filters.tag) plans = plans.filter((p) => p.tags.some((t) => t.slug === filters.tag));

  const priceOf = (p: any) => {
    const active = p.cycles.length ? p.cycles : [];
    const monthly = active.find((c: any) => c.key === "monthly") ?? active[0];
    return monthly ? Number(monthly.price) : 0;
  };

  if (typeof filters.minPrice === "number") plans = plans.filter((p) => priceOf(p) >= filters.minPrice!);
  if (typeof filters.maxPrice === "number") plans = plans.filter((p) => priceOf(p) <= filters.maxPrice!);
  if (filters.discounted) plans = plans.filter((p) => p.cycles.some((c: any) => c.compareAt && Number(c.compareAt) > Number(c.price)));

  switch (filters.sort) {
    case "price_asc":
      plans.sort((a, b) => priceOf(a) - priceOf(b));
      break;
    case "price_desc":
      plans.sort((a, b) => priceOf(b) - priceOf(a));
      break;
    case "popular":
      plans.sort((a, b) => b.popularity - a.popularity);
      break;
    case "name":
      plans.sort((a, b) => a.name.localeCompare(b.name));
      break;
    default:
      break;
  }
  return plans;
}

export type PlanSectionConfig = {
  title: string;
  description: string;
  mode: "category" | "featured" | "manual";
  limit: number;
  perCategory: number;
  showSpecs: boolean;
  showTags: boolean;
  manualOrder: string[];
  categoryOrder: string[];
  popularLimit: number;
  pricingSections: { id: string; title: string; categorySlug: string; limit: number; enabled: boolean }[];
};

export const DEFAULT_PLAN_SECTION: PlanSectionConfig = {
  title: "Hosting plans, priced individually",
  description:
    "Real products from the catalogue — each card shows its own monthly price, specifications, promotional tags and working order button.",
  mode: "category",
  limit: 12,
  perCategory: 3,
  showSpecs: true,
  showTags: true,
  manualOrder: [],
  categoryOrder: [],
  popularLimit: 6,
  pricingSections: [
    { id: "game", title: "Game hosting pricing", categorySlug: "game-hosting", limit: 4, enabled: true },
    { id: "bot", title: "Bot hosting pricing", categorySlug: "bot-hosting", limit: 4, enabled: true },
    { id: "vps", title: "VPS hosting pricing", categorySlug: "vps-hosting", limit: 4, enabled: true },
    { id: "web", title: "Web hosting pricing", categorySlug: "web-hosting", limit: 4, enabled: true },
  ],
};

/**
 * Homepage pricing data: actual plans with actual prices, grouped by their
 * top-level category. Selection, ordering and counts all come from the
 * admin-editable `plansSection` homepage section.
 */
export async function getHomepagePlans(): Promise<{ config: PlanSectionConfig; groups: { id: string; name: string; slug: string; plans: any[] }[]; popular: any[]; sections: { id: string; title: string; slug: string; plans: any[] }[]; total: number }> {
  const rows = await db.select().from(homepageSections).where(eq(homepageSections.key, "plansSection")).limit(1);
  const config: PlanSectionConfig = { ...DEFAULT_PLAN_SECTION, ...((rows[0]?.value as any) ?? {}) };
  const all = await listPlans({});
  const catRows = await db.select().from(categories);
  const byId = new Map(catRows.map((c) => [c.id, c]));
  const rootOf = (plan: any): { id: string; name: string; slug: string } => {
    let node = plan.categoryId ? byId.get(plan.categoryId) : null;
    if (!node) return { id: "other", name: "Other services", slug: "" };
    const seen = new Set<string>();
    while (node?.parentId && byId.has(node.parentId) && !seen.has(node.parentId)) {
      seen.add(node.parentId);
      node = byId.get(node.parentId)!;
    }
    return { id: node!.id, name: node!.name, slug: node!.slug };
  };

  const limit = Math.min(48, Math.max(1, Number(config.limit) || 12));
  let groups: { id: string; name: string; slug: string; plans: any[] }[] = [];

  if (config.mode === "manual") {
    const order = (config.manualOrder ?? []).filter((id) => id);
    const picked = order
      .map((id) => all.find((p: any) => p.id === id))
      .filter(Boolean)
      .slice(0, limit);
    groups = [{ id: "manual", name: config.title, slug: "", plans: picked }];
  } else if (config.mode === "featured") {
    const picked = all.filter((p: any) => p.featured || p.bestSeller).slice(0, limit);
    groups = [{ id: "featured", name: "Featured plans", slug: "", plans: picked.length ? picked : all.slice(0, limit) }];
  } else {
    const map = new Map<string, { id: string; name: string; slug: string; plans: any[] }>();
    for (const plan of all) {
      const root = rootOf(plan);
      const entry = map.get(root.id) ?? { ...root, plans: [] };
      entry.plans.push(plan);
      map.set(root.id, entry);
    }
    const perCategory = Math.min(12, Math.max(1, Number(config.perCategory) || 3));
    const wanted = config.categoryOrder ?? [];
    const list = [...map.values()].filter((g) => g.plans.length > 0);
    list.sort((a, b) => {
      const ia = wanted.indexOf(a.id);
      const ib = wanted.indexOf(b.id);
      if (ia !== -1 || ib !== -1) return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
      return a.name.localeCompare(b.name);
    });
    groups = list.map((g) => ({ ...g, plans: g.plans.slice(0, perCategory) })).slice(0, Math.max(1, Math.ceil(limit / Math.max(1, perCategory))));
  }

  // Popular plans (by recorded demand) and per-category pricing bands.
  const popular = [...all]
    .sort((a: any, b: any) => b.popularity - a.popularity)
    .slice(0, Math.min(24, Number(config.popularLimit) || 6));

  const rootBySlug = new Map<string, string>();
  for (const cat of catRows) rootBySlug.set(cat.slug, cat.id);
  const sections = (config.pricingSections ?? [])
    .filter((sec) => sec.enabled !== false && sec.categorySlug)
    .map((sec) => {
      const targetId = rootBySlug.get(sec.categorySlug);
      const list = targetId ? all.filter((p: any) => rootOf(p).id === targetId) : [];
      const limit = Math.min(12, Math.max(1, Number(sec.limit) || 3));
      return { id: sec.id, title: sec.title, slug: sec.categorySlug, plans: list.slice(0, limit) };
    })
    .filter((sec) => sec.plans.length > 0);

  const total = groups.reduce((n, g) => n + g.plans.length, 0);
  return { config, groups, popular, sections, total };
}

/** Category tree annotated with live plan counts (including nested children). */
export async function getCategoryTreeWithCounts() {
  const [allCats, prods] = await Promise.all([
    db.select().from(categories),
    db
      .select({ id: products.id, categoryId: products.categoryId })
      .from(products)
      .where(and(eq(products.active, true), eq(products.archived, false))),
  ]);
  const childrenOf = new Map<string | null, string[]>();
  allCats.forEach((c) => {
    const list = childrenOf.get(c.parentId ?? null) ?? [];
    list.push(c.id);
    childrenOf.set(c.parentId ?? null, list);
  });
  const own = new Map<string, number>();
  prods.forEach((p) => {
    if (!p.categoryId) return;
    own.set(p.categoryId, (own.get(p.categoryId) ?? 0) + 1);
  });
  const total = (id: string, seen = new Set<string>()): number => {
    if (seen.has(id)) return 0;
    seen.add(id);
    let n = own.get(id) ?? 0;
    for (const child of childrenOf.get(id) ?? []) n += total(child, seen);
    return n;
  };
  const build = (parentId: string | null): any[] =>
    (childrenOf.get(parentId) ?? [])
      .map((id) => allCats.find((c) => c.id === id)!)
      .filter((c) => c && (includeInactive ? true : c.active))
      .sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name))
      .map((c) => ({
        ...c,
        planCount: total(c.id),
        ownPlanCount: own.get(c.id) ?? 0,
        children: build(c.id),
      }));
  const includeInactive = false;
  return build(null);
}

export async function getPlan(slug: string) {
  const rows = await db
    .select({ product: products, category: categories })
    .from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(eq(products.slug, slug))
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  const [cycles, planTags, config] = await Promise.all([
    db.select().from(billingCycles).where(eq(billingCycles.productId, row.product.id)).orderBy(asc(billingCycles.sortOrder)),
    db
      .select({ tag: tags })
      .from(productTags)
      .innerJoin(tags, eq(productTags.tagId, tags.id))
      .where(eq(productTags.productId, row.product.id)),
    db.select().from(billingConfigurations).where(eq(billingConfigurations.productId, row.product.id)).limit(1),
  ]);
  return {
    ...row.product,
    category: row.category,
    cycles: cycles.filter((c) => c.active),
    tags: planTags.map((t) => t.tag).filter((t) => t.active),
    billing: config[0] ?? null,
  };
}

/* ------------------------------- checkout --------------------------------- */
export type BillingResolution = {
  mode: "redirect" | "internal" | "manual";
  url: string | null;
  openIn: "same" | "new";
  buttonText: string;
};

/**
 * Resolves where an order button must send the customer. Price is always
 * computed server-side from billing_cycles — never from the browser.
 */
export function resolveBilling(config: any, plan: any, params: Record<string, string>, settings?: Json): BillingResolution {
  const resolved: Destination = resolveDestination(config, plan, params, settings);
  return { mode: resolved.mode, url: resolved.url, openIn: resolved.openIn, buttonText: resolved.buttonText };
}

export function money(amount: number | string, symbol = "₹") {
  const n = typeof amount === "string" ? Number(amount) : amount;
  return `${symbol}${n.toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}
