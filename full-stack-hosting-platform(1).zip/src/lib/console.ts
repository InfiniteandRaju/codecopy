import { db } from "@/db";
import { systemConfig } from "@/db/schema";
import { eq } from "drizzle-orm";
import { encryptSecret, decryptSecret } from "@/lib/secrets";
import { ApiError } from "@/lib/api";

export type ConsoleConfig = {
  enabled: boolean;
  /** Base URL of the authorised server-management API, e.g. https://panel.example.com */
  baseUrl: string;
  /** Bearer token for that API — encrypted at rest, never returned. */
  token: string;
  serversPath: string;
  commandPath: string;
  logPath: string;
  resourcePath: string;
  timeoutMs: number;
};

const DEFAULTS: ConsoleConfig = {
  enabled: false,
  baseUrl: "",
  token: "",
  serversPath: "/api/client/servers",
  commandPath: "/command",
  logPath: "/logs",
  resourcePath: "/resources",
  timeoutMs: 8000,
};

const SECRET_FIELDS = ["token"];

export async function getConsoleConfig(): Promise<ConsoleConfig & { configured: boolean }> {
  const rows = await db.select().from(systemConfig).where(eq(systemConfig.key, "console")).limit(1);
  const stored = (rows[0]?.value ?? {}) as Partial<ConsoleConfig>;
  const cfg: ConsoleConfig = { ...DEFAULTS, ...stored, token: decryptSecret(stored.token as string) };
  return { ...cfg, configured: Boolean(cfg.baseUrl && cfg.token && cfg.enabled) };
}

/** Persists console credentials with the token encrypted. */
export async function saveConsoleConfig(input: Partial<ConsoleConfig>, actorId?: string | null) {
  const current = await getConsoleConfig();
  const next: ConsoleConfig = { ...current, ...input } as ConsoleConfig;
  if (input.token === undefined) next.token = current.token;
  const stored: Record<string, any> = { ...next, token: next.token ? encryptSecret(next.token) : "" };
  await db
    .insert(systemConfig)
    .values({ key: "console", value: stored, updatedBy: actorId ?? null, updatedAt: new Date() })
    .onConflictDoUpdate({ target: systemConfig.key, set: { value: stored, updatedBy: actorId ?? null, updatedAt: new Date() } });
  return { ...next, token: undefined } as any;
}

/** Status for the console UI — truthful about what is and is not connected. */
export async function consoleStatus() {
  const cfg = await getConsoleConfig();
  if (!cfg.configured) {
    return {
      connected: false,
      configured: false,
      baseUrl: cfg.baseUrl || null,
      message:
        "No server-management API configured. Add the panel base URL and API token in Admin → Settings → Console integration. Until then this console cannot execute anything.",
    };
  }
  try {
    const servers = await fetchFromPanel(cfg, cfg.serversPath, "GET");
    return {
      connected: true,
      configured: true,
      baseUrl: safeHost(cfg.baseUrl),
      message: "Connected to the server-management API.",
      servers: normaliseServers(servers),
    };
  } catch (e: any) {
    return {
      connected: false,
      configured: true,
      baseUrl: safeHost(cfg.baseUrl),
      message: `Configured but unreachable: ${e?.message ?? "request failed"}`,
      servers: [],
    };
  }
}

function safeHost(u: string) {
  try {
    return new URL(u).host;
  } catch {
    return u;
  }
}

function normaliseServers(payload: any): { id: string; name: string; status?: string }[] {
  const raw = Array.isArray(payload)
    ? payload
    : Array.isArray(payload?.data)
      ? payload.data
      : Array.isArray(payload?.servers)
        ? payload.servers
        : [];
  return raw
    .map((s: any) => ({
      id: String(s?.id ?? s?.identifier ?? s?.uuid ?? ""),
      name: String(s?.name ?? s?.attributes?.name ?? s?.id ?? "server"),
      status: s?.status ?? s?.attributes?.status ?? undefined,
    }))
    .filter((s: any) => s.id)
    .slice(0, 50);
}

/** Single authenticated transport for every panel operation. */
export async function fetchFromPanel(cfg: ConsoleConfig, path: string, method: "GET" | "POST", body?: any) {
  if (!cfg.baseUrl || !cfg.token) throw new ApiError("Server-management API is not configured.", 503);
  const base = cfg.baseUrl.replace(/\/+$/, "");
  let target: string;
  try {
    target = new URL(path.startsWith("/") ? path : `/${path}`, base + "/").toString();
  } catch {
    throw new ApiError("Console path is invalid.", 422);
  }
  // Open-redirect guard: the request must stay on the configured host.
  if (new URL(target).host !== new URL(base).host) throw new ApiError("Console path points outside the configured host.", 422);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), cfg.timeoutMs || 8000);
  try {
    const res = await fetch(target, {
      method,
      cache: "no-store",
      signal: controller.signal,
      headers: {
        accept: "application/json",
        authorization: `Bearer ${cfg.token}`,
        ...(body ? { "content-type": "application/json" } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let data: any = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = text;
    }
    if (!res.ok) {
      const detail = typeof data === "string" ? data.slice(0, 200) : (data?.error ?? data?.message ?? "");
      throw new ApiError(`Panel returned ${res.status}${detail ? `: ${detail}` : ""}`, 502);
    }
    return data;
  } catch (e: any) {
    if (e instanceof ApiError) throw e;
    if (e?.name === "AbortError") throw new ApiError("Server-management API timed out.", 504);
    throw new ApiError(`Cannot reach server-management API: ${e?.message ?? "network error"}`, 502);
  } finally {
    clearTimeout(timer);
  }
}

export const CONSOLE_SECRET_FIELDS = SECRET_FIELDS;
