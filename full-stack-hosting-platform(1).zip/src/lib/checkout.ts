import { db } from "@/db";
import { orders, payments, products, billingCycles, coupons, paymentMethods, walletAccounts, walletTransactions } from "@/db/schema";
import { and, eq, gt, or, sql } from "drizzle-orm";
import { ApiError } from "@/lib/api";
import { applyWalletTx, markOrderPaid, newRef } from "@/lib/wallet";
import { getPlan, getSettings, resolveBilling, type Json } from "@/lib/data";
import { createHmac, randomBytes, timingSafeEqual } from "crypto";

export const money2 = (n: number) => (Math.round(n * 100) / 100).toFixed(2);

export async function getMethod(key: string) {
  const rows = await db.select().from(paymentMethods).where(eq(paymentMethods.key, key)).limit(1);
  return rows[0] ?? null;
}

export async function enabledMethods() {
  const rows = await db.select().from(paymentMethods);
  return rows
    .filter((m) => m.enabled)
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((m) => ({
      key: m.key,
      name: m.name,
      // Secrets are stripped here and never reach the browser.
      config:
        m.key === "razorpay"
          ? { mode: (m.config as Json)?.mode ?? "test", configured: Boolean((m.config as Json)?.keyId && (m.config as Json)?.keySecret) }
          : m.key === "crypto"
            ? { provider: (m.config as Json)?.provider, configured: Boolean((m.config as Json)?.apiKey), coins: (m.config as Json)?.coins ?? [] }
            : m.key === "qr"
              ? { upiId: (m.config as Json)?.upiId, qrImage: (m.config as Json)?.qrImage, instructions: (m.config as Json)?.instructions, requireScreenshot: (m.config as Json)?.requireScreenshot }
              : { instructions: (m.config as Json)?.instructions, topups: (m.config as Json)?.topups ?? [] },
    }));
}

export type CheckoutInput = {
  userId: string | null;
  slug: string;
  cycleKey?: string;
  location?: string;
  coupon?: string;
  meta?: Json;
};

export async function createCheckout(input: CheckoutInput) {
  const plan = await getPlan(input.slug);
  if (!plan || !plan.active || plan.archived) throw new ApiError("This plan is not available.", 404);
  const cycles = plan.cycles.filter((c) => c.active);
  if (!cycles.length) throw new ApiError("No billing cycles are configured for this plan.", 409);
  const cycle = cycles.find((c) => c.key === (input.cycleKey ?? "monthly")) ?? cycles[0];

  const settings = await getSettings();
  let subtotal = Number(cycle.price) + Number(plan.setupFee ?? 0);
  let discount = 0;
  let couponCode: string | null = null;
  if (input.coupon) {
    const code = input.coupon.trim().toUpperCase();
    const rows = await db
      .select()
      .from(coupons)
      .where(and(eq(coupons.code, code), eq(coupons.active, true)))
      .limit(1);
    const coupon = rows[0];
    const expired = coupon?.expiresAt && coupon.expiresAt.getTime() < Date.now();
    const exhausted = coupon && coupon.maxUses ? coupon.used >= coupon.maxUses : false;
    if (!coupon || expired || exhausted) throw new ApiError("That coupon code is not valid.", 422);
    discount = coupon.type === "percent" ? (subtotal * Number(coupon.value)) / 100 : Number(coupon.value);
    discount = Math.min(discount, subtotal);
    couponCode = code;
  }

  const taxRate = Number(plan.taxRate ?? 0) || Number(settings.taxRate ?? 0);
  const tax = ((subtotal - discount) * taxRate) / 100;
  const total = subtotal - discount + tax;

  const billing = resolveBilling(plan.billing, plan, {
    billing_cycle: cycle.key,
    cycle: cycle.key,
    location: input.location ?? "",
    coupon: couponCode ?? "",
  }, settings);

  const inserted = await db
    .insert(orders)
    .values({
      reference: newRef("ORD").toUpperCase().replace("_", ""),
      userId: input.userId,
      productId: plan.id,
      planName: plan.name,
      cycleKey: cycle.key,
      cycleLabel: cycle.label,
      location: input.location ?? null,
      couponCode,
      subtotal: money2(subtotal),
      discount: money2(discount),
      tax: money2(tax),
      total: money2(total),
      currency: plan.currency ?? settings.currency ?? "INR",
      status: "pending",
      billingUrl: billing.url,
      meta: { ...(input.meta ?? {}), cycleMonths: cycle.months, planSlug: plan.slug },
    })
    .returning();

  if (couponCode) {
    await db.update(coupons).set({ used: sql`${coupons.used} + 1` }).where(eq(coupons.code, couponCode));
  }
  await db.update(products).set({ popularity: sql`${products.popularity} + 1` }).where(eq(products.id, plan.id));

  return { order: inserted[0], plan, cycle, billing };
}

/* --------------------------------- wallet --------------------------------- */
export async function payFromWallet(orderId: string, userId: string) {
  const rows = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  const order = rows[0];
  if (!order) throw new ApiError("Order not found", 404);
  if (order.userId !== userId) throw new ApiError("This order does not belong to you", 403);
  if (order.status === "paid" || order.status === "active") return { order, alreadyPaid: true };

  const amount = Number(order.total);
  const payment = await db
    .insert(payments)
    .values({
      reference: newRef("PAY").toUpperCase().replace("_", ""),
      orderId: order.id,
      userId,
      method: "wallet",
      provider: "internal",
      amount: money2(amount),
      currency: order.currency,
      status: "pending",
      externalId: `wallet_${order.reference}`,
    })
    .returning();

  try {
    const { balance } = await applyWalletTx({
      userId,
      type: "debit",
      amount,
      note: `Payment for ${order.planName} (${order.cycleLabel ?? order.cycleKey})`,
      orderId: order.id,
      paymentId: payment[0].id,
      reference: `wd_${payment[0].reference}`,
    });
    await db
      .update(payments)
      .set({ status: "verified", updatedAt: new Date() })
      .where(eq(payments.id, payment[0].id));
    await markOrderPaid(order.id, "wallet");
    const fresh = (await db.select().from(orders).where(eq(orders.id, order.id)))[0];
    return { order: fresh, balance };
  } catch (e) {
    await db
      .update(payments)
      .set({ status: "failed", note: e instanceof Error ? e.message : "declined", updatedAt: new Date() })
      .where(eq(payments.id, payment[0].id));
    throw e;
  }
}

/* -------------------------------- razorpay -------------------------------- */
export async function createRazorpayOrder(order: { id: string; reference: string; total: string; currency: string }) {
  const method = await getMethod("razorpay");
  const cfg = (method?.config ?? {}) as Json;
  if (!method?.enabled || !cfg.keyId || !cfg.keySecret) {
    throw new ApiError("Razorpay is awaiting API credentials. Configure keys in Admin → Settings → Payments.", 503);
  }
  const res = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      Authorization: "Basic " + Buffer.from(`${cfg.keyId}:${cfg.keySecret}`).toString("base64"),
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: Math.round(Number(order.total) * 100),
      currency: order.currency || "INR",
      receipt: order.reference,
      notes: { obsidian_order: order.id },
    }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new ApiError(`Razorpay order creation failed: ${detail.slice(0, 200)}`, 502);
  }
  const rzpOrder = await res.json();
  await db
    .insert(payments)
    .values({
      reference: newRef("PAY").toUpperCase().replace("_", ""),
      orderId: order.id,
      method: "razorpay",
      provider: "razorpay",
      amount: order.total,
      currency: order.currency,
      status: "pending",
      externalId: rzpOrder.id,
    });
  return { keyId: cfg.keyId, razorpayOrder: rzpOrder };
}

export function verifyRazorpaySignature(opts: { orderId: string; paymentId: string; signature: string; secret: string }) {
  const expected = createHmac("sha256", opts.secret)
    .update(`${opts.orderId}|${opts.paymentId}`)
    .digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(String(opts.signature ?? ""));
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function settleExternalPayment(opts: {
  orderId: string;
  method: string;
  externalId: string;
  expectedAmount?: number;
}) {
  return db.transaction(async (tx) => {
    const orderRows = await tx.select().from(orders).where(eq(orders.id, opts.orderId)).limit(1);
    const order = orderRows[0];
    if (!order) throw new ApiError("Order not found", 404);
    if (order.status === "paid" || order.status === "active") return order; // idempotent

    const payRows = await tx.select().from(payments).where(eq(payments.orderId, order.id));
    let payment = payRows.find((p) => p.method === opts.method && p.status !== "verified");
    if (!payment) payment = payRows[0];
    if (!payment) throw new ApiError("No payment record for this order", 404);

    // Server-side amount check — never trust an amount from the client.
    if (opts.expectedAmount != null && Math.abs(Number(payment.amount) - opts.expectedAmount) > 1) {
      throw new ApiError("Amount mismatch — payment rejected", 409);
    }
    await tx
      .update(payments)
      .set({ status: "verified", externalId: opts.externalId ?? payment.externalId, updatedAt: new Date() })
      .where(eq(payments.id, payment.id));
    await tx.update(orders).set({ status: "paid", paymentMethod: opts.method, updatedAt: new Date() }).where(eq(orders.id, order.id));

    // A paid order with no product is a wallet top-up — credit the ledger.
    if (!order.userId) throw new ApiError("Order has no customer", 409);
    if (!order.productId) {
      await tx.execute(sql`SELECT balance FROM wallet_accounts WHERE user_id = ${order.userId} FOR UPDATE`);
      const acct = await tx.select().from(walletAccounts).where(eq(walletAccounts.userId, order.userId)).limit(1);
      const current = Number(acct[0]?.balance ?? 0);
      const next = current + Number(order.total);
      await tx.insert(walletTransactions).values({
        userId: order.userId,
        type: "topup",
        amount: order.total,
        balanceAfter: money2(next),
        orderId: order.id,
        paymentId: payment.id,
        reference: `wc_${payment.reference}`,
        note: `Wallet top-up via ${opts.method}`,
      }).onConflictDoNothing({ target: walletTransactions.reference });
      if (acct[0]) {
        await tx
          .update(walletAccounts)
          .set({ balance: money2(next), updatedAt: new Date() })
          .where(eq(walletAccounts.userId, order.userId));
      } else {
        await tx.insert(walletAccounts).values({ userId: order.userId, balance: money2(next) });
      }
    }
    return (await tx.select().from(orders).where(eq(orders.id, order.id)))[0];
  });
}

/* ---------------------------------- crypto -------------------------------- */
export async function createCryptoInvoice(order: { id: string; reference: string; total: string; currency: string }) {
  const method = await getMethod("crypto");
  const cfg = (method?.config ?? {}) as Json;
  if (!method?.enabled || !cfg.apiKey) {
    throw new ApiError(
      "Cryptocurrency payments are awaiting provider credentials. Configure them in Admin → Settings → Payments.",
      503,
    );
  }
  const base = cfg.provider === "coinpayments" ? "https://api.coinpayments.net" : "https://api.nowpayments.io";
  const res = await fetch(`${base}/v1/invoice`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": cfg.apiKey },
    body: JSON.stringify({
      price_amount: Number(order.total),
      price_currency: (order.currency || "INR").toLowerCase() === "inr" ? "usd" : order.currency.toLowerCase(),
      pay_currency: cfg.coins?.[0]?.toLowerCase?.() ?? "btc",
      order_id: order.reference,
      ipn_callback_url: `${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/webhooks/crypto`,
      order_description: `Obsidian Node order ${order.reference}`,
    }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new ApiError(`Crypto provider error: ${detail.slice(0, 200)}`, 502);
  }
  const invoice = await res.json();
  await db.insert(payments).values({
    reference: newRef("PAY").toUpperCase().replace("_", ""),
    orderId: order.id,
    method: "crypto",
    provider: cfg.provider ?? "nowpayments",
    amount: order.total,
    currency: order.currency,
    status: "pending",
    externalId: String(invoice.id ?? ""),
    note: invoice.invoice_url ?? null,
  });
  return { invoice, provider: cfg.provider ?? "nowpayments" };
}

export async function verifyCryptoIpn(payload: Json, signature: string | null, raw: string) {
  const method = await getMethod("crypto");
  const cfg = (method?.config ?? {}) as Json;
  if (!cfg.ipnSecret) throw new ApiError("IPN secret not configured", 400);
  if (cfg.provider === "nowpayments") {
    const sorted = JSON.stringify(
      Object.keys(payload)
        .filter((k) => k !== "sign")
        .sort()
        .reduce((acc, k) => ((acc[k] = payload[k]), acc), {} as Json),
    );
    const expected = createHmac("sha512", cfg.ipnSecret).update(sorted).digest("hex");
    if (!signature || signature !== expected) throw new ApiError("Invalid IPN signature", 401);
  }
  const status = String(payload.payment_status ?? payload.status ?? "").toLowerCase();
  const orderRef = String(payload.order_id ?? "");
  if (status !== "finished" && status !== "confirmed" && status !== "paid") {
    return { settled: false, status };
  }
  const rows = await db.select().from(orders).where(eq(orders.reference, orderRef)).limit(1);
  if (!rows[0]) throw new ApiError("Unknown order reference", 404);
  await settleExternalPayment({
    orderId: rows[0].id,
    method: "crypto",
    externalId: String(payload.payment_id ?? payload.transaction_id ?? ""),
  });
  return { settled: true, status };
}

/* ----------------------------------- QR ----------------------------------- */
export async function submitQrPayment(opts: {
  orderId: string;
  userId: string;
  utr: string;
  proofUrl?: string | null;
  note?: string | null;
}) {
  const rows = await db.select().from(orders).where(eq(orders.id, opts.orderId)).limit(1);
  const order = rows[0];
  if (!order) throw new ApiError("Order not found", 404);
  if (order.userId !== opts.userId) throw new ApiError("This order does not belong to you", 403);
  if (!/^[\w-]{6,40}$/.test(opts.utr)) return Promise.reject(new ApiError("Enter a valid UTR / transaction reference.", 422));

  const existing = await db
    .select()
    .from(payments)
    .where(and(eq(payments.orderId, order.id), eq(payments.method, "qr"), eq(payments.status, "awaiting_verification")))
    .limit(1);
  if (existing[0]) throw new ApiError("A payment for this order is already awaiting verification.", 409);

  const payment = await db
    .insert(payments)
    .values({
      reference: newRef("PAY").toUpperCase().replace("_", ""),
      orderId: order.id,
      userId: opts.userId,
      method: "qr",
      provider: "manual",
      amount: order.total,
      currency: order.currency,
      status: "awaiting_verification",
      externalId: opts.utr,
      proofUrl: opts.proofUrl ?? null,
      note: opts.note ?? null,
    })
    .returning();
  // Order stays "pending" until an administrator approves — a screenshot or UTR
  // submission alone never marks a payment as successful.
  return payment[0];
}
