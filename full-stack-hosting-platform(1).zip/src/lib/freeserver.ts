import { db } from "@/db";
import { settings, demoServers, users } from "@/db/schema";
import { and, eq, lt, ne, sql, desc, inArray, gte } from "drizzle-orm";
import { ApiError } from "@/lib/api";

export type FreeServerSettings = {
  enabled: boolean;
  title: string;
  description: string;
  banner: string;
  cta: string;
  requireRegistration: boolean;
  currency: string;
  defaults: { ramMb: number; cpuPercent: number; diskMb: number; durationMinutes: number; software: string };
  ram: { freeMb: number; maxMb: number; options: number[]; allowPaid: boolean; pricePerGb: number };
  cpu: { freePercent: number; maxPercent: number; options: number[]; allowPaid: boolean; pricePer100: number };
  disk: { freeMb: number; maxMb: number; options: number[]; allowPaid: boolean; pricePerGb: number; type: string };
  duration: {
    options: number[];
    defaultMinutes: number;
    maxMinutes: number;
    allowExtension: boolean;
    extensionMinutes: number;
    /** What happens when a demo expires: stop the container, or destroy it. */
    expireAction: "stop" | "delete";
    cleanup: boolean;
  };
  software: { id: string; name: string; version: string; enabled: boolean; egg: number | null; dockerImage: string; startup: string }[];
  access: {
    oneActivePerUser: boolean;
    maxPerAccount: number;
    cooldownMinutes: number;
    maxActiveGlobal: number;
    ipLimit: number;
    ipWindowMinutes: number;
  };
};

export const DEFAULT_FREE_SERVER: FreeServerSettings = {
  enabled: true,
  title: "Build your free demo server",
  description:
    "Configure RAM, CPU, storage, runtime and software exactly the way you would on a paid plan. The first 2 GB, 100% CPU and 10 GB are free — everything above that is priced live.",
  banner: "/images/rack-macro.jpg",
  cta: "Create Free Server",
  requireRegistration: true,
  currency: "INR",
  defaults: { ramMb: 2048, cpuPercent: 100, diskMb: 10240, durationMinutes: 180, software: "paper" },
  ram: {
    freeMb: 2048,
    maxMb: 8192,
    options: [512, 1024, 2048, 3072, 4096, 6144, 8192],
    allowPaid: true,
    pricePerGb: 49,
  },
  cpu: { freePercent: 100, maxPercent: 200, options: [50, 100, 150, 200], allowPaid: true, pricePer100: 39 },
  disk: {
    freeMb: 10240,
    maxMb: 20480,
    options: [5120, 10240, 15360, 20480],
    allowPaid: true,
    pricePerGb: 9,
    type: "NVMe SSD",
  },
  duration: {
    options: [60, 180, 360, 720, 1440, 4320],
    defaultMinutes: 180,
    maxMinutes: 4320,
    allowExtension: true,
    extensionMinutes: 180,
    expireAction: "stop",
    cleanup: true,
  },
  software: [
    { id: "paper", name: "Minecraft Java — Paper", version: "1.21.4", enabled: true, egg: null, dockerImage: "ghcr.io/pterodactyl/yolks:java_21", startup: "java -Xms1024M -Xmx{{SERVER_MEMORY}}M -jar server.jar nogui" },
    { id: "purpur", name: "Minecraft Java — Purpur", version: "1.21.4", enabled: true, egg: null, dockerImage: "ghcr.io/pterodactyl/yolks:java_21", startup: "java -Xms1024M -Xmx{{SERVER_MEMORY}}M -jar server.jar nogui" },
    { id: "fabric", name: "Minecraft Java — Fabric", version: "1.21.4", enabled: true, egg: null, dockerImage: "ghcr.io/pterodactyl/yolks:java_21", startup: "java -Xms1024M -Xmx{{SERVER_MEMORY}}M -jar fabric-server-launch.jar nogui" },
    { id: "forge", name: "Minecraft Java — Forge", version: "1.20.1", enabled: true, egg: null, dockerImage: "ghcr.io/pterodactyl/yolks:java_17", startup: "java -Xms2048M -Xmx{{SERVER_MEMORY}}M @libraries/forge/... nogui" },
    { id: "vanilla", name: "Minecraft Java — Vanilla", version: "1.21.4", enabled: true, egg: null, dockerImage: "ghcr.io/pterodactyl/yolks:java_21", startup: "java -Xms1024M -Xmx{{SERVER_MEMORY}}M -jar server.jar nogui" },
    { id: "bedrock", name: "Minecraft Bedrock", version: "1.21.51", enabled: true, egg: null, dockerImage: "ghcr.io/pterodactyl/yolks:vanilla_bedrock", startup: "./bedrock_server" },
  ],
  access: { oneActivePerUser: true, maxPerAccount: 1, cooldownMinutes: 60, maxActiveGlobal: 25, ipLimit: 3, ipWindowMinutes: 60 },
};

export async function getFreeServerSettings(): Promise<FreeServerSettings> {
  const rows = await db.select().from(settings).where(eq(settings.key, "freeServer")).limit(1);
  const stored = (rows[0]?.value ?? {}) as Partial<FreeServerSettings>;
  return deepMerge(DEFAULT_FREE_SERVER, stored);
}

function deepMerge<T>(base: T, patch: any): T {
  if (patch == null) return base;
  if (Array.isArray(base)) return (Array.isArray(patch) ? patch : base) as any;
  if (typeof base !== "object" || base === null) return (patch ?? base) as any;
  const out: any = { ...(base as any) };
  for (const [k, v] of Object.entries(patch)) {
    out[k] = k in (base as any) ? deepMerge((base as any)[k], v) : v;
  }
  return out;
}

/* -------------------------------- pricing --------------------------------- */
export type Selection = {
  ramMb: number;
  cpuPercent: number;
  diskMb: number;
  durationMinutes: number;
  software: string;
  name: string;
};

export type PriceLine = { key: string; label: string; detail: string; free: boolean; amount: number };

export type PriceResult = { lines: PriceLine[]; total: number; currency: string; free: boolean };

/**
 * Price is always computed on the server from the stored configuration —
 * values sent by the browser are never trusted.
 */
export function priceSelection(cfg: FreeServerSettings, sel: Selection): PriceResult {
  const lines: PriceLine[] = [];
  const gb = (mb: number) => Math.ceil(Math.max(0, mb) / 1024);

  // RAM
  const ramOver = Math.max(0, sel.ramMb - cfg.ram.freeMb);
  lines.push({
    key: "ram",
    label: "RAM",
    detail: ramOver > 0 ? `${gb(cfg.ram.freeMb)} GB included · ${gb(ramOver)} GB extra` : `${gb(sel.ramMb)} GB included`,
    free: ramOver === 0,
    amount: ramOver > 0 && cfg.ram.allowPaid ? gb(ramOver) * cfg.ram.pricePerGb : 0,
  });
  // CPU
  const cpuOver = Math.max(0, sel.cpuPercent - cfg.cpu.freePercent);
  lines.push({
    key: "cpu",
    label: "CPU",
    detail: cpuOver > 0 ? `${cfg.cpu.freePercent}% included · +${cpuOver}% allocated` : `${sel.cpuPercent}% included`,
    free: cpuOver === 0,
    amount: cpuOver > 0 && cfg.cpu.allowPaid ? Math.ceil(cpuOver / 100) * cfg.cpu.pricePer100 : 0,
  });
  // Disk
  const diskOver = Math.max(0, sel.diskMb - cfg.disk.freeMb);
  lines.push({
    key: "disk",
    label: "Storage",
    detail: diskOver > 0 ? `${gb(cfg.disk.freeMb)} GB included · ${gb(diskOver)} GB extra` : `${gb(sel.diskMb)} GB included`,
    free: diskOver === 0,
    amount: diskOver > 0 && cfg.disk.allowPaid ? gb(diskOver) * cfg.disk.pricePerGb : 0,
  });
  // Duration is always free (time-limited demo)
  lines.push({
    key: "duration",
    label: "Duration",
    detail: `${formatDuration(sel.durationMinutes)} demo runtime`,
    free: true,
    amount: 0,
  });

  const total = lines.reduce((n, l) => n + l.amount, 0);
  return { lines, total, currency: cfg.currency, free: total === 0 };
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  if (minutes % 1440 === 0) return `${minutes / 1440} day${minutes > 1440 ? "s" : ""}`;
  if (minutes % 60 === 0) return `${minutes / 60} hour${minutes > 60 ? "s" : ""}`;
  return `${minutes} min`;
}

/* ------------------------------- validation ------------------------------- */
export function validateSelection(cfg: FreeServerSettings, sel: Partial<Selection>): Selection {
  if (!cfg.enabled) throw new ApiError("The free server demo is currently disabled.", 403);

  const inList = (list: number[], value: number) => list.includes(value);
  const ram = Number(sel.ramMb ?? cfg.defaults.ramMb);
  const cpu = Number(sel.cpuPercent ?? cfg.defaults.cpuPercent);
  const disk = Number(sel.diskMb ?? cfg.defaults.diskMb);
  const duration = Number(sel.durationMinutes ?? cfg.defaults.durationMinutes);
  const software = String(sel.software ?? cfg.defaults.software);
  const name = String(sel.name ?? "").trim().slice(0, 60);

  if (!inList(cfg.ram.options, ram)) throw new ApiError("That RAM option is not offered.", 422);
  if (ram > cfg.ram.maxMb) throw new ApiError(`RAM cannot exceed ${cfg.ram.maxMb} MB on the demo tier.`, 422);
  if (ram > cfg.ram.freeMb && !cfg.ram.allowPaid) throw new ApiError("Paid RAM upgrades are disabled for demos.", 422);

  if (!inList(cfg.cpu.options, cpu)) throw new ApiError("That CPU option is not offered.", 422);
  if (cpu > cfg.cpu.maxPercent) throw new ApiError(`CPU cannot exceed ${cfg.cpu.maxPercent}%.`, 422);
  if (cpu > cfg.cpu.freePercent && !cfg.cpu.allowPaid) throw new ApiError("Paid CPU upgrades are disabled for demos.", 422);

  if (!inList(cfg.disk.options, disk)) throw new ApiError("That storage option is not offered.", 422);
  if (disk > cfg.disk.maxMb) throw new ApiError(`Storage cannot exceed ${cfg.disk.maxMb} MB.`, 422);
  if (disk > cfg.disk.freeMb && !cfg.disk.allowPaid) throw new ApiError("Paid storage upgrades are disabled for demos.", 422);

  if (!inList(cfg.duration.options, duration)) throw new ApiError("That duration is not offered.", 422);
  if (duration > cfg.duration.maxMinutes) throw new ApiError(`Duration cannot exceed ${cfg.duration.maxMinutes} minutes.`, 422);

  const sw = cfg.software.find((s) => s.id === software && s.enabled);
  if (!sw) throw new ApiError("That server software is not available for demos.", 422);

  if (name.length < 3) throw new ApiError("Give the server a name of at least 3 characters.", 422);
  if (!/^[A-Za-z0-9 _.-]+$/.test(name)) throw new ApiError("Server name may only contain letters, numbers, spaces, dots, dashes and underscores.", 422);

  return { ramMb: ram, cpuPercent: cpu, diskMb: disk, durationMinutes: duration, software, name };
}

/* ------------------------------ access rules ------------------------------ */
export type RuleContext = { userId: string; ip: string };

export async function assertAccessAllowed(cfg: FreeServerSettings, ctx: RuleContext) {
  if (!cfg.enabled) throw new ApiError("The free server demo is currently disabled.", 403);

  const activeStatuses = ["pending", "running", "stopped"];
  const mine = await db
    .select()
    .from(demoServers)
    .where(and(eq(demoServers.userId, ctx.userId), inArrayStatus(activeStatuses)))
    .orderBy(desc(demoServers.createdAt));

  if (cfg.access.oneActivePerUser && mine.length >= 1) {
    throw new ApiError("You already have an active demo server. Stop or remove it before creating another.", 409);
  }
  if (mine.length >= cfg.access.maxPerAccount) {
    throw new ApiError(`Your account is limited to ${cfg.access.maxPerAccount} active demo server(s).`, 409);
  }

  const cooldownFrom = new Date(Date.now() - cfg.access.cooldownMinutes * 60_000);
  if (cfg.access.cooldownMinutes > 0) {
    const recent = mine.find((m) => m.createdAt > cooldownFrom);
    if (recent) {
      const waitMin = Math.ceil((recent.createdAt.getTime() + cfg.access.cooldownMinutes * 60_000 - Date.now()) / 60000);
      throw new ApiError(`Demo cooldown active — ${waitMin} minute(s) before you can create another server.`, 429);
    }
  }

  const globalActive = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(demoServers)
    .where(and(inArrayStatus(activeStatuses), ne(demoServers.status, "failed")));
  if (globalActive[0].n >= cfg.access.maxActiveGlobal) {
    throw new ApiError("All demo slots are currently in use. Try again later.", 429);
  }

  if (cfg.access.ipLimit > 0 && ctx.ip) {
    const from = new Date(Date.now() - cfg.access.ipWindowMinutes * 60_000);
    const rows = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(demoServers)
      .where(and(eq(demoServers.createdIp, ctx.ip), gteDate(from)));
    if (rows[0].n >= cfg.access.ipLimit) {
      throw new ApiError("This network has reached its demo-server limit.", 429);
    }
  }

  // Blocked users (set by an administrator) cannot create new demos.
  const user = await db.select({ status: users.status, mustChangePassword: users.mustChangePassword }).from(users).where(eq(users.id, ctx.userId)).limit(1);
  if (!user[0] || user[0].status !== "active") throw new ApiError("This account cannot create demo servers.", 403);
}

const inArrayStatus = (list: string[]) => inArray(demoServers.status, list as any);
const inArrayStatusImpl = inArrayStatus;
const gteDate = (d: Date) => gte(demoServers.createdAt, d);

/* ----------------------------- expiry sweep ------------------------------- */
/**
 * Stops or destroys demo servers past their expiry according to the
 * configured policy. Safe to call on every list request; also exposed as a
 * cron endpoint for scheduled runs.
 */
export async function sweepExpiredDemoServers(): Promise<{ processed: number; errors: string[] }> {
  const cfg = await getFreeServerSettings();
  const now = new Date();
  const due = await db
    .select()
    .from(demoServers)
    .where(and(lt(demoServers.expiresAt, now), inArrayStatusImpl(["running", "stopped", "pending"])))
    .limit(50);

  const errors: string[] = [];
  let processed = 0;
  const { stopExternalServer, deleteExternalServer, getProvisionConfig, isConfiguredStatic } = await import("@/lib/provision");
  const configured = isConfiguredStatic(await getProvisionConfig());

  for (const srv of due) {
    try {
      if (cfg.duration.expireAction === "delete" && configured && srv.externalId) {
        await deleteExternalServer(srv.externalId);
        await db
          .update(demoServers)
          .set({ status: "terminated", stoppedAt: now, updatedAt: now, lastError: null })
          .where(eq(demoServers.id, srv.id));
      } else {
        if (configured && srv.externalId && srv.status === "running") {
          await stopExternalServer(srv.externalId);
        }
        await db
          .update(demoServers)
          .set({ status: "expired", stoppedAt: now, updatedAt: now })
          .where(eq(demoServers.id, srv.id));
      }
      processed++;
    } catch (e: any) {
      errors.push(`${srv.reference}: ${e?.message ?? "cleanup failed"}`);
    }
  }
  return { processed, errors };
}
