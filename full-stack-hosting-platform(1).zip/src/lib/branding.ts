import { getSettings, type Json } from "@/lib/data";

export type Branding = {
  siteName: string;
  tagline: string;
  /** Primary logo (dark surfaces). Falls back to the SVG mark when empty. */
  logo: string | null;
  /** Optional light-theme variant used on light surfaces / print. */
  logoLight: string | null;
  /** Optional dark-theme variant. */
  logoDark: string | null;
  favicon: string | null;
  faviconType: string;
  /** Text shown next to the logo when no image is supplied. */
  wordmark: string;
  submark: string;
  logoWidth: number;
  logoHeight: number;
};

function isImage(v: unknown): v is string {
  return typeof v === "string" && (v.startsWith("data:image/") || v.startsWith("/") || /^https?:\/\//.test(v));
}

function typeOf(src: string | null): string {
  if (!src) return "image/svg+xml";
  if (src.startsWith("data:image/")) return src.slice(5, src.indexOf(";"));
  if (/\.png(\?|$)/i.test(src)) return "image/png";
  if (/\.jpe?g(\?|$)/i.test(src)) return "image/jpeg";
  if (/\.ico(\?|$)/i.test(src)) return "image/x-icon";
  if (/\.webp(\?|$)/i.test(src)) return "image/webp";
  return "image/svg+xml";
}

/** Single source of truth for the logo / favicon used by every surface. */
export async function getBranding(): Promise<Branding> {
  const s = await getSettings().catch(() => ({}) as Json);
  const b = (s.branding ?? {}) as Json;
  const logo = isImage(b.logo) ? b.logo : null;
  return {
    siteName: b.siteName || s.siteName || "Obsidian Node",
    tagline: b.tagline || s.tagline || "",
    logo,
    logoLight: isImage(b.logoLight) ? b.logoLight : null,
    logoDark: isImage(b.logoDark) ? b.logoDark : null,
    favicon: isImage(b.favicon) ? b.favicon : null,
    faviconType: typeOf(isImage(b.favicon) ? b.favicon : null),
    wordmark: (b.wordmark || s.logoText || "OBSIDIAN").toString().slice(0, 24),
    submark: (b.submark || "NODE · INFRA").toString().slice(0, 24),
    logoWidth: Math.min(320, Math.max(24, Number(b.logoWidth) || 132)),
    logoHeight: Math.min(96, Math.max(16, Number(b.logoHeight) || 34)),
  };
}

export const DEFAULT_BRANDING: Json = {
  siteName: "",
  tagline: "",
  logo: null,
  logoLight: null,
  logoDark: null,
  favicon: null,
  wordmark: "",
  submark: "NODE · INFRA",
  logoWidth: 132,
  logoHeight: 34,
};
