import { Pool } from "pg";
import net from "net";

export type DbProvider = "postgres" | "supabase" | "mysql" | "local";

export type DbCandidate = {
  provider: DbProvider;
  projectUrl?: string;
  host: string;
  port: number;
  database: string;
  username: string;
  /** Plaintext password — only ever passed to the driver, never persisted in clear. */
  password?: string;
  ssl: "disable" | "require" | "prefer";
  /** Supabase public client config (safe to show). Service-role key stays server-side. */
  anonKey?: string;
};

export type TestResult = {
  ok: boolean;
  stage: "config" | "tcp" | "auth" | "schema";
  message: string;
  latencyMs: number | null;
  tables?: { name: string; present: boolean }[];
};

export const REQUIRED_TABLES = [
  "users",
  "categories",
  "products",
  "billing_cycles",
  "billing_configurations",
  "orders",
  "payments",
  "wallet_accounts",
  "wallet_transactions",
  "settings",
];

function connectionString(c: DbCandidate): string {
  const enc = (s: string) => encodeURIComponent(s ?? "");
  if (c.provider === "supabase" && c.projectUrl) {
    const u = new URL(c.projectUrl);
    const db = c.database || u.pathname.replace(/^\//, "") || "postgres";
    const user = c.username || "postgres";
    const pass = c.password ?? "";
    return `${u.protocol}//${user}:${enc(pass)}@${u.hostname}:${c.port || 5432}/${db}?sslmode=${c.ssl === "disable" ? "disable" : "require"}`;
  }
  const ssl = c.ssl === "disable" ? "" : `?sslmode=${c.ssl === "require" ? "require" : "prefer"}`;
  return `postgresql://${enc(c.username)}:${enc(c.password ?? "")}@${c.host}:${c.port}/${c.database}${ssl}`;
}

/** Raw TCP reachability — works for any database including MySQL. */
export function testTcp(host: string, port: number, timeoutMs = 5000): Promise<{ ok: boolean; ms: number | null; error: string | null }> {
  return new Promise((resolve) => {
    if (!host) return resolve({ ok: false, ms: null, error: "Host is required" });
    const start = Date.now();
    const socket = net.connect({ host, port: Number(port) });
    let settled = false;
    const done = (ok: boolean, error: string | null) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve({ ok, ms: Date.now() - start, error });
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => done(true, null));
    socket.once("timeout", () => done(false, "Connection timed out"));
    socket.once("error", (e) => done(false, e.message));
  });
}

/**
 * Full validation of a proposed connection: TCP → authentication → schema.
 * Uses a throwaway pool so the running application's pool is untouched.
 */
export async function testDatabaseConnection(c: DbCandidate): Promise<TestResult> {
  if (!c.host && !c.projectUrl) {
    return { ok: false, stage: "config", message: "Host or project URL is required.", latencyMs: null };
  }
  if (!c.database) return { ok: false, stage: "config", message: "Database name is required.", latencyMs: null };
  if (!c.username && c.provider !== "supabase") {
    return { ok: false, stage: "config", message: "Username is required.", latencyMs: null };
  }

  if (c.provider === "mysql") {
    // The current schema and Drizzle config are PostgreSQL-only: MySQL can be
    // reached and authenticated against, but cannot host this application.
    const tcp = await testTcp(c.host, Number(c.port) || 3306);
    return {
      ok: false,
      stage: "tcp",
      latencyMs: tcp.ms,
      message: tcp.ok
        ? `MySQL server at ${c.host}:${c.port} is reachable, but this deployment runs on PostgreSQL/Drizzle — MySQL cannot be used as the application database without a schema migration.`
        : `MySQL connection failed: ${tcp.error}`,
    };
  }

  const host = c.provider === "supabase" && c.projectUrl ? new URL(c.projectUrl).hostname : c.host;
  const tcp = await testTcp(host, Number(c.port) || 5432);
  if (!tcp.ok) return { ok: false, stage: "tcp", message: `Cannot reach ${host}:${c.port} — ${tcp.error}`, latencyMs: tcp.ms };

  const pool = new Pool({ connectionString: connectionString(c), connectionTimeoutMillis: 8000, max: 2 });
  const started = Date.now();
  try {
    const client = await pool.connect();
    try {
      await client.query("select 1 as ok");
      const tables: { name: string; present: boolean }[] = [];
      for (const t of REQUIRED_TABLES) {
        const r = await client.query("select to_regclass($1) as v", [`public.${t}`]);
        tables.push({ name: t, present: Boolean(r.rows[0]?.v) });
      }
      const missing = tables.filter((t) => !t.present);
      const latencyMs = Date.now() - started;
      if (missing.length) {
        return {
          ok: false,
          stage: "schema",
          latencyMs,
          tables,
          message: `Authenticated, but ${missing.length} required table(s) missing: ${missing.map((m) => m.name).join(", ")}. Run the schema push before switching.`,
        };
      }
      return { ok: true, stage: "schema", latencyMs, tables, message: `Connected and verified ${tables.length} required tables.` };
    } finally {
      client.release();
    }
  } catch (e: any) {
    return { ok: false, stage: "auth", latencyMs: Date.now() - started, message: `Authentication failed: ${e?.message ?? "unknown error"}` };
  } finally {
    await pool.end().catch(() => {});
  }
}
