import { db } from "@/db";
import {
  categories,
  tags,
  products,
  productTags,
  billingCycles,
  billingConfigurations,
  testimonials,
  faqs,
  homepageSections,
  settings,
  orders,
  payments,
  users,
  coupons,
  paymentMethods,
  activityLogs,
  walletAccounts,
} from "@/db/schema";
import { asc, desc, eq, sql, inArray } from "drizzle-orm";
import { ApiError } from "@/lib/api";
import { validateRedirectUrl } from "@/lib/api";
import { hashPassword } from "@/lib/auth";
import { getSettings, type Json } from "@/lib/data";
import { billingDefaults, normalizePath, defaultPath, normalizePrefix } from "@/lib/redirect";
import { serverLocations } from "@/db/schema";

const slugify = (s: string) =>
  String(s)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 160);

const str = (v: unknown, max = 500): string | undefined =>
  v == null ? undefined : String(v).slice(0, max);
const bool = (v: unknown, d = false) => (v == null ? d : Boolean(v));
const num = (v: unknown, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
const arr = (v: unknown): any[] => (Array.isArray(v) ? v : []);

/** entity → allowed RBAC scope */
export const ENTITY_SCOPE: Record<string, string> = {
  categories: "catalog",
  tags: "catalog",
  plans: "catalog",
  testimonials: "cms",
  faqs: "cms",
  homepage: "cms",
  settings: "settings",
  "payment-methods": "settings",
  orders: "orders",
  payments: "payments",
  customers: "customers",
  coupons: "orders",
  activity: "orders",
  locations: "catalog",
};

export function scopeFor(entity: string) {
  const scope = ENTITY_SCOPE[entity];
  if (!scope) throw new ApiError("Unknown resource", 404);
  return scope;
}

/* --------------------------------- reads ---------------------------------- */
export async function listEntity(entity: string) {
  switch (entity) {
    case "categories":
      return db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name));
    case "tags":
      return db.select().from(tags).orderBy(asc(tags.sortOrder), asc(tags.name));
    case "plans": {
      const rows = await db
        .select({ product: products, categoryName: categories.name, categorySlug: categories.slug })
        .from(products)
        .leftJoin(categories, eq(products.categoryId, categories.id))
        .orderBy(asc(products.sortOrder), asc(products.name));
      const ids = rows.map((r) => r.product.id);
      const [cycleRows, tagRows] = await Promise.all([
        ids.length ? db.select().from(billingCycles).where(inArray(billingCycles.productId, ids)) : [],
        ids.length
          ? db
              .select({ productId: productTags.productId, tag: tags })
              .from(productTags)
              .innerJoin(tags, eq(productTags.tagId, tags.id))
          : [],
      ]);
      const billingRows = ids.length
        ? await db.select().from(billingConfigurations).where(inArray(billingConfigurations.productId, ids))
        : [];
      return rows.map((r) => ({
        ...r.product,
        categoryName: r.categoryName,
        categorySlug: r.categorySlug,
        cycles: cycleRows.filter((c) => c.productId === r.product.id).sort((a, b) => a.sortOrder - b.sortOrder),
        tags: tagRows.filter((t) => t.productId === r.product.id).map((t) => t.tag),
        billing: billingRows.find((b) => b.productId === r.product.id) ?? null,
      }));
    }
    case "orders": {
      const rows = await db
        .select({ order: orders, customer: users.name, email: users.email, plan: products.name })
        .from(orders)
        .leftJoin(users, eq(orders.userId, users.id))
        .leftJoin(products, eq(orders.productId, products.id))
        .orderBy(desc(orders.createdAt))
        .limit(500);
      return rows.map((r) => ({
        ...r.order,
        customer: r.customer ?? "Guest",
        email: r.email ?? null,
        plan: r.plan ?? r.order.planName,
      }));
    }
    case "payments": {
      const rows = await db
        .select({ payment: payments, customer: users.name, email: users.email, orderRef: orders.reference, plan: orders.planName })
        .from(payments)
        .leftJoin(users, eq(payments.userId, users.id))
        .leftJoin(orders, eq(payments.orderId, orders.id))
        .orderBy(desc(payments.createdAt))
        .limit(500);
      return rows.map((r) => ({
        ...r.payment,
        customer: r.customer ?? "Guest",
        email: r.email ?? null,
        orderRef: r.orderRef ?? null,
        plan: r.plan ?? null,
      }));
    }
    case "customers": {
      const rows = await db
        .select({
          user: users,
          balance: walletAccounts.balance,
          orderCount: sql<number>`(select count(*)::int from orders where orders.user_id = ${users.id})`,
        })
        .from(users)
        .leftJoin(walletAccounts, eq(walletAccounts.userId, users.id))
        .where(eq(users.role, "customer"))
        .orderBy(desc(users.createdAt))
        .limit(500);
      return rows.map((r) => ({ ...r.user, passwordHash: undefined, balance: r.balance ?? "0", orderCount: r.orderCount }));
    }
    case "locations":
      return db.select().from(serverLocations).orderBy(asc(serverLocations.sortOrder), asc(serverLocations.name));
    case "testimonials":
      return db.select().from(testimonials).orderBy(asc(testimonials.sortOrder));
    case "faqs":
      return db.select().from(faqs).orderBy(asc(faqs.sortOrder));
    case "coupons":
      return db.select().from(coupons).orderBy(desc(coupons.createdAt));
    case "payment-methods": {
      const rows = await db.select().from(paymentMethods).orderBy(asc(paymentMethods.sortOrder));
      // Secrets never leave the server.
      return rows.map((m) => {
        const cfg = { ...((m.config as Json) ?? {}) };
        for (const secret of ["keySecret", "webhookSecret", "apiKey", "ipnSecret"]) delete cfg[secret];
        const configured =
          m.key === "razorpay"
            ? Boolean((m.config as Json)?.keyId && (m.config as Json)?.keySecret)
            : m.key === "crypto"
              ? Boolean((m.config as Json)?.apiKey)
              : undefined;
        return { ...m, config: { ...cfg, ...(configured !== undefined ? { configured } : {}) } };
      });
    }
    case "homepage":
      return db.select().from(homepageSections);
    case "settings":
      return db.select().from(settings);
    case "activity":
      return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(300);
    default:
      throw new ApiError("Unknown resource", 404);
  }
}

/* --------------------------------- writes --------------------------------- */
function cleanCycles(input: any) {
  const rows = arr(input);
  if (!rows.length) throw new ApiError("At least one billing cycle is required.", 422);
  const seen = new Set<string>();
  return rows.map((c: any, i: number) => {
    const key = String(c.key ?? "").trim().toLowerCase();
    if (!/^[\w-]{2,30}$/.test(key)) throw new ApiError(`Billing cycle #${i + 1} has an invalid key.`, 422);
    if (seen.has(key)) throw new ApiError(`Duplicate billing cycle "${key}".`, 422);
    seen.add(key);
    const price = num(c.price, NaN);
    if (!Number.isFinite(price) || price < 0) throw new ApiError(`Billing cycle "${key}" needs a valid price.`, 422);
    return {
      key,
      label: str(c.label, 60) ?? key,
      months: Math.max(1, num(c.months, 1)),
      price: price.toFixed(2),
      compareAt: c.compareAt != null && num(c.compareAt, 0) > 0 ? num(c.compareAt).toFixed(2) : null,
      active: bool(c.active, true),
      sortOrder: num(c.sortOrder, i + 1),
    };
  });
}

export async function cleanBilling(productId: string, input: any, excludeId?: string) {
  const settings = await getSettings();
  const { pathPrefix, canonicalDomain } = billingDefaults(settings);
  const billingType = ["external", "internal", "custom", "manual"].includes(String(input?.billingType))
    ? String(input.billingType)
    : "internal";

  // Mode: explicitly supplied, else derived from which field the admin filled in.
  const requested = input?.redirectMode === "external" ? "external" : input?.redirectMode === "internal" ? "internal" : null;
  const mode =
    requested ??
    (input?.destinationUrl && !input?.redirectPath ? "external" : input?.redirectPath ? "internal" : billingType === "external" ? "external" : "internal");

  const globalSetting = (settings?.billing?.trustedHosts ?? "") as string;
  const allowedHosts = [...String(input?.trustedHosts ?? "").split(","), ...String(globalSetting).split(",")]
    .map((h) => h.trim())
    .filter(Boolean);

  let destinationUrl: string | null = null;
  let redirectPath: string | null = null;

  if (mode === "external") {
    destinationUrl = validateRedirectUrl(input?.destinationUrl, allowedHosts);
    if (!destinationUrl)
      throw new ApiError(
        "Billing destination must be a valid http(s) URL on a trusted host. Add the host to this plan's Trusted hosts or to Admin -> Settings -> Trusted billing hosts.",
        422,
      );
  } else {
    // Per-plan internal path: admin-editable, validated against open redirects,
    // generated from the slug when empty, and unique across the catalogue.
    const raw = normalizePath(input?.redirectPath) ?? (input?.destinationUrl ? normalizePath(stripOrigin(input?.destinationUrl)) : null);
    const slug = String(input?.slug ?? "").trim();
    const path = raw ?? defaultPath(pathPrefix, slug || productId);
    if (!path) throw new ApiError("Redirect path is invalid. Use a relative path such as /order/plan-slug.", 422);
    const clash = await db
      .select({ id: billingConfigurations.productId })
      .from(billingConfigurations)
      .where(eq(billingConfigurations.redirectPath, path))
      .limit(5);
    const conflict = clash.find((c) => c.id !== (excludeId ?? productId));
    if (conflict) throw new ApiError(`Path ${path} is already used by another plan. Choose a different path.`, 409);
    redirectPath = path;
  }

  return {
    productId,
    orderingEnabled: bool(input?.orderingEnabled, true),
    billingType: billingType === "custom" ? "external" : billingType,
    redirectMode: mode as "internal" | "external",
    redirectPath,
    destinationUrl,
    urlParams: typeof input?.urlParams === "object" && input.urlParams ? input.urlParams : {},
    openIn: input?.openIn === "new" ? "new" : "same",
    buttonText: str(input?.buttonText, 60) ?? "Order Now",
    trustedHosts: str(input?.trustedHosts, 400),
    canonicalPreview: mode === "internal" ? `${canonicalDomain}${redirectPath ?? ""}` : destinationUrl,
  };
}

/** https://host/order/x -> /order/x (keeps query). */
function stripOrigin(value: unknown): string {
  try {
    const u = new URL(String(value));
    return `${u.pathname}${u.search}`;
  } catch {
    return String(value ?? "");
  }
}

export async function createEntity(entity: string, data: Json, actor: { id: string; name: string }) {
  switch (entity) {
    case "categories": {
      const name = str(data.name, 120);
      if (!name) throw new ApiError("Category name is required.", 422);
      const row = await db
        .insert(categories)
        .values({
          name,
          slug: slugify(data.slug || name),
          description: str(data.description, 2000),
          icon: str(data.icon, 60) ?? "server",
          image: str(data.image, 400),
          parentId: data.parentId ? String(data.parentId) : null,
          seoTitle: str(data.seoTitle, 190),
          seoDescription: str(data.seoDescription, 320),
          sortOrder: num(data.sortOrder, 0),
          active: bool(data.active, true),
        })
        .returning();
      return row[0];
    }
    case "tags": {
      const name = str(data.name, 80);
      if (!name) throw new ApiError("Tag name is required.", 422);
      const row = await db
        .insert(tags)
        .values({
          name,
          slug: slugify(data.slug || name),
          color: /^#[0-9a-fA-F]{3,8}$/.test(String(data.color)) ? String(data.color) : "#FF6B18",
          showOnCards: bool(data.showOnCards, true),
          sortOrder: num(data.sortOrder, 0),
          active: bool(data.active, true),
        })
        .returning();
      return row[0];
    }
    case "plans":
      return createPlan(data, actor);
    case "locations": {
      const name = str(data.name, 120);
      if (!name) throw new ApiError("Location name is required.", 422);
      const row = await db
        .insert(serverLocations)
        .values({
          name,
          city: str(data.city, 80),
          country: str(data.country, 80),
          code: str(data.code, 20),
          tier: str(data.tier, 20) ?? "Edge",
          endpoint: normalizeEndpoint(data.endpoint),
          timeoutMs: Math.min(15000, Math.max(1000, num(data.timeoutMs, 4000))),
          sortOrder: num(data.sortOrder, 0),
          active: bool(data.active, true),
        })
        .returning();
      return row[0];
    }
    case "testimonials": {
      const row = await db
        .insert(testimonials)
        .values({
          name: str(data.name, 120) ?? "Anonymous",
          role: str(data.role, 120),
          company: str(data.company, 120),
          quote: str(data.quote, 1000) ?? "",
          rating: Math.min(5, Math.max(1, num(data.rating, 5))),
          avatar: str(data.avatar, 400),
          sortOrder: num(data.sortOrder, 0),
          active: bool(data.active, true),
        })
        .returning();
      return row[0];
    }
    case "faqs": {
      const row = await db
        .insert(faqs)
        .values({
          question: str(data.question, 300) ?? "",
          answer: str(data.answer, 3000) ?? "",
          group: str(data.group, 60) ?? "General",
          sortOrder: num(data.sortOrder, 0),
          active: bool(data.active, true),
        })
        .returning();
      return row[0];
    }
    case "coupons": {
      const code = slugify(data.code || "").toUpperCase().replace(/-/g, "");
      if (code.length < 3) throw new ApiError("Coupon code is too short.", 422);
      const row = await db
        .insert(coupons)
        .values({
          code,
          type: data.type === "fixed" ? "fixed" : "percent",
          value: num(data.value, 0).toFixed(2),
          maxUses: num(data.maxUses, 0),
          expiresAt: data.expiresAt ? new Date(String(data.expiresAt)) : null,
          active: bool(data.active, true),
        })
        .returning();
      return row[0];
    }
    case "payment-methods": {
      const key = str(data.key, 30);
      if (!key) throw new ApiError("Method key is required.", 422);
      const existing = await db.select().from(paymentMethods).where(eq(paymentMethods.key, key)).limit(1);
      const config = sanitizeMethodConfig(key, data.config ?? {});
      if (existing[0]) {
        const [updated] = await db
          .update(paymentMethods)
          .set({ name: str(data.name, 80) ?? existing[0].name, enabled: bool(data.enabled, false), config, updatedAt: new Date() })
          .where(eq(paymentMethods.id, existing[0].id))
          .returning();
        return updated;
      }
      const row = await db
        .insert(paymentMethods)
        .values({ key, name: str(data.name, 80) ?? key, enabled: bool(data.enabled, false), config, sortOrder: num(data.sortOrder, 0) })
        .returning();
      return row[0];
    }
    case "homepage": {
      const key = str(data.key, 60);
      if (!key) throw new ApiError("Section key is required.", 422);
      await db
        .insert(homepageSections)
        .values({ key, value: data.value ?? {}, updatedAt: new Date() })
        .onConflictDoUpdate({ target: homepageSections.key, set: { value: data.value ?? {}, updatedAt: new Date() } });
      return { key, value: data.value ?? {} };
    }
    case "settings": {
      const key = str(data.key, 60);
      if (!key) throw new ApiError("Setting key is required.", 422);
      if (key === "payments") sanitizePayments(data.value ?? {});
      if (key === "billing") data.value = sanitizeBilling(data.value ?? {});
      if (key === "branding") data.value = sanitizeBranding(data.value ?? {});
      await db
        .insert(settings)
        .values({ key, value: data.value ?? {}, updatedAt: new Date() })
        .onConflictDoUpdate({ target: settings.key, set: { value: data.value ?? {}, updatedAt: new Date() } });
      return { key, value: data.value ?? {} };
    }
    default:
      throw new ApiError("Unknown resource", 404);
  }
}

export async function createPlan(data: Json, actor: { id: string; name: string }) {
  const name = str(data.name, 160);
  if (!name) throw new ApiError("Plan name is required.", 422);
  const cycles = cleanCycles(data.cycles);
  return db.transaction(async (tx) => {
    const [product] = await tx
      .insert(products)
      .values({
        name,
        slug: slugify(data.slug || name),
        shortDescription: str(data.shortDescription, 320),
        description: str(data.description, 40000),
        categoryId: data.categoryId ? String(data.categoryId) : null,
        icon: str(data.icon, 60) ?? "server",
        image: str(data.image, 400),
        specs: arr(data.specs).map((s: any) => ({ label: str(s.label, 60) ?? "", value: str(s.value, 160) ?? "" })),
        features: arr(data.features).map((f: any) => String(f).slice(0, 300)),
        locations: arr(data.locations).map((l: any) => String(l).slice(0, 80)),
        faqs: arr(data.faqs).map((f: any) => ({ q: String(f.q ?? "").slice(0, 300), a: String(f.a ?? "").slice(0, 2000) })),
        setupFee: num(data.setupFee, 0).toFixed(2),
        taxRate: num(data.taxRate, 0).toFixed(2),
        currency: str(data.currency, 8) ?? "INR",
        sortOrder: num(data.sortOrder, 0),
        active: bool(data.active, true),
        featured: bool(data.featured, false),
        bestSeller: bool(data.bestSeller, false),
        archived: bool(data.archived, false),
        popularity: num(data.popularity, 0),
        seoTitle: str(data.seoTitle, 190),
        seoDescription: str(data.seoDescription, 320),
      })
      .returning();

    await tx.insert(billingCycles).values(cycles.map((c) => ({ ...c, productId: product.id })));
    if (arr(data.tagIds).length) {
      await tx.insert(productTags).values(
        arr(data.tagIds).map((id: any) => ({ productId: product.id, tagId: String(id) })),
      );
    }
    await tx.insert(billingConfigurations).values(await cleanBilling(product.id, data.billing ?? {}));
    return product;
  });
}

export async function updateEntity(entity: string, id: string, data: Json) {
  switch (entity) {
    case "categories": {
      const [row] = await db
        .update(categories)
        .set({
          name: data.name != null ? str(data.name, 120)! : undefined,
          slug: data.slug != null ? slugify(data.slug) : undefined,
          description: data.description != null ? str(data.description, 2000) : undefined,
          icon: data.icon != null ? str(data.icon, 60) : undefined,
          image: data.image != null ? str(data.image, 400) : undefined,
          parentId: data.parentId !== undefined ? (data.parentId ? String(data.parentId) : null) : undefined,
          seoTitle: data.seoTitle != null ? str(data.seoTitle, 190) : undefined,
          seoDescription: data.seoDescription != null ? str(data.seoDescription, 320) : undefined,
          sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
          active: data.active != null ? bool(data.active, true) : undefined,
        })
        .where(eq(categories.id, id))
        .returning();
      if (!row) throw new ApiError("Category not found", 404);
      if (row.parentId === id) throw new ApiError("A category cannot be its own parent.", 422);
      return row;
    }
    case "tags": {
      const [row] = await db
        .update(tags)
        .set({
          name: data.name != null ? str(data.name, 80)! : undefined,
          slug: data.slug != null ? slugify(data.slug) : undefined,
          color: data.color != null && /^#[0-9a-fA-F]{3,8}$/.test(String(data.color)) ? String(data.color) : undefined,
          showOnCards: data.showOnCards != null ? bool(data.showOnCards, true) : undefined,
          sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
          active: data.active != null ? bool(data.active, true) : undefined,
        })
        .where(eq(tags.id, id))
        .returning();
      if (!row) throw new ApiError("Tag not found", 404);
      return row;
    }
    case "plans":
      return updatePlan(id, data);
    case "locations": {
      const [row] = await db
        .update(serverLocations)
        .set({
          name: data.name != null ? str(data.name, 120)! : undefined,
          city: data.city != null ? str(data.city, 80) : undefined,
          country: data.country != null ? str(data.country, 80) : undefined,
          code: data.code != null ? str(data.code, 20) : undefined,
          tier: data.tier != null ? str(data.tier, 20) : undefined,
          endpoint: data.endpoint !== undefined ? normalizeEndpoint(data.endpoint) : undefined,
          timeoutMs: data.timeoutMs != null ? Math.min(15000, Math.max(1000, num(data.timeoutMs, 4000))) : undefined,
          sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
          active: data.active != null ? bool(data.active, true) : undefined,
        })
        .where(eq(serverLocations.id, id))
        .returning();
      if (!row) throw new ApiError("Location not found", 404);
      return row;
    }
    case "testimonials": {
      const [row] = await db
        .update(testimonials)
        .set({
          name: data.name != null ? str(data.name, 120) : undefined,
          role: data.role != null ? str(data.role, 120) : undefined,
          company: data.company != null ? str(data.company, 120) : undefined,
          quote: data.quote != null ? str(data.quote, 1000) : undefined,
          rating: data.rating != null ? Math.min(5, Math.max(1, num(data.rating, 5))) : undefined,
          sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
          active: data.active != null ? bool(data.active, true) : undefined,
        })
        .where(eq(testimonials.id, id))
        .returning();
      if (!row) throw new ApiError("Testimonial not found", 404);
      return row;
    }
    case "faqs": {
      const [row] = await db
        .update(faqs)
        .set({
          question: data.question != null ? str(data.question, 300) : undefined,
          answer: data.answer != null ? str(data.answer, 3000) : undefined,
          group: data.group != null ? str(data.group, 60) : undefined,
          sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
          active: data.active != null ? bool(data.active, true) : undefined,
        })
        .where(eq(faqs.id, id))
        .returning();
      if (!row) throw new ApiError("FAQ not found", 404);
      return row;
    }
    case "coupons": {
      const [row] = await db
        .update(coupons)
        .set({
          value: data.value != null ? num(data.value, 0).toFixed(2) : undefined,
          type: data.type != null ? (data.type === "fixed" ? "fixed" : "percent") : undefined,
          maxUses: data.maxUses != null ? num(data.maxUses, 0) : undefined,
          active: data.active != null ? bool(data.active, true) : undefined,
        })
        .where(eq(coupons.id, id))
        .returning();
      if (!row) throw new ApiError("Coupon not found", 404);
      return row;
    }
    case "payment-methods": {
      const rows = await db.select().from(paymentMethods).where(eq(paymentMethods.id, id)).limit(1);
      if (!rows[0]) throw new ApiError("Payment method not found", 404);
      const config = sanitizeMethodConfig(rows[0].key, { ...((rows[0].config as Json) ?? {}), ...(data.config ?? {}) });
      const [row] = await db
        .update(paymentMethods)
        .set({
          name: data.name != null ? str(data.name, 80) : undefined,
          enabled: data.enabled != null ? bool(data.enabled, false) : undefined,
          sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
          config,
          updatedAt: new Date(),
        })
        .where(eq(paymentMethods.id, id))
        .returning();
      return row;
    }
    case "customers": {
      const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
      if (!rows[0]) throw new ApiError("Customer not found", 404);
      const [row] = await db
        .update(users)
        .set({
          name: data.name != null ? str(data.name, 120) : undefined,
          status: data.status != null && ["active", "suspended"].includes(String(data.status)) ? (String(data.status) as any) : undefined,
          role: data.role != null && ["customer", "support", "product_manager", "finance_manager", "super_admin"].includes(String(data.role)) ? (String(data.role) as any) : undefined,
          updatedAt: new Date(),
        })
        .where(eq(users.id, id))
        .returning();
      return { ...row, passwordHash: undefined };
    }
    case "orders": {
      const [row] = await db
        .update(orders)
        .set({
          status:
            data.status != null &&
            ["pending", "awaiting_payment", "paid", "processing", "active", "cancelled", "failed", "refunded"].includes(String(data.status))
              ? (String(data.status) as any)
              : undefined,
          paymentMethod: data.paymentMethod != null ? str(data.paymentMethod, 30) : undefined,
          updatedAt: new Date(),
        })
        .where(eq(orders.id, id))
        .returning();
      if (!row) throw new ApiError("Order not found", 404);
      return row;
    }
    case "homepage": {
      const key = str(data.key, 60);
      if (!key) throw new ApiError("Section key required", 422);
      await db
        .insert(homepageSections)
        .values({ key, value: data.value ?? {}, updatedAt: new Date() })
        .onConflictDoUpdate({ target: homepageSections.key, set: { value: data.value ?? {}, updatedAt: new Date() } });
      return { key, value: data.value ?? {} };
    }
    case "settings": {
      const key = str(data.key, 60);
      if (!key) throw new ApiError("Setting key required", 422);
      if (key === "payments") sanitizePayments(data.value ?? {});
      if (key === "billing") data.value = sanitizeBilling(data.value ?? {});
      if (key === "branding") data.value = sanitizeBranding(data.value ?? {});
      await db
        .insert(settings)
        .values({ key, value: data.value ?? {}, updatedAt: new Date() })
        .onConflictDoUpdate({ target: settings.key, set: { value: data.value ?? {}, updatedAt: new Date() } });
      return { key, value: data.value ?? {} };
    }
    default:
      throw new ApiError("Unknown resource", 404);
  }
}

export async function updatePlan(id: string, data: Json) {
  const existing = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!existing[0]) throw new ApiError("Plan not found", 404);
  const cycles = data.cycles != null ? cleanCycles(data.cycles) : null;
  return db.transaction(async (tx) => {
    const [product] = await tx
      .update(products)
      .set({
        name: data.name != null ? str(data.name, 160)! : undefined,
        slug: data.slug != null ? slugify(data.slug) : undefined,
        shortDescription: data.shortDescription != null ? str(data.shortDescription, 320) : undefined,
        description: data.description != null ? str(data.description, 40000) : undefined,
        categoryId: data.categoryId !== undefined ? (data.categoryId ? String(data.categoryId) : null) : undefined,
        icon: data.icon != null ? str(data.icon, 60) : undefined,
        image: data.image != null ? str(data.image, 400) : undefined,
        specs: data.specs != null ? arr(data.specs).map((s: any) => ({ label: str(s.label, 60) ?? "", value: str(s.value, 160) ?? "" })) : undefined,
        features: data.features != null ? arr(data.features).map((f: any) => String(f).slice(0, 300)) : undefined,
        locations: data.locations != null ? arr(data.locations).map((l: any) => String(l).slice(0, 80)) : undefined,
        faqs: data.faqs != null ? arr(data.faqs).map((f: any) => ({ q: String(f.q ?? "").slice(0, 300), a: String(f.a ?? "").slice(0, 2000) })) : undefined,
        setupFee: data.setupFee != null ? num(data.setupFee, 0).toFixed(2) : undefined,
        taxRate: data.taxRate != null ? num(data.taxRate, 0).toFixed(2) : undefined,
        currency: data.currency != null ? str(data.currency, 8) : undefined,
        sortOrder: data.sortOrder != null ? num(data.sortOrder, 0) : undefined,
        active: data.active != null ? bool(data.active, true) : undefined,
        featured: data.featured != null ? bool(data.featured, false) : undefined,
        bestSeller: data.bestSeller != null ? bool(data.bestSeller, false) : undefined,
        archived: data.archived != null ? bool(data.archived, false) : undefined,
        seoTitle: data.seoTitle != null ? str(data.seoTitle, 190) : undefined,
        seoDescription: data.seoDescription != null ? str(data.seoDescription, 320) : undefined,
        updatedAt: new Date(),
      })
      .where(eq(products.id, id))
      .returning();

    if (cycles) {
      await tx.delete(billingCycles).where(eq(billingCycles.productId, id));
      await tx.insert(billingCycles).values(cycles.map((c) => ({ ...c, productId: id })));
    }
    if (data.tagIds != null) {
      await tx.delete(productTags).where(eq(productTags.productId, id));
      const ids = arr(data.tagIds).map((t: any) => String(t));
      if (ids.length) await tx.insert(productTags).values(ids.map((tagId) => ({ productId: id, tagId })));
    }
    if (data.billing != null) {
      await tx.delete(billingConfigurations).where(eq(billingConfigurations.productId, id));
      await tx.insert(billingConfigurations).values(await cleanBilling(id, data.billing, id));
    }
    return product;
  });
}

export async function deleteEntity(entity: string, id: string) {
  switch (entity) {
    case "categories": {
      // Children are re-parented rather than orphaned or cascade-deleted.
      await db.update(categories).set({ parentId: null }).where(eq(categories.parentId, id));
      const rows = await db.delete(categories).where(eq(categories.id, id)).returning({ id: categories.id });
      if (!rows[0]) throw new ApiError("Category not found", 404);
      return { id };
    }
    case "tags":
      await db.delete(productTags).where(eq(productTags.tagId, id));
      return drain(db.delete(tags).where(eq(tags.id, id)));
    case "plans": {
      await db.delete(billingConfigurations).where(eq(billingConfigurations.productId, id));
      await db.delete(billingCycles).where(eq(billingCycles.productId, id));
      await db.delete(productTags).where(eq(productTags.productId, id));
      return drain(db.delete(products).where(eq(products.id, id)));
    }
    case "testimonials":
      return drain(db.delete(testimonials).where(eq(testimonials.id, id)));
    case "faqs":
      return drain(db.delete(faqs).where(eq(faqs.id, id)));
    case "coupons":
      return drain(db.delete(coupons).where(eq(coupons.id, id)));
    case "locations":
      return drain(db.delete(serverLocations).where(eq(serverLocations.id, id)));
    default:
      throw new ApiError("This resource cannot be deleted.", 405);
  }
}

async function drain(query: any) {
  const rows = await query.returning({ id: sql`id` });
  if (!rows[0]) throw new ApiError("Not found", 404);
  return { id: String(rows[0].id) };
}

/* ------------------------------ sanitisation ------------------------------ */
export function sanitizeMethodConfig(key: string, config: Json): Json {
  const out: Json = { ...(config ?? {}) };
  if (key === "razorpay") {
    // Never allow a client to read secrets back — blank strings mean "keep existing".
    for (const f of ["keySecret", "webhookSecret"]) {
      if (out[f] === "" || out[f] == null) delete out[f];
    }
    if (!["live", "test"].includes(String(out.mode))) out.mode = "test";
    out.keyId = String(out.keyId ?? "").slice(0, 120);
  }
  if (key === "crypto") {
    if (out.apiKey === "" || out.apiKey == null) delete out.apiKey;
    if (out.ipnSecret === "" || out.ipnSecret == null) delete out.ipnSecret;
    out.provider = ["nowpayments", "coinpayments"].includes(String(out.provider)) ? String(out.provider) : "nowpayments";
    out.coins = arr(out.coins).map((c) => String(c).toUpperCase().slice(0, 12)).slice(0, 8);
  }
  if (key === "qr") {
    out.upiId = String(out.upiId ?? "").slice(0, 80);
    out.instructions = String(out.instructions ?? "").slice(0, 1000);
    const img = String(out.qrImage ?? "");
    if (img && !(img.startsWith("data:image/") || img.startsWith("http") || img.startsWith("/"))) {
      throw new ApiError("QR image must be an uploaded data URL or a trusted path.", 422);
    }
    out.requireScreenshot = bool(out.requireScreenshot, true);
  }
  if (key === "wallet") {
    out.instructions = String(out.instructions ?? "").slice(0, 1000);
    out.topups = arr(out.topups)
      .map((n) => num(n, 0))
      .filter((n) => n >= 100)
      .slice(0, 8);
  }
  return out;
}

/** Payment credentials live in the settings store, never in the client bundle. */
export function sanitizePayments(value: Json): void {
  if (value?.razorpay) {
    const r = value.razorpay;
    if (r.keySecret === "" || r.keySecret == null) delete r.keySecret;
    if (r.webhookSecret === "" || r.webhookSecret == null) delete r.webhookSecret;
  }
  if (value?.crypto) {
    const c = value.crypto;
    if (c.apiKey === "" || c.apiKey == null) delete c.apiKey;
    if (c.ipnSecret === "" || c.ipnSecret == null) delete c.ipnSecret;
  }
}

export async function createUserAccount(data: Json) {
  const name = str(data.name, 120);
  const email = String(data.email ?? "").toLowerCase();
  const password = String(data.password ?? "");
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new ApiError("Valid name and email required.", 422);
  if (password.length < 8) throw new ApiError("Password must be at least 8 characters.", 422);
  const [row] = await db
    .insert(users)
    .values({ name, email, passwordHash: hashPassword(password), role: "customer", status: "active" })
    .returning();
  await db.insert(walletAccounts).values({ userId: row.id, balance: "0" }).onConflictDoNothing();
  return { ...row, passwordHash: undefined };
}


/** Health endpoints must be absolute http(s) — this is what latency actually measures. */
export function normalizeEndpoint(value: unknown): string | null {
  if (value == null || String(value).trim() === "") return null;
  const raw = String(value).trim();
  try {
    const u = new URL(raw);
    if (u.protocol !== "http:" && u.protocol !== "https:") throw new Error("protocol");
    if (u.username || u.password) throw new Error("credentials");
    return u.toString();
  } catch {
    throw new ApiError("Measurement endpoint must be an absolute http(s) URL.", 422);
  }
}


/** Canonical domain + path prefix: normalised, never allowing javascript:/protocol-relative tricks. */
export function sanitizeBilling(value: Json): Json {
  const out: Json = { ...value };
  let domain = String(out.canonicalDomain ?? "").trim().replace(/\/+$/, "");
  if (domain) {
    if (!/^https?:\/\//i.test(domain)) domain = `https://${domain}`;
    try {
      const u = new URL(domain);
      if (u.username || u.password) throw new Error("credentials");
      domain = u.origin;
    } catch {
      throw new ApiError("Canonical domain must be a valid http(s) origin, e.g. https://example.com", 422);
    }
  }
  out.canonicalDomain = domain;
  out.pathPrefix = normalizePrefix(out.pathPrefix || "/order/");
  out.trustedHosts = String(out.trustedHosts ?? "")
    .split(",")
    .map((h) => h.trim().toLowerCase())
    .filter((h) => h && !h.includes("/") && !h.includes(" "))
    .join(", ");
  return out;
}

/** Logos and favicons: only data-URLs, same-origin paths or http(s) URLs are accepted. */
export function sanitizeBranding(value: Json): Json {
  const out: Json = { ...value };
  const image = (v: unknown): string | null => {
    if (v == null || v === "") return null;
    const raw = String(v);
    const ok = raw.startsWith("data:image/") || raw.startsWith("/") || /^https?:\/\//.test(raw);
    if (!ok) throw new ApiError("Branding images must be an uploaded image, a site path or an http(s) URL.", 422);
    if (raw.startsWith("data:image/") && raw.length > 1_600_000) throw new ApiError("Branding image exceeds 1.2 MB.", 422);
    return raw;
  };
  for (const key of ["logo", "logoLight", "logoDark", "favicon"]) out[key] = image(out[key]);
  out.siteName = String(out.siteName ?? "").slice(0, 80);
  out.wordmark = String(out.wordmark ?? "").slice(0, 24);
  out.submark = String(out.submark ?? "").slice(0, 24);
  out.logoWidth = Math.min(320, Math.max(24, Number(out.logoWidth) || 132));
  out.logoHeight = Math.min(96, Math.max(16, Number(out.logoHeight) || 34));
  // The website name also drives the global siteName setting.
  return out;
}
