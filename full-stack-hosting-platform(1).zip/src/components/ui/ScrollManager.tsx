"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

/**
 * Keeps CSS smooth-scrolling for in-page anchors while making route changes
 * jump instantly to the top. Without this, `scroll-behavior: smooth` turns
 * every navigation into an animated scroll from the previous page's offset,
 * which reads as broken/jumpy scrolling.
 */
export function ScrollManager() {
  const pathname = usePathname();
  const first = useRef(true);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const html = document.documentElement;
    const previous = html.style.scrollBehavior;
    html.style.scrollBehavior = "auto";
    // Preserve the browser's own restoration for back/forward navigations.
    if (window.history.scrollRestoration !== "manual") window.history.scrollRestoration = "manual";
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
    const id = window.setTimeout(() => {
      html.style.scrollBehavior = previous;
    }, 60);
    return () => window.clearTimeout(id);
  }, [pathname]);

  useEffect(() => {
    // Close any leftover scroll locks when the route changes (e.g. a modal was open).
    document.body.classList.remove("scroll-locked");
  }, [pathname]);

  return null;
}
