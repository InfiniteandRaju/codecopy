"use client";

import { motion, useReducedMotion } from "framer-motion";

export function Reveal({
  children,
  delay = 0,
  y = 22,
  className = "",
  as = "div",
}: {
  children: React.ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  as?: "div" | "section" | "li" | "article";
}) {
  const reduce = useReducedMotion();
  const Tag = motion[as] as any;
  return (
    <Tag
      className={className}
      initial={reduce ? false : { opacity: 0, y, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.62, delay, ease: [0.16, 0.8, 0.28, 1] }}
    >
      {children}
    </Tag>
  );
}

/** A unit sliding into the rack: 24px travel, tight settle. */
export function SeatIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, x: -24 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ type: "spring", stiffness: 260, damping: 30, delay }}
    >
      {children}
    </motion.div>
  );
}

export function SectionHead({
  index,
  legend,
  title,
  description,
  right,
}: {
  index: string;
  legend: string;
  title: React.ReactNode;
  description?: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="mb-10 flex flex-col gap-6 md:mb-14 md:flex-row md:items-end md:justify-between">
      <div className="max-w-3xl">
        <div className="text-signal legend mb-4 flex items-center gap-3">
          <span>{index}</span>
          <span className="bg-line-2 h-px w-8" />
          <span className="text-mute">{legend}</span>
        </div>
        <h2 className="text-[clamp(1.9rem,4.2vw,3.25rem)] font-semibold">{title}</h2>
        {description && <p className="text-mute mt-4 max-w-2xl text-[15.5px] leading-relaxed">{description}</p>}
      </div>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  );
}
