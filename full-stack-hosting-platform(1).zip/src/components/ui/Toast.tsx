"use client";

import { createContext, useCallback, useContext, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, AlertTriangle, Info, X } from "lucide-react";

type Toast = { id: number; kind: "ok" | "err" | "info"; message: string };
const Ctx = createContext<{ push: (m: string, kind?: Toast["kind"]) => void }>({ push: () => {} });

export function useToast() {
  return useContext(Ctx);
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((message: string, kind: Toast["kind"] = "ok") => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev, { id, kind, message }]);
    setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4200);
  }, []);

  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-5 right-5 z-[100] flex w-[min(360px,calc(100vw-40px))] flex-col gap-2">
        <AnimatePresence>
          {items.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, x: 32, scale: 0.97 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 32, scale: 0.97 }}
              transition={{ type: "spring", stiffness: 420, damping: 34 }}
              className="panel pointer-events-auto flex items-start gap-3 px-4 py-3"
            >
              <span
                className={
                  t.kind === "ok" ? "text-led mt-0.5" : t.kind === "err" ? "text-signal mt-0.5" : "text-link mt-0.5"
                }
              >
                {t.kind === "ok" ? <CheckCircle2 size={16} /> : t.kind === "err" ? <AlertTriangle size={16} /> : <Info size={16} />}
              </span>
              <p className="text-fore flex-1 text-[13px] leading-snug">{t.message}</p>
              <button
                onClick={() => setItems((prev) => prev.filter((x) => x.id !== t.id))}
                className="text-mute hover:text-chalk transition-colors"
                aria-label="Dismiss"
              >
                <X size={14} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  );
}
