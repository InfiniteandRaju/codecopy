import Link from "next/link";
import { ChevronRight } from "lucide-react";

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-2">
      {items.map((item, i) => (
        <span key={i} className="flex items-center gap-2">
          {i > 0 && <ChevronRight size={11} className="text-mute/50" />}
          {item.href ? (
            <Link href={item.href} className="legend text-mute hover:text-signal transition-colors">
              {item.label}
            </Link>
          ) : (
            <span className="legend text-fore">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}
