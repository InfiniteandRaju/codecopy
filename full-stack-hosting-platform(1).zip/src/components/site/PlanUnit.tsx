"use client";

import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Check } from "lucide-react";
import { useOrder } from "@/lib/useOrder";

export type Cycle = { id?: string; key: string; label: string; months: number; price: string; compareAt: string | null; active: boolean };
export type PlanTag = { id?: string; name: string; slug: string; color: string; showOnCards: boolean };
export type PlanLike = {
  id: string;
  name: string;
  slug: string;
  shortDescription?: string | null;
  specs?: any;
  cycles: Cycle[];
  tags: PlanTag[];
  categoryName?: string | null;
  featured?: boolean;
  bestSeller?: boolean;
};

export function TagChip({ tag, small = false }: { tag: PlanTag; small?: boolean }) {
  if (!tag.showOnCards) return null;
  return (
    <span
      className={`legend inline-flex items-center gap-1.5 border px-2 ${small ? "py-0.5 text-[9px]" : "py-1"}`}
      style={{
        color: tag.color,
        borderColor: `${tag.color}44`,
        background: `${tag.color}12`,
      }}
    >
      <span className="h-1 w-1 rounded-full" style={{ background: tag.color }} />
      {tag.name}
    </span>
  );
}

function fmt(n: number) {
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

/**
 * A pricing card drawn as a 1U rack front panel: engraved index, vent mesh,
 * status LED, and a billing-cycle selector that reprices live.
 */
export function PlanUnit({
  plan,
  index = 0,
  symbol = "₹",
  href,
}: {
  plan: PlanLike;
  index?: number;
  symbol?: string;
  href?: string;
}) {
  const activeCycles = plan.cycles.filter((c) => c.active !== false);
  const [selected, setSelected] = useState(
    activeCycles.find((c) => c.key === "monthly")?.key ?? activeCycles[0]?.key ?? "",
  );
  const { order, busy } = useOrder();
  const cycle = activeCycles.find((c) => c.key === selected) ?? activeCycles[0];
  const price = cycle ? Number(cycle.price) : 0;
  const compare = cycle?.compareAt ? Number(cycle.compareAt) : null;
  const saving = compare && compare > price ? Math.round(((compare - price) / compare) * 100) : 0;
  const monthly = cycle && cycle.months > 1 ? price / cycle.months : price;
  const specs = (Array.isArray(plan.specs) ? plan.specs : []).slice(0, 3);
  const link = href ?? `/plans/${plan.slug}`;

  return (
    <motion.article
      initial={{ opacity: 0, x: -24 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ type: "spring", stiffness: 250, damping: 30, delay: Math.min(index, 6) * 0.06 }}
      className="panel group relative overflow-hidden transition-all duration-300 hover:border-line-2"
    >
      {/* vent mesh — right third of the unit */}
      <div className="vent absolute inset-y-0 right-0 hidden w-[132px] border-l border-line/70 opacity-70 transition-opacity duration-500 group-hover:opacity-95 lg:block" />
      <div
        className={`led absolute top-4 right-4 z-10 h-2 w-2 rounded-full lg:right-[148px] ${
          plan.bestSeller ? "bg-signal text-signal led-pulse" : plan.featured ? "bg-link text-link" : "bg-led text-led"
        }`}
      />

      <div className="relative grid gap-6 p-6 lg:grid-cols-[1fr_260px] lg:pr-[172px] lg:p-7">
        <div className="min-w-0">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <span className="legend text-signal">
              UNIT {String(index + 1).padStart(2, "0")}
            </span>
            {plan.categoryName && (
              <>
                <span className="bg-line-2 h-px w-5" />
                <span className="legend text-mute">{plan.categoryName}</span>
              </>
            )}
          </div>

          <Link href={link} className="block">
            <h3 className="group-hover:text-signal-2 text-[clamp(1.25rem,2vw,1.6rem)] font-semibold transition-colors">
              {plan.name}
            </h3>
          </Link>

          {plan.tags.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {plan.tags.filter((t) => t.showOnCards).slice(0, 4).map((t) => (
                <TagChip key={t.id ?? t.slug} tag={t} small />
              ))}
            </div>
          )}

          {plan.shortDescription && (
            <p className="text-mute mt-3 max-w-xl text-[14px] leading-relaxed">{plan.shortDescription}</p>
          )}

          {specs.length > 0 && (
            <dl className="mt-5 grid max-w-lg grid-cols-3 gap-px bg-line/60">
              {specs.map((s: any, i: number) => (
                <div key={i} className="bg-panel px-3 py-2.5">
                  <dt className="legend text-mute text-[8.5px]">{s.label}</dt>
                  <dd className="num text-fore mt-1 truncate text-[12.5px]">{s.value}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>

        {/* price column */}
        <div className="flex flex-col justify-between gap-4 border-line lg:border-l lg:pl-6">
          <div>
            {activeCycles.length > 1 && (
              <div className="mb-4 flex flex-wrap gap-1">
                {activeCycles.map((c) => (
                  <button
                    key={c.key}
                    onClick={() => setSelected(c.key)}
                    className={`legend border px-2 py-1.5 transition-all ${
                      c.key === selected
                        ? "border-signal/70 bg-signal/12 text-signal"
                        : "border-line text-mute hover:border-line-2 hover:text-fore"
                    }`}
                  >
                    {c.months > 1 ? `${c.months}M` : "M"}
                  </button>
                ))}
              </div>
            )}

            <div className="flex items-end gap-2">
              <span className="num text-chalk text-[2.6rem] leading-none font-semibold tracking-tight">
                {symbol}
                {fmt(monthly)}
              </span>
              <span className="legend text-mute mb-1.5">/mo</span>
            </div>

            <div className="mt-2 flex flex-wrap items-center gap-2">
              {compare && saving > 0 && (
                <>
                  <span className="num text-mute text-[13px] line-through">
                    {symbol}
                    {fmt(compare / (cycle?.months || 1))}
                  </span>
                  <span className="legend bg-led/12 text-led border-led/30 border px-1.5 py-0.5">SAVE {saving}%</span>
                </>
              )}
              {cycle && cycle.months > 1 && (
                <span className="legend text-mute">
                  {symbol}
                  {fmt(price)} / {cycle.label.toLowerCase()}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <button
              onClick={() => order({ slug: plan.slug, cycleKey: cycle?.key }, plan.id)}
              disabled={busy === plan.id}
              className="bg-signal text-void hover:bg-signal-2 legend flex w-full items-center justify-center gap-2 py-3 font-semibold transition-colors disabled:opacity-60"
            >
              {busy === plan.id ? "WORKING…" : "ORDER NOW"}
              <ArrowUpRight size={13} />
            </button>
            <Link
              href={link}
              className="border-line text-mute hover:text-chalk hover:border-line-2 flex w-full items-center justify-center gap-1.5 border py-2.5 text-[12.5px] transition-all"
            >
              Specifications <Check size={12} className="text-link" />
            </Link>
          </div>
        </div>
      </div>
    </motion.article>
  );
}
