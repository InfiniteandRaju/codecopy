"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Wallet,
  CreditCard,
  Bitcoin,
  QrCode,
  Loader2,
  CheckCircle2,
  Clock,
  ExternalLink,
  ShieldCheck,
} from "lucide-react";
import { useToast } from "@/components/ui/Toast";
import { Mark } from "@/components/site/Mark";

const ICONS: Record<string, any> = { wallet: Wallet, razorpay: CreditCard, crypto: Bitcoin, qr: QrCode };

type Payload = {
  order: any;
  plan: any;
  cycle: any;
  methods: any[];
  currencySymbol: string;
  taxLabel: string;
};

export function CheckoutClient({ initial }: { initial?: Payload | null } = {}) {
  const [payload, setPayload] = useState<Payload | null>(initial ?? null);
  const [method, setMethod] = useState("wallet");
  const [balance, setBalance] = useState<number | null>(null);
  const [status, setStatus] = useState<string>("pending");
  const [busy, setBusy] = useState(false);
  const [invoice, setInvoice] = useState<any>(null);
  const [utr, setUtr] = useState("");
  const [proof, setProof] = useState<string | null>(null);
  const { push } = useToast();

  useEffect(() => {
    if (initial) {
      setStatus(initial.order?.status ?? "pending");
      setMethod(initial.methods?.[0]?.key ?? "wallet");
    }
    const raw = sessionStorage.getItem("obs_checkout");
    if (raw && !initial) {
      try {
        const data = JSON.parse(raw);
        setPayload(data);
        setStatus(data.order?.status ?? "pending");
        setMethod(data.methods?.[0]?.key ?? "wallet");
      } catch {
        sessionStorage.removeItem("obs_checkout");
      }
    }
    fetch("/api/wallet")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d && setBalance(Number(d.balance)))
      .catch(() => {});
  }, []);

  const symbol = payload?.currencySymbol ?? "₹";
  const total = Number(payload?.order?.total ?? 0);
  const selected = useMemo(() => payload?.methods?.find((m: any) => m.key === method) ?? payload?.methods?.[0], [payload, method]);

  const verifyStatus = async () => {
    if (!payload?.order) return;
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "status", orderId: payload.order.id }),
    });
    const d = await res.json();
    if (res.ok && d.status) {
      setStatus(d.status);
      if (d.status === "paid" || d.status === "active") push("Payment confirmed. Your order is being provisioned.", "ok");
    }
  };

  useEffect(() => {
    if (status === "paid" || status === "active") return;
    const id = setInterval(verifyStatus, 5000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, payload?.order?.id]);

  const call = async (body: Record<string, any>) => {
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error ?? "Payment request failed");
    return data;
  };

  const openRazorpay = async (data: any) => {
    await new Promise<void>((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        const rzp = new (window as any).Razorpay({
          key: data.keyId,
          amount: data.razorpayOrder.amount,
          currency: data.razorpayOrder.currency,
          name: "Obsidian Node",
          description: `${payload?.order?.planName} · ${payload?.order?.reference}`,
          order_id: data.razorpayOrder.id,
          theme: { color: "#FF6B18" },
          handler: async (res: any) => {
            try {
              const verify = await call({ action: "razorpay_verify", ...res });
              setStatus(verify.order?.status ?? "paid");
              push("Payment verified.", "ok");
              resolve();
            } catch (e: any) {
              push(e.message, "err");
              resolve();
            }
          },
          modal: { ondismiss: () => resolve() },
        });
        rzp.open();
      };
      script.onerror = () => reject(new Error("Unable to load Razorpay checkout."));
      document.body.appendChild(script);
    });
  };

  const pay = async () => {
    if (!payload?.order || busy) return;
    setBusy(true);
    try {
      if (method === "wallet") {
        const d = await call({ action: "wallet", orderId: payload.order.id });
        setStatus(d.order?.status ?? "paid");
        setBalance(Number(d.balance));
        push("Paid from wallet balance.", "ok");
      } else if (method === "razorpay") {
        const d = await call({ action: "razorpay_order", orderId: payload.order.id });
        await openRazorpay(d);
        verifyStatus();
      } else if (method === "crypto") {
        const d = await call({ action: "crypto", orderId: payload.order.id });
        setInvoice(d);
        push("Invoice created. Confirmation arrives via provider webhook.", "info");
      } else if (method === "qr") {
        const d = await call({ action: "qr", orderId: payload.order.id, utr, proofUrl: proof, note: "Order payment" });
        setStatus("awaiting_payment");
        setInvoice(null);
        push(d.message ?? "Submitted for verification.", "ok");
      }
    } catch (e: any) {
      push(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  const onFile = (file?: File) => {
    if (!file) return;
    if (file.size > 1_200_000) return push("Screenshot must be under 1.2 MB.", "err");
    const reader = new FileReader();
    reader.onload = () => setProof(String(reader.result));
    reader.readAsDataURL(file);
  };

  if (!payload) {
    return (
      <div className="border-line panel mx-auto max-w-xl p-12 text-center">
        <Mark size={36} className="mx-auto" />
        <h1 className="mt-5 text-[22px] font-semibold">No order in progress</h1>
        <p className="text-mute mt-3 text-[14.5px]">Pick a plan from the catalogue to start a checkout.</p>
        <Link href="/pricing" className="bg-signal text-void legend mt-6 inline-block px-6 py-3 font-semibold">
          BROWSE PLANS
        </Link>
      </div>
    );
  }

  const settled = status === "paid" || status === "active";

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_400px]">
      <div className="flex flex-col gap-5">
        <div className="panel">
          <div className="border-line flex items-center justify-between border-b px-5 py-3.5">
            <span className="legend text-signal">SELECT PAYMENT METHOD</span>
            <span className="legend text-mute">{payload.order.reference}</span>
          </div>
          <div className="grid gap-3 p-5 sm:grid-cols-2">
            {(payload.methods ?? []).map((m: any) => {
              const Icon = ICONS[m.key] ?? CreditCard;
              const on = method === m.key;
              const unavailable = (m.key === "razorpay" || m.key === "crypto") && m.config?.configured === false;
              return (
                <button
                  key={m.key}
                  onClick={() => setMethod(m.key)}
                  disabled={unavailable}
                  className={`border p-4 text-left transition-all disabled:cursor-not-allowed disabled:opacity-45 ${
                    on ? "border-signal/70 bg-signal/10" : "border-line hover:border-line-2 hover:bg-raised/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <Icon size={18} className={on ? "text-signal" : "text-mute"} />
                    {on && <CheckCircle2 size={15} className="text-signal" />}
                  </div>
                  <div className={`mt-3 text-[14.5px] font-medium ${on ? "text-chalk" : "text-fore"}`}>{m.name}</div>
                  <div className="legend text-mute mt-1 text-[8.5px]">
                    {unavailable ? "AWAITING API CREDENTIALS" : m.key === "wallet" ? `BALANCE ${balance != null ? symbol + Number(balance).toLocaleString("en-IN") : "…"}` : "AVAILABLE"}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="border-line border-t p-5">
            {method === "qr" && (
              <div className="flex flex-col gap-3">
                <p className="text-fore text-[14px]">{selected?.config?.instructions ?? "Transfer the exact amount and submit your reference."}</p>
                {selected?.config?.qrImage && (
                  <img src={selected.config.qrImage} alt="Payment QR" className="h-44 w-44 border border-line bg-white p-1" />
                )}
                <div className="num text-chalk text-[14.5px]">UPI: {selected?.config?.upiId ?? "—"}</div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <input
                    value={utr}
                    onChange={(e) => setUtr(e.target.value.toUpperCase())}
                    placeholder="UTR / transaction reference"
                    className="border-line bg-raised text-fore border px-3 py-2.5 text-[13.5px] outline-none"
                  />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => onFile(e.target.files?.[0])}
                    className="text-mute border-line border px-3 py-2 text-[12px] file:mr-3 file:border-0 file:bg-raised file:px-3 file:py-1.5 file:text-fore"
                  />
                </div>
              </div>
            )}

            {method === "crypto" && (
              <div className="flex flex-col gap-3">
                <p className="text-fore text-[14px]">
                  An invoice is created through {selected?.config?.provider ?? "our provider"}. Payment is confirmed only
                  when the provider's signed webhook arrives — submitting a transaction hash never marks an order paid.
                </p>
                <div className="flex flex-wrap gap-2">
                  {(selected?.config?.coins ?? []).map((c: string) => (
                    <span key={c} className="legend border-line text-mute border px-2.5 py-1">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {method === "wallet" && (
              <p className="text-fore text-[14px]">
                Pay instantly from your Obsidian Node wallet. The ledger is debited atomically — insufficient balance is
                rejected before any order state changes.
                {balance != null && (
                  <>
                    {" "}
                    Available: <span className="num text-chalk">
                      {symbol}
                      {balance.toLocaleString("en-IN")}
                    </span>
                    {balance < total && <span className="text-signal"> — insufficient, top up first</span>}
                  </>
                )}
              </p>
            )}

            {method === "razorpay" && (
              <p className="text-fore text-[14px]">
                UPI, credit and debit cards, net banking and wallets. The order is created server-side with Razorpay and
                the signature is verified before your order is marked paid.
              </p>
            )}

            {invoice?.invoice?.invoice_url && (
              <div className="border-link/40 bg-link/8 mt-4 border p-4">
                <div className="legend text-link mb-2">PAYMENT INVOICE</div>
                <a
                  href={invoice.invoice_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-fore flex items-center gap-2 text-[13.5px] underline"
                >
                  {invoice.invoice_url} <ExternalLink size={12} />
                </a>
              </div>
            )}
          </div>

          <div className="border-line flex flex-wrap items-center justify-between gap-4 border-t p-5">
            <div className="flex items-center gap-3">
              <span className={`led h-2 w-2 rounded-full ${settled ? "bg-led text-led" : "bg-signal text-signal led-pulse"}`} />
              <span className="legend text-mute">
                STATUS: {String(status).replace("_", " ").toUpperCase()}
              </span>
            </div>
            <button
              onClick={pay}
              disabled={busy || settled || (method === "qr" && utr.length < 6) || (method === "wallet" && balance != null && balance < total)}
              className="bg-signal text-void hover:bg-signal-2 flex items-center gap-2 px-6 py-3 text-[13.5px] font-semibold transition-colors disabled:opacity-50"
            >
              {busy ? (
                <>
                  <Loader2 size={14} className="animate-spin" /> WORKING…
                </>
              ) : settled ? (
                <>
                  <CheckCircle2 size={14} /> PAID
                </>
              ) : method === "qr" ? (
                "SUBMIT REFERENCE"
              ) : method === "crypto" ? (
                "CREATE CRYPTO INVOICE"
              ) : (
                <>
                  PAY {symbol}
                  {total.toLocaleString("en-IN")}
                </>
              )}
            </button>
          </div>
        </div>

        <div className="border-line text-mute flex flex-wrap items-center gap-x-6 gap-y-2 border border-dashed px-5 py-4 text-[12.5px]">
          <span className="flex items-center gap-2">
            <ShieldCheck size={14} className="text-led" /> Prices and payment status are verified server-side
          </span>
          <span className="flex items-center gap-2">
            <Clock size={14} className="text-link" /> Provisioning starts automatically after confirmation
          </span>
        </div>
      </div>

      <aside className="lg:sticky lg:top-24 lg:self-start">
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="panel">
          <div className="border-line border-b px-5 py-3.5">
            <span className="legend text-signal">ORDER SUMMARY</span>
          </div>
          <dl className="flex flex-col gap-3 p-5 text-[13.5px]">
            <div className="flex justify-between">
              <dt className="text-mute">Plan</dt>
              <dd className="text-chalk text-right">{payload.plan?.name ?? payload.order.planName}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-mute">Billing period</dt>
              <dd className="num text-fore">{payload.cycle?.label ?? payload.order.cycleLabel}</dd>
            </div>
            {payload.order.location && (
              <div className="flex justify-between">
                <dt className="text-mute">Location</dt>
                <dd className="text-fore">{payload.order.location}</dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-mute">Subtotal</dt>
              <dd className="num text-fore">
                {symbol}
                {Number(payload.order.subtotal).toLocaleString("en-IN")}
              </dd>
            </div>
            {Number(payload.order.discount) > 0 && (
              <div className="flex justify-between">
                <dt className="text-mute">Discount ({payload.order.couponCode})</dt>
                <dd className="num text-led">
                  −
                  {symbol}
                  {Number(payload.order.discount).toLocaleString("en-IN")}
                </dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-mute">{payload.taxLabel} on order</dt>
              <dd className="num text-fore">
                {symbol}
                {Number(payload.order.tax).toLocaleString("en-IN")}
              </dd>
            </div>
            <div className="border-line flex items-baseline justify-between border-t pt-3">
              <dt className="text-chalk font-medium">Total</dt>
              <dd className="num text-chalk text-[22px] font-semibold">
                {symbol}
                {total.toLocaleString("en-IN")}
              </dd>
            </div>
          </dl>
          <div className="border-line border-t px-5 py-4">
            <div className="legend text-mute leading-relaxed">
              ORDER ID {payload.order.reference}
              <br />
              PLACED {new Date(payload.order.createdAt).toLocaleString("en-IN")}
            </div>
            <Link href="/account" className="text-signal link-underline legend mt-3 inline-block">
              VIEW ALL ORDERS →
            </Link>
          </div>
        </motion.div>
      </aside>
    </div>
  );
}
