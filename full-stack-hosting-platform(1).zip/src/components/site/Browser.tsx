"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { Search, SlidersHorizontal, X, ChevronDown, Check } from "lucide-react";
import { PlanUnit, type PlanLike } from "@/components/site/PlanUnit";

type Node = { id: string; name: string; slug: string; icon?: string; children?: Node[] };

export function Browser({
  categories,
  tags,
  initialPlans,
  symbol = "₹",
  activeCategory,
}: {
  categories: Node[];
  tags: any[];
  initialPlans: PlanLike[];
  symbol?: string;
  activeCategory?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [query, setQuery] = useState(params.get("q") ?? "");
  const [sort, setSort] = useState(params.get("sort") ?? "default");
  const [tag, setTag] = useState(params.get("tag") ?? "");
  const [category, setCategory] = useState(params.get("category") ?? activeCategory ?? "");
  const [max, setMax] = useState(params.get("max") ?? "");
  const [discounted, setDiscounted] = useState(params.get("discounted") === "1");
  const [plans, setPlans] = useState<PlanLike[]>(initialPlans);
  const [loading, setLoading] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const first = useRef(true);

  const apply = useCallback(
    async (next: Record<string, string | undefined>) => {
      const sp = new URLSearchParams();
      const merged = { q: query, sort, tag, category, max, discounted: discounted ? "1" : "", ...next };
      Object.entries(merged).forEach(([k, v]) => {
        if (v && v !== "default" && v !== "all") sp.set(k, String(v));
      });
      const qs = sp.toString();
      router.replace(`${pathname}${qs ? `?${qs}` : ""}`, { scroll: false });
      setLoading(true);
      try {
        const res = await fetch(`/api/plans?${sp.toString()}`);
        const data = await res.json();
        setPlans(data.plans ?? []);
      } catch {
        /* keep current list */
      } finally {
        setLoading(false);
      }
    },
    [query, sort, tag, category, max, discounted, router, pathname],
  );

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const id = setTimeout(() => apply({}), 260);
    return () => clearTimeout(id);
  }, [query, sort, tag, category, max, discounted, apply]);

  const reset = () => {
    setQuery("");
    setSort("default");
    setTag("");
    setCategory("");
    setMax("");
    setDiscounted(false);
    router.replace(pathname, { scroll: false });
    setLoading(true);
    fetch("/api/plans")
      .then((r) => r.json())
      .then((d) => setPlans(d.plans ?? []))
      .finally(() => setLoading(false));
  };

  const setCat = (slug: string) => {
    setCategory(slug === category ? "" : slug);
    if (pathname !== "/pricing") router.push(slug ? `/pricing?category=${slug}` : "/pricing", { scroll: false });
  };

  const total = plans.length;

  const filterPanel = (
    <div className="flex flex-col gap-8">
      <div>
        <div className="legend text-signal mb-3">SEARCH</div>
        <div className="border-line bg-panel focus-within:border-signal/60 flex items-center gap-2 border px-3 py-2.5 transition-colors">
          <Search size={14} className="text-mute" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Plan, processor, workload…"
            className="placeholder:text-mute/70 w-full bg-transparent text-[13.5px] text-fore outline-none"
          />
          {query && (
            <button onClick={() => setQuery("")} aria-label="Clear search" className="text-mute hover:text-signal">
              <X size={13} />
            </button>
          )}
        </div>
      </div>

      <div>
        <div className="legend text-signal mb-3">CATEGORY TREE</div>
        <div className="flex flex-col gap-0.5">
          <button
            onClick={() => setCat("")}
            className={`flex items-center justify-between border-l-2 py-2 pl-3 text-[13.5px] transition-all ${
              category === "" ? "border-signal bg-signal/8 text-chalk" : "border-transparent text-mute hover:text-fore"
            }`}
          >
            All services <span className="legend text-mute">{plans.length}</span>
          </button>
          <Tree nodes={categories} depth={0} active={category} onPick={setCat} />
        </div>
      </div>

      <div>
        <div className="legend text-signal mb-3">FILTER BY TAG</div>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setTag("")}
            className={`legend border px-2.5 py-1.5 transition-all ${
              tag === "" ? "border-signal/70 bg-signal/12 text-signal" : "border-line text-mute hover:border-line-2"
            }`}
          >
            ANY
          </button>
          {tags.map((t) => (
            <button
              key={t.id}
              onClick={() => setTag(tag === t.slug ? "" : t.slug)}
              className="legend border px-2.5 py-1.5 transition-all"
              style={{
                color: tag === t.slug ? t.color : "#8A94A8",
                borderColor: tag === t.slug ? `${t.color}77` : "#1E2636",
                background: tag === t.slug ? `${t.color}14` : "transparent",
              }}
            >
              {t.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="legend text-signal mb-3">MONTHLY PRICE</div>
        <div className="flex items-center gap-2">
          <input
            type="range"
            min={0}
            max={20000}
            step={250}
            value={max === "" ? 20000 : Number(max)}
            onChange={(e) => setMax(Number(e.target.value) >= 20000 ? "" : e.target.value)}
            className="accent-signal w-full"
            aria-label="Maximum monthly price"
          />
          <span className="num text-fore w-24 shrink-0 text-right text-[12.5px]">
            {max === "" ? "Any" : `≤ ${symbol}${Number(max).toLocaleString("en-IN")}`}
          </span>
        </div>
      </div>

      <div>
        <div className="legend text-signal mb-3">SORT</div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
          className="border-line bg-panel text-fore w-full border px-3 py-2.5 text-[13.5px] outline-none"
        >
          <option value="default">Recommended</option>
          <option value="price_asc">Price — low to high</option>
          <option value="price_desc">Price — high to low</option>
          <option value="popular">Most popular</option>
          <option value="name">Name A–Z</option>
        </select>
        <label className="border-line hover:border-line-2 mt-3 flex cursor-pointer items-center gap-2.5 border px-3 py-2.5 transition-colors">
          <span
            className={`flex h-4 w-4 items-center justify-center border ${
              discounted ? "border-signal bg-signal text-void" : "border-line-2"
            }`}
          >
            {discounted && <Check size={11} />}
          </span>
          <input type="checkbox" checked={discounted} onChange={(e) => setDiscounted(e.target.checked)} className="sr-only" />
          <span className="text-fore text-[13px]">Discounted plans only</span>
        </label>
      </div>

      <button onClick={reset} className="border-line text-mute hover:border-signal/50 hover:text-signal border py-2.5 text-[12.5px] transition-all">
        Reset all filters
      </button>
    </div>
  );

  return (
    <div className="grid gap-8 lg:grid-cols-[264px_1fr]">
      <div className="lg:sticky lg:top-24 lg:max-h-[calc(100vh-120px)] lg:self-start lg:overflow-y-auto lg:pr-2 thin-scroll">
        <div className="hidden lg:block">{filterPanel}</div>
        <button
          onClick={() => setFiltersOpen((v) => !v)}
          className="border-line text-fore flex w-full items-center justify-between border px-4 py-3 text-[13.5px] lg:hidden"
        >
          <span className="flex items-center gap-2">
            <SlidersHorizontal size={14} className="text-signal" /> Filters & sorting
          </span>
          <ChevronDown size={15} className={`transition-transform ${filtersOpen ? "rotate-180" : ""}`} />
        </button>
        {filtersOpen && <div className="mt-5 lg:hidden">{filterPanel}</div>}
      </div>

      <div>
        <div className="border-line mb-5 flex items-center justify-between border-b pb-4">
          <p className="legend text-mute">
            <span className="text-signal">{String(total).padStart(2, "0")}</span> PLANS MATCH
            {category && <span className="ml-2">· /{category}</span>}
            {tag && <span className="ml-2">· TAG {tag}</span>}
          </p>
          <span className={`legend ${loading ? "text-signal" : "text-mute/60"} transition-colors`}>
            {loading ? "QUERYING…" : "LIVE FROM DATABASE"}
          </span>
        </div>

        <div className={`flex flex-col gap-4 transition-opacity duration-200 ${loading ? "opacity-50" : "opacity-100"}`}>
          {plans.map((plan, i) => (
            <PlanUnit key={plan.id} plan={plan} index={i} symbol={symbol} />
          ))}
          {plans.length === 0 && !loading && (
            <div className="border-line border-dashed px-6 py-16 text-center">
              <p className="text-chalk text-[16px] font-medium">No plans match those filters</p>
              <p className="text-mute mt-2 text-[13.5px]">Widen the price range or clear a tag to see more units.</p>
              <button onClick={reset} className="bg-signal text-void legend mt-5 px-5 py-2.5 font-semibold">
                RESET FILTERS
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Tree({ nodes, depth, active, onPick }: { nodes: Node[]; depth: number; active: string; onPick: (s: string) => void }) {
  const [open, setOpen] = useState<Record<string, boolean>>(() => {
    const seed: Record<string, boolean> = {};
    const walk = (list: Node[]) =>
      list.forEach((n) => {
        if (n.children?.some((c) => c.slug === active || c.children?.length)) seed[n.id] = true;
        if (n.children) walk(n.children);
      });
    walk(nodes);
    return seed;
  });

  return (
    <>
      {nodes.map((node) => {
        const hasKids = (node.children?.length ?? 0) > 0;
        const isOpen = open[node.id] ?? false;
        const isActive = active === node.slug;
        return (
          <div key={node.id}>
            <div
              className={`flex items-center border-l-2 transition-all ${
                isActive ? "border-signal bg-signal/8" : "border-transparent hover:bg-raised/60"
              }`}
            >
              <button
                onClick={() => onPick(node.slug)}
                className={`flex-1 py-2 pl-3 text-left text-[13.5px] transition-colors ${
                  isActive ? "text-chalk" : "text-mute hover:text-fore"
                }`}
                style={{ paddingLeft: 12 + depth * 12 }}
              >
                {node.name}
              </button>
              {hasKids && (
                <button
                  onClick={() => setOpen((o) => ({ ...o, [node.id]: !isOpen }))}
                  aria-label={isOpen ? "Collapse" : "Expand"}
                  className={`text-mute hover:text-signal px-3 transition-transform ${isOpen ? "rotate-180" : ""}`}
                >
                  <ChevronDown size={13} />
                </button>
              )}
            </div>
            {hasKids && isOpen && (
              <div className="border-line/60 ml-4 border-l pl-0">
                <Tree nodes={node.children!} depth={depth + 1} active={active} onPick={onPick} />
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}
