"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Play, Square, RotateCcw, Info, Clock, Plus, RefreshCw, ExternalLink, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/Toast";
import { Countdown } from "@/components/site/FreeServerConfigurator";

const STATUS_TONE: Record<string, string> = {
  running: "border-led/40 bg-led/10 text-led",
  pending: "border-signal/40 bg-signal/10 text-signal",
  stopped: "border-line text-mute",
  expired: "border-line text-mute",
  terminated: "border-red-500/40 bg-red-500/10 text-red-400",
  failed: "border-red-500/40 bg-red-500/10 text-red-400",
  suspended: "border-signal/40 bg-signal/10 text-signal",
};

const mb = (v: number) => (v >= 1024 ? `${(v / 1024).toFixed(v % 1024 === 0 ? 0 : 1)} GB` : `${v} MB`);

/** Customer dashboard list of demo servers: real actions against their own servers only. */
export function DemoServers() {
  const { push } = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [provisioning, setProvisioning] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [detail, setDetail] = useState<any>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/free-server", { credentials: "same-origin" });
      if (!res.ok) throw new Error((await res.json()).error ?? "Could not load demo servers");
      const data = await res.json();
      setRows(data.servers ?? []);
      setProvisioning(data.provisioning);
    } catch (e: any) {
      push(e.message, "err");
    } finally {
      setLoading(false);
    }
  }, [push]);

  useEffect(() => {
    load();
  }, [load]);

  const act = async (id: string, action: string) => {
    setBusy(`${id}:${action}`);
    try {
      const res = await fetch(`/api/free-server/${id}`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Action failed");
      if (action === "info") setDetail(data);
      else {
        push(`${action} requested.`, "ok");
        await load();
      }
    } catch (e: any) {
      push(e.message, "err");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="legend text-mute">
          {rows.length} DEMO SERVER{rows.length === 1 ? "" : "S"}
          {provisioning && !provisioning.configured && <span className="text-signal"> · BACKEND NOT CONNECTED</span>}
        </p>
        <div className="flex gap-2">
          <button onClick={load} className="border-line text-mute hover:text-fore border px-3 py-2 text-[12.5px]" aria-label="Refresh">
            <RefreshCw size={13} />
          </button>
          <Link href="/free-server" className="bg-signal text-void legend flex items-center gap-2 px-4 py-2.5">
            <Plus size={13} /> NEW DEMO
          </Link>
        </div>
      </div>

      {loading && (
        <div className="legend text-mute border-line flex items-center gap-3 border border-dashed p-10">
          <RefreshCw size={14} className="animate-spin" /> LOADING…
        </div>
      )}

      {!loading && rows.length === 0 && (
        <div className="border-line border-dashed px-6 py-14 text-center">
          <p className="text-chalk text-[15px] font-medium">No demo servers yet</p>
          <p className="text-mute mt-2 text-[13.5px]">Configure RAM, CPU, storage and runtime, then provision one in under a minute.</p>
          <Link href="/free-server" className="bg-signal text-void legend mt-5 inline-block px-6 py-3 font-semibold">
            TRY A FREE SERVER
          </Link>
        </div>
      )}

      <div className="flex flex-col gap-3">
        {rows.map((s) => {
          const expired = s.expiresAt && new Date(s.expiresAt).getTime() <= Date.now();
          const active = ["running", "pending", "stopped"].includes(s.status) && !expired;
          return (
            <div key={s.id} className="panel p-4 md:p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-chalk text-[15.5px] font-semibold">{s.name}</h3>
                    <span className={`legend border px-2 py-0.5 ${STATUS_TONE[s.status] ?? "border-line text-mute"}`}>
                      {String(s.status).toUpperCase()}
                    </span>
                  </div>
                  <div className="legend text-mute mt-1.5">
                    {s.reference} · {s.software?.toUpperCase()} {s.version ? `· ${s.version}` : ""} · CREATED{" "}
                    {new Date(s.createdAt).toLocaleDateString("en-IN")}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4">
                  <div className="text-right">
                    <div className="legend text-mute text-[8.5px]">EXPIRES IN</div>
                    <div className="num text-[15px]">
                      {expired ? <span className="text-signal">EXPIRED</span> : <Countdown expiresAt={s.expiresAt} />}
                    </div>
                  </div>
                  <div className="border-line grid grid-cols-3 gap-px border bg-line/60">
                    {[
                      ["RAM", mb(s.ramMb)],
                      ["CPU", `${s.cpuPercent}%`],
                      ["DISK", mb(s.diskMb)],
                    ].map(([label, value]) => (
                      <div key={label} className="bg-panel px-3 py-2 text-center">
                        <div className="legend text-mute text-[7.5px]">{label}</div>
                        <div className="num text-fore mt-0.5 text-[12.5px]">{value}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="border-line mt-4 flex flex-wrap items-center gap-2 border-t pt-4">
                <ActionBtn label="Start" icon={Play} disabled={!active || s.status === "running"} busy={busy === `${s.id}:start`} onClick={() => act(s.id, "start")} />
                <ActionBtn label="Stop" icon={Square} disabled={!active || s.status === "stopped"} busy={busy === `${s.id}:stop`} onClick={() => act(s.id, "stop")} />
                <ActionBtn label="Restart" icon={RotateCcw} disabled={!active} busy={busy === `${s.id}:restart`} onClick={() => act(s.id, "restart")} />
                <ActionBtn label="Info" icon={Info} busy={busy === `${s.id}:info`} onClick={() => act(s.id, "info")} />
                <ActionBtn label="Extend" icon={Clock} disabled={!active} busy={busy === `${s.id}:extend`} onClick={() => act(s.id, "extend")} />
                {s.panelUrl && (
                  <a
                    href={s.panelUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="border-line text-mute hover:text-fore flex items-center gap-1.5 border px-3 py-2 text-[12.5px] transition-colors"
                  >
                    Console <ExternalLink size={12} />
                  </a>
                )}
                <span className="legend text-mute ml-auto">
                  {s.price && Number(s.price) > 0 ? `PAID UPGRADE ${symbolize(s.price)}` : "FREE TIER"}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* server information panel */}
      {detail && (
        <div className="panel p-5">
          <div className="flex items-center justify-between border-line border-b pb-3">
            <span className="legend text-signal">SERVER INFORMATION · {detail.server?.reference}</span>
            <button onClick={() => setDetail(null)} className="text-mute hover:text-signal text-[13px]">
              Close
            </button>
          </div>
          <pre className="text-fore mt-3 overflow-x-auto font-mono text-[12px] thin-scroll">
            {JSON.stringify({ stored: { ...detail.server, meta: undefined }, panel: detail.external, syncError: detail.syncError }, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}

function symbolize(v: any) {
  return `₹${Number(v).toLocaleString("en-IN")}`;
}

function ActionBtn({ label, icon: Icon, onClick, disabled, busy }: any) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || busy}
      className="border-line text-fore hover:border-signal/50 hover:text-signal flex items-center gap-1.5 border px-3 py-2 text-[12.5px] transition-all disabled:cursor-not-allowed disabled:opacity-40"
    >
      {busy ? <Loader2 size={12} className="animate-spin" /> : <Icon size={12} />}
      {label}
    </button>
  );
}
