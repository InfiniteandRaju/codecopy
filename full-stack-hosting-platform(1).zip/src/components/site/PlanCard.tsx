"use client";

import Link from "next/link";
import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Check } from "lucide-react";
import { useOrder } from "@/lib/useOrder";
import { TagChip } from "@/components/site/PlanUnit";

type Cycle = { key: string; label: string; months: number; price: string; compareAt: string | null };

export type HomePlan = {
  id: string;
  name: string;
  slug: string;
  shortDescription?: string | null;
  specs?: any;
  features?: any;
  cycles: Cycle[];
  tags: any[];
  categoryName?: string | null;
  featured?: boolean;
  bestSeller?: boolean;
};

/**
 * A true product pricing card: name, individual price, specifications,
 * features, promotional tags and a working Order Now button.
 */
export function PlanCard({ plan, index = 0, symbol = "₹", showSpecs = true, showTags = true }: {
  plan: HomePlan;
  index?: number;
  symbol?: string;
  showSpecs?: boolean;
  showTags?: boolean;
}) {
  const activeCycles = plan.cycles.filter((c) => c) as Cycle[];
  const [selected, setSelected] = useState(
    activeCycles.find((c) => c.key === "monthly")?.key ?? activeCycles[0]?.key ?? "",
  );
  const { order, busy } = useOrder();
  const cycle = activeCycles.find((c) => c.key === selected) ?? activeCycles[0];
  const price = cycle ? Number(cycle.price) / (cycle.months || 1) : 0;
  const total = cycle ? Number(cycle.price) : 0;
  const compare = cycle?.compareAt ? Number(cycle.compareAt) : null;
  const saving = compare && compare > total ? Math.round(((compare - total) / compare) * 100) : 0;
  const specs = (Array.isArray(plan.specs) ? plan.specs : []).slice(0, 3);
  const features = (Array.isArray(plan.features) ? plan.features : []).slice(0, 3);
  const visibleTags = (plan.tags ?? []).filter((t: any) => t.showOnCards).slice(0, 3);

  return (
    <motion.article
      initial={{ opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.5, delay: Math.min(index, 8) * 0.05, ease: [0.16, 0.8, 0.3, 1] }}
      className="panel group relative flex flex-col overflow-hidden"
    >
      <span
        className={`led absolute top-4 right-4 h-2 w-2 rounded-full ${
          plan.bestSeller ? "bg-signal text-signal led-pulse" : plan.featured ? "bg-link text-link" : "bg-led text-led"
        }`}
      />

      <div className="flex flex-1 flex-col p-5">
        <div className="legend text-signal mb-3 pr-6">{plan.categoryName ?? "PLAN"}</div>

        <Link href={`/plans/${plan.slug}`} className="block">
          <h3 className="text-chalk group-hover:text-signal-2 pr-6 text-[19px] leading-tight font-semibold transition-colors">
            {plan.name}
          </h3>
        </Link>

        {showTags && visibleTags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {visibleTags.map((t: any) => (
              <TagChip key={t.id ?? t.slug} tag={t} small />
            ))}
          </div>
        )}

        <p className="text-mute mt-3 line-clamp-2 text-[13.5px] leading-relaxed">{plan.shortDescription}</p>

        {/* price */}
        <div className="border-line/70 mt-4 flex items-end justify-between gap-3 border-t pt-4">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="num text-chalk text-[30px] leading-none font-semibold tracking-tight">
                {symbol}
                {Math.round(price).toLocaleString("en-IN")}
              </span>
              <span className="legend text-mute">/MO</span>
            </div>
            <div className="legend text-mute mt-1.5 flex items-center gap-2">
              {compare && saving > 0 && (
                <span className="text-led">
                  SAVE {saving}% · WAS {symbol}
                  {Math.round(compare / (cycle?.months || 1)).toLocaleString("en-IN")}
                </span>
              )}
              {!compare && cycle && cycle.months > 1 && (
                <span>
                  {symbol}
                  {total.toLocaleString("en-IN")} / {cycle.label.toLowerCase()}
                </span>
              )}
            </div>
          </div>
          {activeCycles.length > 1 && (
            <div className="flex gap-1">
              {activeCycles.map((c) => (
                <button
                  key={c.key}
                  onClick={() => setSelected(c.key)}
                  aria-label={`Select ${c.label} billing`}
                  className={`legend border px-1.5 py-1 transition-all ${
                    c.key === selected ? "border-signal/70 bg-signal/12 text-signal" : "border-line text-mute hover:border-line-2"
                  }`}
                >
                  {c.months > 1 ? `${c.months}M` : "M"}
                </button>
              ))}
            </div>
          )}
        </div>

        {showSpecs && specs.length > 0 && (
          <dl className="mt-4 grid grid-cols-3 gap-px bg-line/60">
            {specs.map((s: any, i: number) => (
              <div key={i} className="bg-panel px-2 py-2">
                <dt className="legend text-mute text-[8px]">{s.label}</dt>
                <dd className="num text-fore mt-0.5 truncate text-[11.5px]">{s.value}</dd>
              </div>
            ))}
          </dl>
        )}

        {features.length > 0 && (
          <ul className="mt-4 flex flex-col gap-1.5">
            {features.map((f: string, i: number) => (
              <li key={i} className="text-mute flex items-start gap-2 text-[13px] leading-snug">
                <Check size={13} className="text-led mt-0.5 shrink-0" />
                <span className="line-clamp-1">{f}</span>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-auto flex flex-col gap-2 pt-5">
          <button
            onClick={() => order({ slug: plan.slug, cycleKey: cycle?.key }, plan.id)}
            disabled={busy === plan.id}
            className="bg-signal text-void hover:bg-signal-2 legend flex w-full items-center justify-center gap-2 py-3 font-semibold transition-colors disabled:opacity-60"
          >
            {busy === plan.id ? "WORKING…" : "ORDER NOW"}
            <ArrowUpRight size={13} />
          </button>
          <Link
            href={`/plans/${plan.slug}`}
            className="border-line text-mute hover:text-chalk hover:border-line-2 border py-2.5 text-center text-[12.5px] transition-all"
          >
            View plan details
          </Link>
        </div>
      </div>
    </motion.article>
  );
}
