import Link from "next/link";
import { Code2, AtSign, Play, MessageCircle, ArrowUpRight, Mail } from "lucide-react";
import { Wordmark } from "@/components/site/Mark";
import { getSettings, getCategoryTree } from "@/lib/data";

export async function Footer() {
  const settings = await getSettings().catch(() => null);
  const cats = await getCategoryTree().catch(() => [] as any[]);
  const social = settings?.social ?? {};
  const icons: Record<string, any> = { twitter: AtSign, github: Code2, youtube: Play, discord: MessageCircle };

  const columns = [
    {
      title: "Hosting",
      links: cats.slice(0, 6).map((c: any) => ({ label: c.name, href: `/hosting/${c.slug}` })),
    },
    {
      title: "Company",
      links: [
        { label: "About the network", href: "/#why" },
        { label: "Server locations", href: "/#locations" },
        { label: "Infrastructure", href: "/#infra" },
        { label: "Customer stories", href: "/#testimonials" },
        { label: "Contact & support", href: "/#support" },
      ],
    },
    {
      title: "Account",
      links: [
        { label: "Sign in", href: "/login" },
        { label: "Create account", href: "/register" },
        { label: "Wallet & billing", href: "/account" },
        { label: "Pricing", href: "/pricing" },
        { label: "Admin console", href: "/admin" },
      ],
    },
    {
      title: "Legal",
      links: [
        { label: "Terms of service", href: "/legal/terms" },
        { label: "Privacy policy", href: "/legal/privacy" },
        { label: "Acceptable use", href: "/legal/aup" },
        { label: "SLA & uptime", href: "/legal/sla" },
      ],
    },
  ];

  return (
    <footer className="border-line bg-panel/60 relative border-t">
      <div className="mx-auto max-w-[1440px] px-5 py-14 md:px-10 md:py-20">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2.6fr]">
          <div>
            <Wordmark />
            <p className="text-mute mt-5 max-w-sm text-[14px] leading-relaxed">
              {settings?.footer?.blurb ??
                "Independent infrastructure provider operating high-frequency compute and DDoS-filtered network capacity."}
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {Object.entries(social)
                .filter(([, v]) => Boolean(v))
                .map(([k, href]) => {
                  const Icon = icons[k] ?? ArrowUpRight;
                  return (
                    <a
                      key={k}
                      href={String(href)}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={k}
                      className="border-line text-mute hover:border-signal/50 hover:text-signal border p-2.5 transition-all"
                    >
                      <Icon size={15} />
                    </a>
                  );
                })}
            </div>
            <a
              href={`mailto:${settings?.contactEmail ?? "sales@obsidiannode.io"}`}
              className="text-mute hover:text-chalk mt-6 flex items-center gap-2 text-[13.5px] transition-colors"
            >
              <Mail size={14} className="text-signal" /> {settings?.contactEmail ?? "sales@obsidiannode.io"}
            </a>
          </div>

          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            {columns.map((col) => (
              <div key={col.title}>
                <h4 className="legend text-signal mb-4">{col.title}</h4>
                <ul className="space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      <Link href={l.href} className="text-mute hover:text-chalk link-underline text-[13.5px] transition-colors">
                        {l.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="border-line mt-14 flex flex-col gap-4 border-t pt-6 md:flex-row md:items-center md:justify-between">
          <p className="text-mute text-[12.5px]">{settings?.footer?.legal ?? "© Obsidian Node. All rights reserved."}</p>
          <p className="legend text-mute flex flex-wrap items-center gap-x-5 gap-y-2">
            <span>AS204312</span>
            <span className="flex items-center gap-2">
              <span className="led led-pulse bg-led text-led h-1.5 w-1.5 rounded-full" /> 99.99% UPTIME
            </span>
            <span>PCI-DSS READY</span>
            <span>IN · SG · DE · US</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
