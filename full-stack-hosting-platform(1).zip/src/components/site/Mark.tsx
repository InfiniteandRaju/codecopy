"use client";

import { useBranding } from "@/components/brand/BrandingProvider";

export function Mark({ size = 28, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="mk" x1="6" y1="4" x2="42" y2="44" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FF9452" />
          <stop offset="1" stopColor="#C24A08" />
        </linearGradient>
      </defs>
      {/* Hex chassis — a node in a fabric */}
      <path
        d="M24 2.6 42.4 13.2v21.6L24 45.4 5.6 34.8V13.2L24 2.6Z"
        stroke="url(#mk)"
        strokeWidth="2.4"
        fill="rgba(255,107,24,0.06)"
      />
      {/* N carved through the chassis */}
      <path
        d="M16.5 33V15.6l15 17.8V15"
        stroke="#Eef2f8"
        strokeWidth="3.1"
        strokeLinecap="square"
        fill="none"
      />
      <circle cx="24" cy="24" r="2.1" fill="#39D7E6" />
    </svg>
  );
}

/**
 * The one logo component used by Nav, Footer, login, customer dashboard and the
 * admin console. It renders the branding configured in Admin → Settings →
 * Branding, falling back to the drawn mark when no image has been uploaded.
 */
export function Wordmark({ compact = false }: { compact?: boolean }) {
  const { siteName, logo, logoLight, logoDark, wordmark, submark, logoWidth, logoHeight } = useBranding();
  const prefersLight =
    typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
  const src = prefersLight ? logoLight || logo : logoDark || logo;

  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={src}
        alt={siteName}
        width={Math.round(compact ? logoWidth * 0.8 : logoWidth)}
        height={Math.round(compact ? logoHeight * 0.8 : logoHeight)}
        className="object-contain"
        style={{ maxHeight: compact ? 26 : logoHeight, height: "auto" }}
      />
    );
  }

  return (
    <span className="flex items-center gap-2.5">
      <Mark size={compact ? 24 : 28} />
      <span className="flex flex-col leading-none">
        <span className="text-chalk font-display text-[15px] font-bold tracking-[0.02em]">{wordmark}</span>
        <span className="legend text-mute mt-0.5 text-[8.5px]">{submark}</span>
      </span>
    </span>
  );
}
