"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, ChevronRight, LogOut, LayoutDashboard, Wallet } from "lucide-react";
import { Wordmark } from "@/components/site/Mark";

const LINKS = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services" },
  { label: "Pricing", href: "/pricing" },
  { label: "Network", href: "/#network" },
  { label: "Support", href: "/#support" },
];

export function Nav() {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setUser(d.user))
      .catch(() => setUser(null));
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    router.push("/");
    router.refresh();
  };

  const isAdmin = user && ["super_admin", "product_manager", "finance_manager", "support"].includes(user.role);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
          scrolled ? "bg-void/88 border-line border-b backdrop-blur-xl" : "border-b border-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-[1440px] items-center gap-6 px-5 md:h-[72px] md:px-10">
          <Link href="/" aria-label="Obsidian Node home">
            <Wordmark />
          </Link>

          <nav className="ml-6 hidden items-center gap-7 lg:flex">
            {LINKS.map((l) => {
              const active = pathname === l.href || (l.href !== "/" && pathname.startsWith(l.href));
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={`link-underline text-[13.5px] transition-colors ${
                    active ? "text-chalk" : "text-mute hover:text-chalk"
                  }`}
                >
                  {l.label}
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            <span className="legend text-mute mr-1 hidden items-center gap-2 xl:flex">
              <span className="led led-pulse bg-led text-led h-1.5 w-1.5 rounded-full" />
              ALL SYSTEMS OPERATIONAL
            </span>
            {user ? (
              <div className="hidden items-center gap-2 md:flex">
                <Link
                  href={isAdmin ? "/admin" : "/account"}
                  className="border-line bg-raised/70 text-fore hover:border-line-2 hover:text-chalk flex items-center gap-2 border px-3.5 py-2 text-[13px] transition-all"
                >
                  {isAdmin ? <LayoutDashboard size={14} /> : <Wallet size={14} />}
                  {isAdmin ? "Dashboard" : "Account"}
                </Link>
                <button
                  onClick={logout}
                  aria-label="Sign out"
                  className="text-mute hover:text-signal border-line hover:border-signal/40 border p-2 transition-all"
                >
                  <LogOut size={14} />
                </button>
              </div>
            ) : (
              <div className="hidden items-center gap-2 md:flex">
                <Link href="/login" className="text-mute hover:text-chalk px-3 py-2 text-[13px] transition-colors">
                  Sign in
                </Link>
                <Link
                  href="/register"
                  className="bg-signal text-void hover:bg-signal-2 legend flex items-center gap-1.5 px-4 py-2.5 font-semibold transition-colors"
                >
                  DEPLOY <ChevronRight size={13} />
                </Link>
              </div>
            )}
            <button
              onClick={() => setOpen((v) => !v)}
              className="border-line text-fore border p-2 md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        <div className="from-line/70 h-px bg-gradient-to-r via-transparent to-transparent" />
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.24 }}
            className="bg-void/97 border-line fixed inset-x-0 top-16 z-40 border-b p-5 backdrop-blur-xl md:hidden"
          >
            <nav className="flex flex-col">
              {LINKS.map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className="border-line/70 text-chalk flex items-center justify-between border-b py-3.5 text-[15px]"
                >
                  {l.label}
                  <ChevronRight size={15} className="text-signal" />
                </Link>
              ))}
            </nav>
            <div className="mt-5 flex gap-3">
              {user ? (
                <>
                  <Link
                    href={user && ["super_admin", "product_manager", "finance_manager", "support"].includes(user.role) ? "/admin" : "/account"}
                    className="bg-signal text-void legend flex-1 py-3 text-center font-semibold"
                  >
                    {["super_admin", "product_manager", "finance_manager", "support"].includes(user.role)
                      ? "DASHBOARD"
                      : "ACCOUNT"}
                  </Link>
                  <button onClick={logout} className="border-line text-fore border px-4 py-3 text-[13px]">
                    Sign out
                  </button>
                </>
              ) : (
                <>
                  <Link href="/register" className="bg-signal text-void legend flex-1 py-3 text-center font-semibold">
                    CREATE ACCOUNT
                  </Link>
                  <Link href="/login" className="border-line text-fore border px-5 py-3 text-[13px]">
                    Sign in
                  </Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
