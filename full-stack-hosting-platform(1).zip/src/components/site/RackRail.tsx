"use client";

import { useEffect, useState } from "react";

export type RailItem = { id: string; label: string };

/** Fixed 88px rack rail: vertical engraved legends + index numbers, scroll-linked. */
export function RackRail({ items }: { items: RailItem[] }) {
  const [active, setActive] = useState(items[0]?.id ?? "");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: [0, 0.2, 0.6] },
    );
    items.forEach((i) => {
      const el = document.getElementById(i.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [items]);

  return (
    <aside className="border-line bg-panel/40 fixed top-0 left-0 z-30 hidden h-full w-[88px] border-r xl:block">
      <div className="flex h-full flex-col items-center justify-center gap-7 py-24">
        {items.map((item, i) => {
          const on = active === item.id;
          return (
            <a
              key={item.id}
              href={`#${item.id}`}
              className="group flex flex-col items-center gap-3 transition-all duration-300"
              aria-label={item.label}
            >
              <span className={`num text-[10px] transition-colors ${on ? "text-signal" : "text-mute/60"}`}>
                {String(i + 1).padStart(2, "0")}
              </span>
              <span
                className={`legend text-[9px] transition-colors ${on ? "text-chalk" : "text-mute/50 group-hover:text-mute"}`}
                style={{ writingMode: "vertical-rl" }}
              >
                {item.label}
              </span>
              <span
                className={`h-px transition-all duration-300 ${on ? "bg-signal w-7" : "bg-line-2 w-3"}`}
              />
            </a>
          );
        })}
      </div>
      <div className="legend text-mute/40 absolute bottom-6 left-1/2 -translate-x-1/2 text-[8px]" style={{ writingMode: "vertical-rl" }}>
        RACK · A01
      </div>
    </aside>
  );
}
