"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Package,
  User,
  Loader2,
  Copy,
  ReceiptText,
} from "lucide-react";
import { useToast } from "@/components/ui/Toast";

const TABS = [
  { key: "wallet", label: "Wallet", icon: Wallet },
  { key: "orders", label: "Orders", icon: Package },
  { key: "profile", label: "Profile", icon: User },
] as const;

const STATUS_COLOR: Record<string, string> = {
  paid: "text-led border-led/40 bg-led/10",
  active: "text-led border-led/40 bg-led/10",
  pending: "text-signal border-signal/40 bg-signal/10",
  awaiting_payment: "text-signal border-signal/40 bg-signal/10",
  processing: "text-link border-link/40 bg-link/10",
  failed: "text-signal-3 border-signal/40 bg-signal/10",
  cancelled: "text-mute border-line bg-raised",
  refunded: "text-link border-link/40 bg-link/10",
};

/* --------------------------------- wallet --------------------------------- */
export function WalletTab({ balance, symbol }: any) {
  const { push } = useToast();
  const [tx, setTx] = useState<any[]>([]);
  const [topups, setTopups] = useState<number[]>([500, 1000, 2500, 5000]);
  const [amount, setAmount] = useState(1000);
  const [method, setMethod] = useState("razorpay");
  const [methods, setMethods] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<any>(null);
  const [utr, setUtr] = useState("");
  const [proof, setProof] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [w, m] = await Promise.all([fetch("/api/wallet").then((r) => r.json()), fetch("/api/payments").then((r) => r.json())]);
    setTx(w.transactions ?? []);
    if (w.topups?.length) setTopups(w.topups);
    setMethods(m.methods ?? []);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openRazorpay = (data: any) => {
    return new Promise<boolean>((resolve) => {
      const finish = async (ok: boolean, payload: any) => {
        if (ok) {
          const res = await fetch("/api/payments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "razorpay_verify", ...payload }),
          });
          const d = await res.json();
          resolve(res.ok);
          if (res.ok) push("Wallet credited.", "ok");
          else push(d.error ?? "Verification failed", "err");
        } else resolve(false);
        load();
      };
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        const rzp = new (window as any).Razorpay({
          key: data.keyId,
          amount: data.razorpayOrder.amount,
          currency: data.razorpayOrder.currency,
          name: "Obsidian Node",
          description: `Wallet top-up ${data.order.reference}`,
          order_id: data.razorpayOrder.id,
          prefill: { email: "" },
          theme: { color: "#FF6B18" },
          handler: (res: any) => finish(true, res),
          modal: { ondismiss: () => finish(false, null) },
        });
        rzp.open();
      };
      script.onerror = () => {
        push("Unable to load the Razorpay checkout.", "err");
        resolve(false);
      };
      document.body.appendChild(script);
    });
  };

  const startTopup = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/wallet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "topup", amount, method }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Top-up failed");
      if (method === "razorpay") {
        await openRazorpay(data);
      } else {
        setPending(data);
        push("Payment instructions generated. Complete the transfer, then submit the reference.", "info");
      }
    } catch (e: any) {
      push(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  const submitQr = async () => {
    if (!pending?.order) return;
    setBusy(true);
    try {
      const res = await fetch("/api/payments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "qr", orderId: pending.order.id, utr, proofUrl: proof, note: "Wallet top-up" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Submission failed");
      push("Reference submitted — pending administrator verification.", "ok");
      setPending(null);
      setUtr("");
      setProof(null);
      load();
    } catch (e: any) {
      push(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  const onFile = (file?: File) => {
    if (!file) return;
    if (file.size > 1_200_000) return push("Screenshot must be under 1.2 MB.", "err");
    const reader = new FileReader();
    reader.onload = () => setProof(String(reader.result));
    reader.readAsDataURL(file);
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="panel p-6 md:p-7">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="legend text-mute">AVAILABLE BALANCE</div>
            <div className="num text-chalk mt-2 text-[clamp(2.2rem,5vw,3rem)] leading-none font-semibold">
              {symbol}
              {Number(balance).toLocaleString("en-IN", { minimumFractionDigits: 2 })}
            </div>
            <div className="legend text-led mt-2">SETTLED · SPENDABLE ON ANY PLAN</div>
          </div>
          <div className="flex items-center gap-2">
            <ArrowDownRight size={15} className="text-led" />
            <span className="legend text-mute">{tx.length} LEDGER ENTRIES</span>
          </div>
        </div>
      </div>

      <div className="panel p-6">
        <div className="legend text-signal mb-4">ADD FUNDS</div>
        <div className="flex flex-wrap gap-2">
          {topups.map((t) => (
            <button
              key={t}
              onClick={() => setAmount(t)}
              className={`num border px-4 py-2.5 text-[13.5px] transition-all ${
                amount === t ? "border-signal bg-signal/10 text-chalk" : "border-line text-mute hover:border-line-2"
              }`}
            >
              {symbol}
              {t.toLocaleString("en-IN")}
            </button>
          ))}
          <input
            type="number"
            min={100}
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="border-line bg-raised text-fore w-32 border px-3 py-2.5 text-[13.5px] outline-none"
            aria-label="Custom amount"
          />
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="legend text-mute mr-1">METHOD</span>
          {methods.map((m) => (
            <button
              key={m.key}
              onClick={() => setMethod(m.key)}
              className={`legend border px-3 py-2 transition-all ${
                method === m.key ? "border-signal bg-signal/10 text-signal" : "border-line text-mute hover:border-line-2"
              }`}
            >
              {m.name}
            </button>
          ))}
        </div>

        <button
          onClick={startTopup}
          disabled={busy || amount < 100}
          className="bg-signal text-void hover:bg-signal-2 mt-5 flex items-center gap-2 px-6 py-3 text-[13.5px] font-semibold transition-colors disabled:opacity-60"
        >
          {busy ? <Loader2 size={14} className="animate-spin" /> : <ArrowUpRight size={14} />}
          Top up {symbol}
          {amount.toLocaleString("en-IN")}
        </button>

        {pending && (
          <div className="border-line bg-raised/60 mt-5 border p-5">
            <div className="legend text-signal mb-3">TRANSFER INSTRUCTIONS</div>
            <p className="text-fore text-[13.5px]">{pending.instructions ?? "Pay the amount and submit your reference below."}</p>
            {pending.upiId && (
              <p className="num text-chalk mt-2 text-[14px]">
                UPI: {pending.upiId} <Copy size={11} className="text-mute inline" />
              </p>
            )}
            {pending.qrImage && (
              <img src={pending.qrImage} alt="Payment QR code" className="mt-4 h-40 w-40 border border-line bg-white p-1" />
            )}
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <input
                value={utr}
                onChange={(e) => setUtr(e.target.value.toUpperCase())}
                placeholder="UTR / transaction reference"
                className="border-line bg-panel text-fore border px-3 py-2.5 text-[13.5px] outline-none"
              />
              <input
                type="file"
                accept="image/*"
                onChange={(e) => onFile(e.target.files?.[0])}
                className="text-mute border-line border px-3 py-2 text-[12px] file:mr-3 file:border-0 file:bg-raised file:px-3 file:py-1.5 file:text-fore"
              />
            </div>
            <div className="mt-3 flex items-center gap-3">
              <button
                onClick={submitQr}
                disabled={busy || utr.length < 6}
                className="bg-signal text-void px-5 py-2.5 text-[13px] font-semibold disabled:opacity-60"
              >
                {busy ? "SUBMITTING…" : "Submit for verification"}
              </button>
              <button onClick={() => setPending(null)} className="text-mute hover:text-fore text-[13px]">
                Cancel
              </button>
            </div>
            <p className="legend text-mute mt-3">STATUS: PENDING VERIFICATION — MANUAL REVIEW BY AN ADMINISTRATOR</p>
          </div>
        )}
      </div>

      <div className="panel overflow-hidden">
        <div className="border-line flex items-center justify-between border-b px-5 py-3.5">
          <span className="legend text-signal flex items-center gap-2">
            <ReceiptText size={13} /> TRANSACTION LEDGER
          </span>
          <span className="legend text-mute">IMMUTABLE</span>
        </div>
        <div className="overflow-x-auto thin-scroll">
          <table className="w-full min-w-[600px]">
            <thead>
              <tr className="border-line border-b">
                {["DATE", "TYPE", "NOTE", "AMOUNT", "BALANCE"].map((h) => (
                  <th key={h} className="legend text-mute px-5 py-2.5 text-left font-medium">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tx.map((t) => {
                const credit = ["topup", "refund", "adjustment"].includes(t.type);
                return (
                  <tr key={t.id} className="border-line border-b last:border-0">
                    <td className="num text-mute px-5 py-3 text-[12px]">
                      {new Date(t.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })} ·{" "}
                      {new Date(t.createdAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                    </td>
                    <td className="px-5 py-3">
                      <span className="legend border-line text-fore border px-2 py-0.5">{t.type}</span>
                    </td>
                    <td className="text-mute max-w-[280px] truncate px-5 py-3 text-[13px]">{t.note ?? "—"}</td>
                    <td className={`num px-5 py-3 text-[13.5px] ${credit ? "text-led" : "text-signal-2"}`}>
                      {credit ? "+" : "−"}
                      {symbol}
                      {Number(t.amount).toLocaleString("en-IN")}
                    </td>
                    <td className="num text-fore px-5 py-3 text-[13.5px]">
                      {symbol}
                      {Number(t.balanceAfter).toLocaleString("en-IN")}
                    </td>
                  </tr>
                );
              })}
              {tx.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-mute px-5 py-10 text-center text-[13.5px]">
                    No wallet activity yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- orders --------------------------------- */
export function OrdersTab({ orders, symbol }: any) {
  const [list, setList] = useState(orders ?? []);
  const { push } = useToast();

  const reorder = async (o: any) => {
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug: o.planSlug, cycleKey: o.cycleKey, location: o.location ?? "" }),
    });
    const data = await res.json();
    if (!res.ok) return push(data.error ?? "Unable to reorder", "err");
    if (data.billing?.mode === "redirect" && data.billing.url) window.location.href = data.billing.url;
    else {
      sessionStorage.setItem("obs_checkout", JSON.stringify(data));
      window.location.href = "/checkout";
    }
  };

  return (
    <div className="panel overflow-hidden">
      <div className="border-line flex items-center justify-between border-b px-5 py-3.5">
        <span className="legend text-signal">ORDER HISTORY</span>
        <span className="legend text-mute">{list.length} RECORDS</span>
      </div>
      <div className="overflow-x-auto thin-scroll">
        <table className="w-full min-w-[760px]">
          <thead>
            <tr className="border-line border-b">
              {["REFERENCE", "PLAN", "PERIOD", "AMOUNT", "METHOD", "STATUS", ""].map((h) => (
                <th key={h} className="legend text-mute px-5 py-2.5 text-left font-medium">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {list.map((o: any) => (
              <tr key={o.id} className="border-line hover:bg-raised/40 border-b transition-colors">
                <td className="num text-fore px-5 py-3.5 text-[12.5px]">{o.reference}</td>
                <td className="text-chalk px-5 py-3.5 text-[13.5px]">{o.planName}</td>
                <td className="text-mute px-5 py-3.5 text-[13px]">{o.cycleLabel ?? o.cycleKey}</td>
                <td className="num text-fore px-5 py-3.5 text-[13.5px]">
                  {symbol}
                  {Number(o.total).toLocaleString("en-IN")}
                </td>
                <td className="legend text-mute px-5 py-3.5">{o.paymentMethod ?? "—"}</td>
                <td className="px-5 py-3.5">
                  <span className={`legend border px-2 py-0.5 ${STATUS_COLOR[o.status] ?? "border-line text-mute"}`}>
                    {String(o.status).replace("_", " ")}
                  </span>
                </td>
                <td className="px-5 py-3.5 text-right">
                  {(o.status === "pending" || o.status === "failed" || o.status === "awaiting_payment") && (
                    <button onClick={() => reorder(o)} className="legend text-signal hover:text-signal-2">
                      RETRY
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr>
                <td colSpan={7} className="text-mute px-5 py-12 text-center text-[13.5px]">
                  No orders yet — <a className="text-signal" href="/pricing">browse the catalogue</a>.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* -------------------------------- profile --------------------------------- */
export function ProfileTab({ user }: any) {
  const { push } = useToast();
  const [name, setName] = useState(user.name);
  const [busy, setBusy] = useState(false);
  return (
    <div className="panel max-w-xl p-6">
      <div className="legend text-signal mb-4">PROFILE</div>
      <div className="flex flex-col gap-4">
        <label className="block">
          <span className="legend text-mute mb-2 block">NAME</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border-line bg-raised text-fore w-full border px-3 py-2.5 text-[14px] outline-none"
          />
        </label>
        <label className="block">
          <span className="legend text-mute mb-2 block">EMAIL</span>
          <input
            value={user.email}
            disabled
            className="border-line bg-panel text-mute w-full border px-3 py-2.5 text-[14px] opacity-70"
          />
        </label>
        <label className="block">
          <span className="legend text-mute mb-2 block">ACCOUNT TYPE</span>
          <input value={user.role} disabled className="border-line bg-panel text-mute w-full border px-3 py-2.5 text-[14px]" />
        </label>
        <button
          onClick={async () => {
            setBusy(true);
            const res = await fetch("/api/account/profile", {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ name }),
            });
            const d = await res.json();
            setBusy(false);
            push(res.ok ? "Profile updated." : d.error ?? "Update failed", res.ok ? "ok" : "err");
          }}
          disabled={busy}
          className="bg-signal text-void px-6 py-3 text-[13.5px] font-semibold disabled:opacity-60"
        >
          {busy ? "SAVING…" : "Save changes"}
        </button>
      </div>
    </div>
  );
}
