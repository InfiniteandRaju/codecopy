"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { Loader2, ArrowRight, ShieldCheck, Zap, Headphones } from "lucide-react";
import { Wordmark } from "@/components/site/Mark";
import { useToast } from "@/components/ui/Toast";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const params = useSearchParams();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { push } = useToast();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? `Sign-in failed (${res.status}). Please try again.`);
      // Only allow same-site redirects after login.
      const requested = params.get("next");
      const next = requested && requested.startsWith("/") && !requested.startsWith("//") ? requested : null;
      push(mode === "login" ? "Signed in." : "Account created — welcome aboard.", "ok");
      router.push(next ?? data.redirectTo ?? "/");
      router.refresh();
    } catch (err: any) {
      setError(
        err?.message === "Failed to fetch"
          ? "Cannot reach the sign-in service. Check your connection and try again."
          : err?.message ?? "Sign-in failed. Please try again.",
      );
    } finally {
      setBusy(false);
    }
  };

  const field =
    "border-line bg-panel focus-within:border-signal/70 w-full border px-4 py-3 text-[14px] text-fore outline-none transition-colors placeholder:text-mute/55";

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_460px]">
      {/* marketing panel */}
      <div className="relative hidden overflow-hidden lg:block">
        <img src="/images/hero-aisle.jpg" alt="" className="absolute inset-0 h-full w-full object-cover opacity-45" />
        <div className="from-void via-void/80 absolute inset-0 bg-gradient-to-t to-transparent" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Link href="/" aria-label="Home">
            <Wordmark />
          </Link>
          <div>
            <div className="legend text-signal mb-5 flex items-center gap-3">
              <span className="led led-pulse bg-signal text-signal h-1.5 w-1.5 rounded-full" />
              CUSTOMER CONSOLE
            </div>
            <h2 className="max-w-lg text-[clamp(2rem,3.4vw,3rem)] font-semibold">
              One account for servers, wallet and invoices.
            </h2>
            <div className="mt-8 flex flex-col gap-3">
              {[
                [Zap, "Deploy in under 60 seconds after payment"],
                [ShieldCheck, "Wallet ledger with an auditable transaction history"],
                [Headphones, "Engineers on support 24/7/365"],
              ].map(([Icon, text]: any, i) => (
                <div key={i} className="border-line flex items-center gap-3 border px-4 py-3">
                  <Icon size={15} className="text-signal shrink-0" />
                  <span className="text-mute text-[13.5px]">{text}</span>
                </div>
              ))}
            </div>
          </div>
          <p className="legend text-mute">AS204312 · 12 REGIONS · 99.99% UPTIME</p>
        </div>
      </div>

      {/* form */}
      <div className="flex items-center justify-center px-5 py-16 md:px-12">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 0.8, 0.3, 1] }}
          className="w-full max-w-[420px]"
        >
          <div className="lg:hidden">
            <Link href="/" className="mb-10 inline-block">
              <Wordmark />
            </Link>
          </div>

          <div className="legend text-signal mb-4">{mode === "login" ? "01 / SIGN IN" : "01 / CREATE ACCOUNT"}</div>
          <h1 className="text-[2rem] font-semibold">
            {mode === "login" ? "Access the console" : "Open an account"}
          </h1>
          <p className="text-mute mt-3 text-[14.5px]">
            {mode === "login"
              ? "Manage your servers, wallet and billing in one place."
              : "Deploy plans, hold a wallet balance and track every payment."}
          </p>

          <form onSubmit={submit} className="mt-8 flex flex-col gap-4">
            {mode === "register" && (
              <label className="block">
                <span className="legend text-mute mb-2 block">FULL NAME</span>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className={field}
                  placeholder="Rohan Das"
                  autoComplete="name"
                />
              </label>
            )}
            <label className="block">
              <span className="legend text-mute mb-2 block">EMAIL ADDRESS</span>
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={field}
                placeholder="you@company.com"
                autoComplete="email"
              />
            </label>
            <label className="block">
              <span className="legend text-mute mb-2 block">PASSWORD</span>
              <input
                required
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className={field}
                placeholder={mode === "register" ? "8+ characters, letter and number" : "••••••••"}
                autoComplete={mode === "login" ? "current-password" : "new-password"}
              />
            </label>

            {error && (
              <p className="border-signal/40 bg-signal/10 text-signal-2 border px-3 py-2.5 text-[13px]">{error}</p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="bg-signal text-void hover:bg-signal-2 mt-2 flex items-center justify-center gap-2 py-3.5 text-[14px] font-semibold transition-colors disabled:opacity-60"
            >
              {busy ? <Loader2 size={15} className="animate-spin" /> : null}
              {mode === "login" ? "Sign in" : "Create account"}
              {!busy && <ArrowRight size={15} />}
            </button>
          </form>

          <p className="text-mute mt-6 text-[13.5px]">
            {mode === "login" ? (
              <>
                No account yet?{" "}
                <Link href="/register" className="text-signal link-underline">
                  Create one
                </Link>
                .
              </>
            ) : (
              <>
                Already registered?{" "}
                <Link href="/login" className="text-signal link-underline">
                  Sign in
                </Link>
                .
              </>
            )}
          </p>

          <p className="legend text-mute/70 border-line mt-8 border-t pt-5">
            ONE LOGIN FOR CUSTOMERS AND STAFF · ROLE IS RESOLVED SERVER-SIDE AFTER AUTHENTICATION
          </p>
        </motion.div>
      </div>
    </div>
  );
}
