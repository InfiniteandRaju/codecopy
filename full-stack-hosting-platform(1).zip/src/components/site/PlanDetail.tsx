"use client";

import { useMemo, useState } from "react";
import { Check, MapPin, Tag, ExternalLink, Loader2, Info } from "lucide-react";
import { useOrder } from "@/lib/useOrder";
import { TagChip } from "@/components/site/PlanUnit";

type Cycle = { key: string; label: string; months: number; price: string; compareAt: string | null };
type Plan = any;

export function PlanDetail({
  plan,
  billing,
  symbol,
  taxLabel,
  taxRate,
}: {
  plan: Plan;
  billing: { mode: string; url: string | null; openIn: string; buttonText: string };
  symbol: string;
  taxLabel: string;
  taxRate: number;
}) {
  const cycles: Cycle[] = plan.cycles ?? [];
  const [cycleKey, setCycleKey] = useState(cycles.find((c) => c.key === "monthly")?.key ?? cycles[0]?.key ?? "");
  const [location, setLocation] = useState(plan.locations?.[0] ?? "");
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState<string | null>(null);
  const { order, busy } = useOrder();

  const cycle = cycles.find((c) => c.key === cycleKey) ?? cycles[0];
  const price = cycle ? Number(cycle.price) : 0;
  const compare = cycle?.compareAt ? Number(cycle.compareAt) : null;
  const setupFee = Number(plan.setupFee ?? 0);
  const taxRateLocal = Number(plan.taxRate ?? taxRate ?? 0);
  const taxable = price + setupFee;
  const tax = (taxable * taxRateLocal) / 100;
  const monthly = cycle && cycle.months > 1 ? price / cycle.months : price;
  const savingPct = compare && compare > price ? Math.round(((compare - price) / compare) * 100) : 0;

  const cheapest = useMemo(() => {
    if (!cycles.length) return null;
    return cycles.reduce((best, c) => Number(c.price) / c.months < Number(best.price) / best.months ? c : best, cycles[0]);
  }, [cycles]);

  const canOrder = billing.mode !== "manual" || true;

  return (
    <div className="grid gap-10 lg:grid-cols-[1.35fr_400px]">
      {/* ------------------------------- left ------------------------------- */}
      <div className="min-w-0">
        {plan.tags?.length > 0 && (
          <div className="mb-6 flex flex-wrap gap-2">
            {plan.tags.map((t: any) => (
              <TagChip key={t.id} tag={t} />
            ))}
          </div>
        )}

        {plan.description && (
          <div className="text-fore max-w-3xl space-y-4 text-[15.5px] leading-relaxed whitespace-pre-line">
            {plan.description}
          </div>
        )}

        {plan.specs?.length > 0 && (
          <section className="mt-12">
            <h2 className="legend text-signal mb-4 flex items-center gap-3">
              <span>SPECIFICATIONS</span>
              <span className="bg-line-2 h-px flex-1" />
            </h2>
            <div className="grid gap-px bg-line/70 sm:grid-cols-2">
              {plan.specs.map((s: any, i: number) => (
                <div key={i} className="bg-panel flex items-baseline justify-between gap-4 px-4 py-3.5">
                  <span className="legend text-mute">{s.label}</span>
                  <span className="num text-chalk text-right text-[13.5px]">{s.value}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {plan.features?.length > 0 && (
          <section className="mt-12">
            <h2 className="legend text-signal mb-4 flex items-center gap-3">
              <span>INCLUDED</span>
              <span className="bg-line-2 h-px flex-1" />
            </h2>
            <ul className="grid gap-2.5 sm:grid-cols-2">
              {plan.features.map((f: string, i: number) => (
                <li key={i} className="text-fore flex items-start gap-2.5 text-[14.5px]">
                  <Check size={15} className="text-led mt-1 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
          </section>
        )}

        {plan.locations?.length > 0 && (
          <section className="mt-12">
            <h2 className="legend text-signal mb-4 flex items-center gap-3">
              <span>AVAILABLE LOCATIONS</span>
              <span className="bg-line-2 h-px flex-1" />
            </h2>
            <div className="flex flex-wrap gap-2">
              {plan.locations.map((l: string) => (
                <span key={l} className="border-line text-fore flex items-center gap-2 border px-3 py-2 text-[13px]">
                  <MapPin size={12} className="text-signal" />
                  {l}
                </span>
              ))}
            </div>
          </section>
        )}

        {plan.faqs?.length > 0 && (
          <section className="mt-12">
            <h2 className="legend text-signal mb-4 flex items-center gap-3">
              <span>PLAN FAQ</span>
              <span className="bg-line-2 h-px flex-1" />
            </h2>
            <div className="border-line border-t">
              {plan.faqs.map((f: any, i: number) => (
                <details key={i} className="border-line group border-b py-4">
                  <summary className="text-fore hover:text-chalk cursor-pointer list-none text-[15px] font-medium">
                    {f.q}
                  </summary>
                  <p className="text-mute mt-2.5 max-w-2xl text-[14px] leading-relaxed">{f.a}</p>
                </details>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* ------------------------------ right ------------------------------- */}
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <div className="panel relative overflow-hidden">
          <div className="border-line flex items-center justify-between border-b px-5 py-3">
            <span className="legend text-signal flex items-center gap-2">
              <span className="led led-pulse bg-led text-led h-1.5 w-1.5 rounded-full" /> ORDER CONFIGURATION
            </span>
            <span className="legend text-mute">{plan.currency ?? "INR"}</span>
          </div>

          <div className="p-5">
            <div className="legend text-mute mb-3">CHOOSE BILLING PERIOD</div>
            <div className="flex flex-col gap-2">
              {cycles.map((c) => {
                const on = c.key === cycleKey;
                const cMonthly = Number(c.price) / c.months;
                const cSave =
                  c.compareAt && Number(c.compareAt) > Number(c.price)
                    ? Math.round(((Number(c.compareAt) - Number(c.price)) / Number(c.compareAt)) * 100)
                    : 0;
                return (
                  <button
                    key={c.key}
                    onClick={() => setCycleKey(c.key)}
                    className={`flex items-center justify-between border px-4 py-3 transition-all ${
                      on ? "border-signal/70 bg-signal/10" : "border-line hover:border-line-2 hover:bg-raised/50"
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <span
                        className={`flex h-3.5 w-3.5 items-center justify-center rounded-full border ${
                          on ? "border-signal" : "border-line-2"
                        }`}
                      >
                        {on && <span className="bg-signal h-1.5 w-1.5 rounded-full" />}
                      </span>
                      <span className={`text-[14px] ${on ? "text-chalk" : "text-fore"}`}>{c.label}</span>
                      {cSave > 0 && (
                        <span className="legend bg-led/12 text-led border-led/30 border px-1.5 py-0.5">−{cSave}%</span>
                      )}
                    </span>
                    <span className="num text-right">
                      <span className={`text-[14.5px] ${on ? "text-chalk" : "text-fore"}`}>
                        {symbol}
                        {Math.round(cMonthly).toLocaleString("en-IN")}
                      </span>
                      <span className="legend text-mute ml-1">/mo</span>
                    </span>
                  </button>
                );
              })}
            </div>

            {cheapest && cycles.length > 1 && (
              <p className="legend text-led mt-3 flex items-center gap-1.5">
                <Info size={11} /> BEST VALUE: {cheapest.label.toUpperCase()} · {symbol}
                {Math.round(Number(cheapest.price) / cheapest.months).toLocaleString("en-IN")}/mo
              </p>
            )}

            {plan.locations?.length > 1 && (
              <div className="mt-5">
                <div className="legend text-mute mb-2">SERVER LOCATION</div>
                <select
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="border-line bg-raised text-fore w-full border px-3 py-2.5 text-[13.5px] outline-none"
                >
                  {plan.locations.map((l: string) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="mt-5">
              <div className="legend text-mute mb-2">COUPON CODE</div>
              <div className="flex gap-2">
                <input
                  value={coupon}
                  onChange={(e) => {
                    setCoupon(e.target.value.toUpperCase());
                    setApplied(null);
                  }}
                  placeholder="LAUNCH20"
                  className="border-line bg-raised placeholder:text-mute/60 text-fore w-full border px-3 py-2.5 text-[13.5px] tracking-wider uppercase outline-none"
                />
                <button
                  onClick={() => setApplied(coupon || null)}
                  disabled={!coupon}
                  className="border-line text-fore hover:border-signal/50 hover:text-signal border px-3 text-[12.5px] transition-all disabled:opacity-40"
                >
                  Apply
                </button>
              </div>
              {applied && <p className="legend text-led mt-2">{applied} WILL BE VALIDATED SERVER-SIDE AT CHECKOUT</p>}
            </div>

            <dl className="border-line mt-6 space-y-2.5 border-t pt-5 text-[13.5px]">
              <div className="flex justify-between">
                <dt className="text-mute">
                  {cycle?.label ?? "Plan"} plan
                </dt>
                <dd className="num text-fore">
                  {symbol}
                  {price.toLocaleString("en-IN")}
                </dd>
              </div>
              {compare && savingPct > 0 && (
                <div className="flex justify-between">
                  <dt className="text-mute">Discount vs monthly</dt>
                  <dd className="num text-led">
                    −
                    {symbol}
                    {(compare - price).toLocaleString("en-IN")}
                  </dd>
                </div>
              )}
              {setupFee > 0 && (
                <div className="flex justify-between">
                  <dt className="text-mute">Setup fee</dt>
                  <dd className="num text-fore">
                    {symbol}
                    {setupFee.toLocaleString("en-IN")}
                  </dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-mute">
                  {taxLabel} ({taxRateLocal}%)
                </dt>
                <dd className="num text-fore">
                  {symbol}
                  {Math.round(tax).toLocaleString("en-IN")}
                </dd>
              </div>
              <div className="border-line flex items-baseline justify-between border-t pt-3">
                <dt className="text-chalk font-medium">Due today</dt>
                <dd className="num text-chalk text-[22px] font-semibold">
                  {symbol}
                  {Math.round(price + setupFee + tax).toLocaleString("en-IN")}
                </dd>
              </div>
            </dl>

            <button
              onClick={() =>
                order(
                  { slug: plan.slug, cycleKey: cycle?.key, location, coupon: applied ?? coupon ?? "" },
                  "detail",
                )
              }
              disabled={busy === "detail" || !canOrder}
              className="bg-signal text-void hover:bg-signal-2 legend mt-5 flex w-full items-center justify-center gap-2 py-4 font-semibold transition-colors disabled:opacity-60"
            >
              {busy === "detail" ? (
                <>
                  <Loader2 size={14} className="animate-spin" /> WORKING…
                </>
              ) : (
                <>
                  {billing.buttonText || "Order Now"}
                  {billing.mode === "redirect" ? <ExternalLink size={13} /> : null}
                </>
              )}
            </button>

            <p className="legend text-mute mt-3 leading-relaxed">
              {billing.mode === "redirect"
                ? "REDIRECTS TO THE BILLING DESTINATION CONFIGURED FOR THIS PLAN"
                : billing.mode === "manual"
                  ? "MANUAL ORDER FLOW — AN ENGINEER WILL CONFIRM AVAILABILITY"
                  : "PROCESSED INSIDE THE OBSIDIAN NODE CHECKOUT"}
            </p>

            <div className="border-line mt-4 grid grid-cols-3 gap-px border-t bg-line/60 pt-4">
              {[
                ["7-DAY", "GUARANTEE"],
                ["FREE", "MIGRATION"],
                ["24/7", "SUPPORT"],
              ].map(([a, b]) => (
                <div key={a} className="text-center">
                  <div className="num text-chalk text-[13px] font-semibold">{a}</div>
                  <div className="legend text-mute text-[8px]">{b}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
}
