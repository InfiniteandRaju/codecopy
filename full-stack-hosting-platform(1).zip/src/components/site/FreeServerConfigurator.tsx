"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import {
  Server,
  Cpu,
  HardDrive,
  Timer,
  Boxes,
  CheckCircle2,
  Loader2,
  TriangleAlert,
  ArrowRight,
  RefreshCw,
} from "lucide-react";
import { useToast } from "@/components/ui/Toast";
import { TagChip } from "@/components/site/PlanUnit";

type Config = any;

const mb = (v: number) => (v >= 1024 ? `${(v / 1024).toFixed(v % 1024 === 0 ? 0 : 1)} GB` : `${v} MB`);
const money = (n: number, currency: string) => (currency === "INR" ? `₹${n.toLocaleString("en-IN")}` : `${currency} ${n}`);

function durationLabel(minutes: number) {
  if (minutes < 60) return `${minutes} minutes`;
  if (minutes % 1440 === 0) return `${minutes / 1440} day${minutes > 1440 ? "s" : ""}`;
  if (minutes % 60 === 0) return `${minutes / 60} hour${minutes > 60 ? "s" : ""}`;
  return `${minutes} minutes`;
}

export function Countdown({ expiresAt, onDone }: { expiresAt: string; onDone?: () => void }) {
  const [left, setLeft] = useState(() => new Date(expiresAt).getTime() - Date.now());
  useEffect(() => {
    const id = setInterval(() => {
      const next = new Date(expiresAt).getTime() - Date.now();
      setLeft(next);
      if (next <= 0) onDone?.();
    }, 1000);
    return () => clearInterval(id);
  }, [expiresAt, onDone]);
  if (left <= 0) return <span className="legend text-signal">EXPIRED</span>;
  const h = Math.floor(left / 3600000);
  const m = Math.floor((left % 3600000) / 60000);
  const s = Math.floor((left % 60000) / 1000);
  return (
    <span className="num text-chalk">
      {String(h).padStart(2, "0")}:{String(m).padStart(2, "0")}:{String(s).padStart(2, "0")}
    </span>
  );
}

export function FreeServerConfigurator({ initialConfig }: { initialConfig?: Config }) {
  const api = useToast();
  const router = useRouter();
  const params = useSearchParams();

  const [config, setConfig] = useState<Config>(initialConfig?.config ?? null);
  const [provisioning, setProvisioning] = useState<any>(initialConfig?.provisioning ?? null);
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const [sel, setSel] = useState<any>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/free-server/config", { cache: "no-store" });
      const data = await res.json();
      setConfig(data.config);
      setProvisioning(data.provisioning);
    } catch {
      api.push("Could not load the configurator settings.", "err");
    }
  }, [api]);

  useEffect(() => {
    fetch("/api/auth/me", { credentials: "same-origin" })
      .then((r) => r.json())
      .then((d) => setAuthed(Boolean(d?.user)))
      .catch(() => setAuthed(false));
    if (!initialConfig) load();
  }, [initialConfig, load]);

  // Defaults come from the administrator's configuration.
  useEffect(() => {
    if (!config || sel) return;
    setSel({
      name: "My demo server",
      ramMb: config.defaults.ramMb,
      cpuPercent: config.defaults.cpuPercent,
      diskMb: config.defaults.diskMb,
      durationMinutes: config.defaults.durationMinutes,
      software: config.defaults.software,
    });
  }, [config, sel]);

  // Restore a configuration preserved through login (or a previous session).
  useEffect(() => {
    if (!config || sel) return;
    const encoded = params.get("cfg");
    let restored: any = null;
    if (encoded) {
      try {
        restored = JSON.parse(decodeURIComponent(escape(atob(decoded(encoded)))));
      } catch {
        restored = null;
      }
    }
    if (!restored) {
      try {
        restored = JSON.parse(localStorage.getItem("free_server_cfg") ?? "null");
      } catch {
        restored = null;
      }
    }
    if (restored) setSel(restored);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config, params]);

  const saveLocal = (next: any) => {
    setSel(next);
    try {
      localStorage.setItem("free_server_cfg", JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const software = useMemo(
    () => (config?.software ?? []).filter((s: any) => s.enabled),
    [config],
  );

  // Live price — computed client-side for display, always recomputed server-side on submit.
  const price = useMemo(() => {
    if (!config || !sel) return null;
    const lines = [];
    const gb = (v: number) => Math.ceil(Math.max(0, v) / 1024);
    const ramOver = Math.max(0, sel.ramMb - config.ram.freeMb);
    lines.push({
      key: "ram",
      label: "RAM",
      detail: ramOver > 0 ? `${gb(config.ram.freeMb)} GB included · ${gb(ramOver)} GB extra` : `${gb(sel.ramMb)} GB — included`,
      free: ramOver === 0,
      amount: ramOver > 0 && config.ram.allowPaid ? gb(ramOver) * config.ram.pricePerGb : 0,
    });
    const cpuOver = Math.max(0, sel.cpuPercent - config.cpu.freePercent);
    lines.push({
      key: "cpu",
      label: "CPU",
      detail: cpuOver > 0 ? `${config.cpu.freePercent}% included · +${cpuOver}% allocated` : `${sel.cpuPercent}% — included`,
      free: cpuOver === 0,
      amount: cpuOver > 0 && config.cpu.allowPaid ? Math.ceil(cpuOver / 100) * config.cpu.pricePer100 : 0,
    });
    const diskOver = Math.max(0, sel.diskMb - config.disk.freeMb);
    lines.push({
      key: "disk",
      label: "Storage",
      detail: diskOver > 0 ? `${gb(config.disk.freeMb)} GB included · ${gb(diskOver)} GB extra` : `${gb(sel.diskMb)} GB — included`,
      free: diskOver === 0,
      amount: diskOver > 0 && config.disk.allowPaid ? gb(diskOver) * config.disk.pricePerGb : 0,
    });
    lines.push({ key: "duration", label: "Duration", detail: `${durationLabel(sel.durationMinutes)} runtime`, free: true, amount: 0 });
    const total = lines.reduce((n, l) => n + l.amount, 0);
    return { lines, total, free: total === 0 };
  }, [config, sel]);

  const create = async () => {
    if (!config || !sel || busy) return;
    setError(null);
    if (!authed) {
      const encoded = btoa(unescape(encodeURIComponent(JSON.stringify(sel))));
      api.push("Create an account or sign in to start your free server.", "info");
      router.push(`/login?next=${encodeURIComponent(`/free-server?cfg=${encoded}`)}`);
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/free-server", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sel),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? `Provisioning failed (${res.status})`);
      setCreated(data.server);
      api.push("Demo server provisioned.", "ok");
    } catch (e: any) {
      setError(e.message);
      api.push(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  if (!config) {
    return (
      <div className="legend text-mute border-line flex items-center justify-center gap-3 border border-dashed p-16">
        <RefreshCw size={14} className="animate-spin" /> LOADING CONFIGURATOR…
      </div>
    );
  }

  if (created) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="panel p-7 md:p-9">
        <CheckCircle2 size={34} className="text-led" />
        <h2 className="mt-4 text-[clamp(1.5rem,3vw,2.2rem)] font-semibold">Your demo server is live</h2>
        <p className="text-mute mt-2 text-[14.5px]">
          {created.name} · <span className="num text-fore">{created.reference}</span> was provisioned on the panel and
          will be cleaned up automatically when it expires.
        </p>
        <dl className="border-line mt-6 grid gap-px border bg-line/60 sm:grid-cols-4">
          {[
            ["RAM", mb(created.ramMb)],
            ["CPU", `${created.cpuPercent}%`],
            ["DISK", mb(created.diskMb)],
            ["EXPIRES IN", ""],
          ].map(([label, value]) => (
            <div key={label} className="bg-panel px-4 py-3">
              <dt className="legend text-mute text-[8.5px]">{label}</dt>
              <dd className="num text-chalk mt-1 text-[15px]">
                {value || <Countdown expiresAt={created.expiresAt} />}
              </dd>
            </div>
          ))}
        </dl>
        <div className="mt-6 flex flex-wrap gap-3">
          <LinkButton href="/account/servers" label="Open demo dashboard" />
          <LinkButton href="/pricing" label="Compare paid plans" ghost />
        </div>
      </motion.div>
    );
  }

  const canCreate = Boolean(provisioning?.configured) && config.enabled && !busy;

  return (
    <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
      {/* --------------------------- configurator --------------------------- */}
      <div className="flex flex-col gap-5">
        {!config.enabled && (
          <Banner tone="warn" title="Demo disabled" body="The administrator has disabled the free server demo." />
        )}
        {provisioning && !provisioning.configured && (
          <Banner tone="warn" title="Provisioning backend not connected" body={provisioning.message} />
        )}
        {error && <Banner tone="err" title="Provisioning failed" body={error} />}

        {/* server name */}
        <Section icon={Server} title="Server name">
          <input
            value={sel?.name ?? ""}
            onChange={(e) => saveLocal({ ...sel, name: e.target.value })}
            className="border-line bg-raised focus:border-signal/70 text-fore w-full border px-4 py-3 text-[14px] outline-none"
            placeholder="My demo server"
            maxLength={60}
          />
        </Section>

        {/* RAM */}
        <Section icon={Server} title="RAM allocation" hint={`${mb(config.ram.freeMb)} free allowance · max ${mb(config.ram.maxMb)}`}>
          <ChipRow
            options={config.ram.options}
            value={sel?.ramMb}
            disabledValue={config.ram.maxMb}
            render={(v) => mb(v)}
            free={(v) => v <= config.ram.freeMb}
            onChange={(v) => saveLocal({ ...sel, ramMb: v })}
          />
          {!config.ram.allowPaid && <p className="legend text-mute mt-2">PAID RAM UPGRADES ARE DISABLED — ONLY THE FREE ALLOWANCE IS AVAILABLE</p>}
        </Section>

        {/* CPU */}
        <Section icon={Cpu} title="CPU allocation" hint={`${config.cpu.freePercent}% free allowance · max ${config.cpu.maxPercent}%`}>
          <ChipRow
            options={config.cpu.options}
            value={sel?.cpuPercent}
            disabledValue={config.cpu.maxPercent}
            render={(v) => `${v}% CPU`}
            free={(v) => v <= config.cpu.freePercent}
            onChange={(v) => saveLocal({ ...sel, cpuPercent: v })}
          />
          <p className="legend text-mute mt-2">ALLOCATED AS A REAL PANEL CPU LIMIT — NOT A LABEL</p>
        </Section>

        {/* Disk */}
        <Section icon={HardDrive} title="Storage" hint={`${config.disk.type} · ${mb(config.disk.freeMb)} free · max ${mb(config.disk.maxMb)}`}>
          <ChipRow
            options={config.disk.options}
            value={sel?.diskMb}
            disabledValue={config.disk.maxMb}
            render={(v) => mb(v)}
            free={(v) => v <= config.disk.freeMb}
            onChange={(v) => saveLocal({ ...sel, diskMb: v })}
          />
        </Section>

        {/* Duration */}
        <Section icon={Timer} title="Demo duration" hint={`Default ${durationLabel(config.duration.defaultMinutes)} · max ${durationLabel(config.duration.maxMinutes)}`}>
          <ChipRow
            options={config.duration.options}
            value={sel?.durationMinutes}
            disabledValue={config.duration.maxMinutes}
            render={(v) => durationLabel(v)}
            free={() => true}
            onChange={(v) => saveLocal({ ...sel, durationMinutes: v })}
          />
          <p className="legend text-mute mt-2">
            AUTO-EXPIRY: {config.duration.expireAction === "delete" ? "DESTROYED" : "STOPPED"} AFTER THE RUNTIME
            {config.duration.allowExtension ? ` · EXTENSIONS OF ${durationLabel(config.duration.extensionMinutes)} ALLOWED` : " · NO EXTENSIONS"}
          </p>
        </Section>

        {/* Software */}
        <Section icon={Boxes} title="Server software" hint={`${software.length} option(s) enabled by the administrator`}>
          <div className="grid gap-2 sm:grid-cols-2">
            {software.map((s: any) => {
              const on = sel?.software === s.id;
              return (
                <button
                  key={s.id}
                  onClick={() => saveLocal({ ...sel, software: s.id })}
                  className={`border p-3.5 text-left transition-all ${
                    on ? "border-signal/70 bg-signal/10" : "border-line hover:border-line-2 hover:bg-raised/60"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-[14px] font-medium ${on ? "text-chalk" : "text-fore"}`}>{s.name}</span>
                    {on && <CheckCircle2 size={14} className="text-signal" />}
                  </div>
                  <span className="legend text-mute mt-1 block">{s.version ? `VERSION ${s.version}` : "LATEST"}</span>
                </button>
              );
            })}
            {software.length === 0 && <p className="text-mute text-[13.5px]">No server software is enabled for demos.</p>}
          </div>
        </Section>
      </div>

      {/* ------------------------------ summary ----------------------------- */}
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <div className="panel overflow-hidden">
          <div className="border-line flex items-center justify-between border-b px-5 py-3.5">
            <span className="legend text-signal">FREE SERVER CONFIGURATION</span>
            <span className="legend text-mute">LIVE</span>
          </div>

          <div className="border-line grid grid-cols-2 gap-px border-b bg-line/60">
            {[
              ["RAM", sel ? mb(sel.ramMb) : "—"],
              ["CPU", sel ? `${sel.cpuPercent}%` : "—"],
              ["DISK", sel ? mb(sel.diskMb) : "—"],
              ["DURATION", sel ? durationLabel(sel.durationMinutes) : "—"],
              ["SOFTWARE", software.find((s: any) => s.id === sel?.software)?.name ?? "—"],
              ["TYPE", config.disk.type],
            ].map(([label, value]) => (
              <div key={label} className="bg-panel px-4 py-3">
                <div className="legend text-mute text-[8.5px]">{label}</div>
                <div className="num text-chalk mt-1 truncate text-[13.5px]">{value}</div>
              </div>
            ))}
          </div>

          <div className="p-5">
            <div className="legend text-mute mb-3">PRICE BREAKDOWN</div>
            <ul className="flex flex-col gap-2.5">
              {price?.lines.map((line) => (
                <li key={line.key} className="flex items-start justify-between gap-3">
                  <span>
                    <span className="text-fore block text-[13.5px]">{line.label}</span>
                    <span className="legend text-mute block text-[8.5px]">{line.detail}</span>
                  </span>
                  <span className="text-right">
                    {line.free ? (
                      <span className="legend text-led border-led/40 border px-1.5 py-0.5">FREE</span>
                    ) : (
                      <span className="num text-signal text-[14px]">{money(line.amount, config.currency)}</span>
                    )}
                  </span>
                </li>
              ))}
            </ul>

            <div className="border-line mt-5 flex items-baseline justify-between border-t pt-4">
              <span className="text-chalk text-[14px] font-medium">Total / month</span>
              <span className={`num text-[26px] font-semibold ${price?.free ? "text-led" : "text-chalk"}`}>
                {price?.free ? "FREE" : money(price?.total ?? 0, config.currency)}
              </span>
            </div>

            {price && !price.free && (
              <p className="legend text-signal mt-2">
                PAID UPGRADE — DEBITED FROM YOUR WALLET AFTER THE SERVER IS PROVISIONED
              </p>
            )}
            {price?.free && <p className="legend text-led mt-2">ALL SELECTED RESOURCES ARE INSIDE THE FREE ALLOWANCE</p>}

            <button
              onClick={create}
              disabled={!canCreate}
              className="bg-signal text-void hover:bg-signal-2 legend mt-5 flex w-full items-center justify-center gap-2 py-4 font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-55"
            >
              {busy ? (
                <>
                  <Loader2 size={14} className="animate-spin" /> PROVISIONING…
                </>
              ) : (
                <>
                  {authed === false ? "SIGN IN TO CREATE" : config.cta} <ArrowRight size={14} />
                </>
              )}
            </button>

            {!provisioning?.configured && (
              <p className="legend text-signal mt-3 leading-relaxed">{provisioning?.message}</p>
            )}
            {provisioning?.configured && (
              <p className="legend text-mute mt-3">
                BACKEND: {provisioning.baseUrl} · RESOURCES ARE VALIDATED SERVER-SIDE BEFORE PROVISIONING
              </p>
            )}
          </div>
        </div>
      </aside>
    </div>
  );
}

function decoded(v: string) {
  return v;
}

function Section({ icon: Icon, title, hint, children }: any) {
  return (
    <section className="panel p-5">
      <div className="mb-4 flex items-center gap-3 border-line border-b pb-3">
        <span className="border-line text-signal flex h-8 w-8 items-center justify-center border">
          <Icon size={15} />
        </span>
        <div>
          <h3 className="text-chalk text-[15px] font-semibold">{title}</h3>
          {hint && <p className="legend text-mute mt-0.5">{hint}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

type ChipRowProps = {
  options: number[];
  value?: number;
  disabledValue: number;
  render: (v: number) => string;
  free: (v: number) => boolean;
  onChange: (v: number) => void;
};

function ChipRow({ options, value, disabledValue, render, free, onChange }: ChipRowProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt: number) => {
        const on = value === opt;
        const over = opt > disabledValue;
        const isFree = free(opt);
        return (
          <button
            key={opt}
            onClick={() => !over && onChange(opt)}
            disabled={over}
            className={`legend relative border px-3.5 py-2.5 transition-all ${
              over
                ? "cursor-not-allowed border-line/60 text-mute/40"
                : on
                  ? "border-signal/70 bg-signal/10 text-signal"
                  : "border-line text-fore hover:border-line-2 hover:bg-raised/60"
            }`}
          >
            {render(opt)}
            {isFree && !over && (
              <span className="absolute -top-2 -right-2 bg-led text-void legend px-1 py-px text-[7px]">FREE</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

function Banner({ tone, title, body }: { tone: "warn" | "err"; title: string; body?: string }) {
  const cls = tone === "warn" ? "border-signal/40 bg-signal/8" : "border-red-500/40 bg-red-500/8";
  return (
    <div className={`border p-4 ${cls}`}>
      <div className="flex items-center gap-2">
        <TriangleAlert size={15} className={tone === "warn" ? "text-signal" : "text-red-400"} />
        <span className="legend">{title}</span>
      </div>
      {body && <p className="text-fore mt-2 text-[13.5px]">{body}</p>}
    </div>
  );
}

function LinkButton({ href, label, ghost = false }: { href: string; label: string; ghost?: boolean }) {
  return (
    <a
      href={href}
      className={
        ghost
          ? "border-line text-fore hover:border-chalk hover:text-chalk border px-5 py-3 text-[13.5px] transition-all"
          : "bg-signal text-void hover:bg-signal-2 px-5 py-3 text-[13.5px] font-semibold transition-colors"
      }
    >
      {label}
    </a>
  );
}
