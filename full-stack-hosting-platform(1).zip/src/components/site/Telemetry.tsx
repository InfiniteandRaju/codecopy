"use client";

import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "framer-motion";

function useTicker(target: number | null) {
  const [val, setVal] = useState<number | null>(target);
  const prev = useRef<number | null>(target);
  useEffect(() => {
    if (target == null) {
      setVal(null);
      return;
    }
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setVal(target);
      prev.current = target;
      return;
    }
    const from = prev.current ?? target;
    const start = performance.now();
    const dur = 650;
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(step);
      else prev.current = target;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return val;
}

/**
 * Hero telemetry. Every number is either a real measurement (latency, online
 * count) or an administrator-configured fact — nothing is randomised.
 */
export function Telemetry({ configured }: { configured: { uptime: string; nodes: number; blocked: string } }) {
  const reduce = useReducedMotion();
  const [series, setSeries] = useState<number[]>([]);
  const [p50, setP50] = useState<number | null>(null);
  const [online, setOnline] = useState<{ up: number; total: number }>({ up: 0, total: 0 });
  const [checkedAt, setCheckedAt] = useState<string | null>(null);
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");

  const measure = async () => {
    try {
      const res = await fetch("/api/latency", { cache: "no-store" });
      const data = await res.json();
      if (!res.ok && res.status !== 429) throw new Error("unavailable");
      const measured = (data.locations ?? [])
        .map((l: any) => l.ms)
        .filter((n: any) => typeof n === "number" && Number.isFinite(n)) as number[];
      const total = (data.locations ?? []).length;
      const up = (data.locations ?? []).filter((l: any) => l.status === "online").length;

      if (measured.length) {
        const sorted = [...measured].sort((a, b) => a - b);
        const median = sorted[Math.floor(sorted.length / 2)];
        setP50(median);
        setSeries((prev) => [...prev.slice(-40), median]);
      } else {
        setP50(null);
        setSeries((prev) => [...prev.slice(-40), 0]);
      }
      setOnline({ up, total });
      setCheckedAt(data.measuredAt ?? new Date().toISOString());
      setState("ok");
    } catch {
      setState("error");
      setP50(null);
    }
  };

  useEffect(() => {
    measure();
    const id = setInterval(measure, 30_000);
    return () => clearInterval(id);
  }, []);

  const latencyText = useTicker(p50);

  const w = 300;
  const h = 68;
  const hasData = series.some((v) => v > 0);
  const max = Math.max(...series, 1);
  const min = Math.min(...series);
  const points = series.length
    ? series.map((v, i) => `${(i / Math.max(1, series.length - 1)) * w},${h - ((v - min) / (max - min || 1)) * (h - 12) - 6}`).join(" ")
    : "";
  const area = points ? `0,${h} ${points} ${w},${h}` : "";

  const rows: { label: string; value: string; unit: string; accent?: boolean }[] = [
    {
      label: "P50 LATENCY",
      value: state === "loading" ? "…" : latencyText != null ? String(Math.round(latencyText)) : "N/A",
      unit: latencyText != null ? "ms" : "",
      accent: true,
    },
    {
      label: "LOCATIONS ONLINE",
      value: state === "loading" ? "…" : online.total ? `${online.up}/${online.total}` : "N/A",
      unit: "",
    },
    { label: "UPTIME 90D", value: configured.uptime ?? "—", unit: "%" },
    { label: "MITIGATION", value: configured.blocked ?? "—", unit: "" },
  ];

  return (
    <div className="panel relative w-full overflow-hidden">
      <div className="border-line flex items-center justify-between border-b px-4 py-2.5">
        <span className="legend text-signal flex items-center gap-2">
          <span
            className={`led led-pulse h-1.5 w-1.5 rounded-full ${
              state === "ok" && online.total > 0 && online.up === online.total ? "bg-led text-led" : state === "error" ? "bg-signal text-signal" : "bg-link text-link"
            }`}
          />
          {state === "error" ? "MEASUREMENT OFFLINE" : "LIVE · MEASURED"}
        </span>
        <span className="legend text-mute">TELEMETRY</span>
      </div>

      <div className="px-4 pt-3">
        <svg viewBox={`0 0 ${w} ${h}`} className="h-[68px] w-full" preserveAspectRatio="none" aria-hidden="true">
          <defs>
            <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FF6B18" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#FF6B18" stopOpacity="0" />
            </linearGradient>
          </defs>
          {hasData ? (
            <>
              <polygon points={area} fill="url(#sparkFill)" />
              <polyline
                points={points}
                fill="none"
                stroke="#FF6B18"
                strokeWidth="1.6"
                strokeLinejoin="round"
                vectorEffect="non-scaling-stroke"
                style={
                  reduce
                    ? undefined
                    : { strokeDasharray: 1400, strokeDashoffset: 1400, animation: "drawLine 1.4s cubic-bezier(.2,.8,.3,1) forwards" }
                }
              />
            </>
          ) : (
            <text x={w / 2} y={h / 2 + 4} textAnchor="middle" fill="#8A94A8" fontSize="11" fontFamily="IBM Plex Mono">
              {state === "loading" ? "MEASURING…" : "NO MEASURABLE ENDPOINTS"}
            </text>
          )}
        </svg>

        <div className="border-line/70 mt-1 grid grid-cols-4 gap-px border-t bg-line/40">
          {rows.map((r) => (
            <div key={r.label} className="bg-panel px-2 py-2.5 text-center">
              <div className={`num text-[15px] font-semibold ${r.accent ? "text-signal" : "text-chalk"}`}>
                {r.value}
                {r.unit && <span className="text-mute text-[10px]">{r.unit}</span>}
              </div>
              <div className="legend text-mute mt-1 text-[7.5px] leading-tight">{r.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="px-4 py-3">
        <div className="legend text-mute flex items-center justify-between text-[8.5px]">
          <span>{checkedAt ? `LAST CHECK ${new Date(checkedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "ACQUIRING…"}</span>
          <span className={state === "error" ? "text-signal" : hasData ? "text-led" : "text-mute"}>
            {state === "error" ? "UNAVAILABLE" : hasData ? "REAL RTT SAMPLES" : "AWAITING ENDPOINTS"}
          </span>
        </div>
      </div>
    </div>
  );
}
