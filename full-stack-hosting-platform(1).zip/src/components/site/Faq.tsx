"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus, Minus } from "lucide-react";

export function FaqList({ items }: { items: { id?: string; question: string; answer: string; group?: string }[] }) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="border-line border-t">
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={item.id ?? i} className="border-line border-b">
            <button
              onClick={() => setOpen(isOpen ? null : i)}
              className="group flex w-full items-start gap-5 py-5 text-left"
              aria-expanded={isOpen}
            >
              <span className={`num mt-1 text-[11px] ${isOpen ? "text-signal" : "text-mute"}`}>
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="flex-1">
                {item.group && <span className="legend text-mute mb-1 block text-[9px]">{item.group}</span>}
                <span
                  className={`block text-[16.5px] leading-snug font-medium transition-colors md:text-[17.5px] ${
                    isOpen ? "text-chalk" : "text-fore group-hover:text-chalk"
                  }`}
                >
                  {item.question}
                </span>
              </span>
              <span
                className={`mt-1 border p-1.5 transition-all ${
                  isOpen ? "border-signal/60 bg-signal/10 text-signal" : "border-line text-mute group-hover:border-line-2"
                }`}
              >
                {isOpen ? <Minus size={13} /> : <Plus size={13} />}
              </span>
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: [0.16, 0.8, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <p className="text-mute max-w-3xl pr-10 pb-6 pl-9 text-[14.5px] leading-relaxed">{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
