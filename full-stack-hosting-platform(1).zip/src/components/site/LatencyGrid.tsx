"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { RefreshCw, MapPin, Wifi, WifiOff, Clock } from "lucide-react";

type Loc = {
  id: string;
  name: string;
  city: string | null;
  country: string | null;
  code: string | null;
  tier: string | null;
  endpoint: string | null;
  ms: number | null;
  status: "online" | "offline" | "timeout" | "unavailable";
  httpStatus: number | null;
  error: string | null;
  checkedAt: string;
  source: "server" | null;
};

type Row = Loc & { browserMs: number | null; browserOk: boolean | null; checking: boolean };

/** Real RTT from the visitor's browser to the configured health endpoint. */
function probeBrowser(endpoint: string, timeoutMs = 4000): Promise<{ ms: number | null; ok: boolean }> {
  return new Promise((resolve) => {
    if (typeof performance === "undefined") return resolve({ ms: null, ok: false });
    const controller = new AbortController();
    const timer = setTimeout(() => {
      controller.abort();
      resolve({ ms: null, ok: false });
    }, timeoutMs);
    const start = performance.now();
    fetch(endpoint, { method: "GET", cache: "no-store", mode: "no-cors", signal: controller.signal })
      .then(() => {
        clearTimeout(timer);
        resolve({ ms: Math.round(performance.now() - start), ok: true });
      })
      .catch(() => {
        clearTimeout(timer);
        resolve({ ms: null, ok: false });
      });
  });
}

const STATUS_STYLE: Record<string, string> = {
  online: "border-led/40 text-led bg-led/10",
  offline: "border-signal/40 text-signal bg-signal/10",
  timeout: "border-signal/40 text-signal bg-signal/10",
  unavailable: "border-line text-mute",
};

const STATUS_LABEL: Record<string, string> = {
  online: "ONLINE",
  offline: "OFFLINE",
  timeout: "TIMEOUT",
  unavailable: "UNAVAILABLE",
};

/**
 * Displays only measured latency. A location with no endpoint — or one that
 * cannot be reached — shows N/A, never a made-up number.
 */
export function LatencyGrid({ compact = false }: { compact?: boolean }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [throttled, setThrottled] = useState(false);
  const [checkedAt, setCheckedAt] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const inflight = useRef(false);

  const load = useCallback(async (withBrowserProbe = true) => {
    if (inflight.current) return;
    inflight.current = true;
    if (withBrowserProbe) setLoading(true);
    try {
      const res = await fetch("/api/latency", { cache: "no-store" });
      const data = await res.json();
      if (res.status === 429) setThrottled(true);
      else setThrottled(false);
      if (!res.ok && res.status !== 429) throw new Error(data.error ?? "Measurement failed");
      const base: Row[] = (data.locations ?? []).map((l: Loc) => ({
        ...l,
        browserMs: null,
        browserOk: null,
        checking: Boolean(l.endpoint),
      }));
      setRows(base);
      setCheckedAt(data.measuredAt ?? new Date().toISOString());
      setError(null);

      // Second pass: real RTT measured from this browser to each endpoint.
      if (withBrowserProbe) {
        await Promise.all(
          base.map(async (l) => {
            if (!l.endpoint) {
              setRows((prev) => prev.map((r) => (r.id === l.id ? { ...r, checking: false } : r)));
              return;
            }
            const probe = await probeBrowser(l.endpoint, 4000);
            setRows((prev) =>
              prev.map((r) =>
                r.id === l.id
                  ? { ...r, browserMs: probe.ms, browserOk: probe.ok, checking: false }
                  : r,
              ),
            );
          }),
        );
        setCheckedAt(new Date().toISOString());
      }
    } catch (e: any) {
      setError(e?.message ?? "Latency service unreachable");
    } finally {
      setLoading(false);
      inflight.current = false;
    }
  }, []);

  useEffect(() => {
    load(true);
    const id = setInterval(() => load(false), 60_000);
    return () => clearInterval(id);
  }, [load]);

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <p className="legend text-mute flex items-center gap-2">
          <Clock size={11} />
          {checkedAt
            ? `LAST CHECKED ${new Date(checkedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`
            : "MEASURING…"}
          {loading && <span className="text-signal">· RUNNING</span>}
        </p>
        <button
          onClick={() => load(true)}
          disabled={loading}
          className="border-line text-mute hover:text-signal hover:border-signal/40 flex items-center gap-2 border px-3 py-1.5 text-[11px] transition-all disabled:opacity-50"
        >
          <RefreshCw size={11} className={loading ? "animate-spin" : ""} /> RE-MEASURE
        </button>
      </div>

      {error && (
        <p className="border-signal/40 bg-signal/10 text-signal-2 mb-3 border px-3 py-2 text-[13px]">
          Latency service unavailable: {error}
        </p>
      )}
      {throttled && !error && (
        <p className="legend text-mute mb-3">MEASUREMENT RATE-LIMITED — RETRY IN A MOMENT</p>
      )}

      <div className="grid gap-px bg-line/60 sm:grid-cols-2 lg:grid-cols-3">
        {rows.map((r) => {
          const measured = r.browserMs ?? r.ms;
          const status =
            r.status === "unavailable"
              ? "unavailable"
              : measured != null
                ? r.browserOk === false && r.browserMs == null && r.status !== "online"
                  ? r.status
                  : "online"
                : r.status;
          const label = (r.city || r.name) + (r.country && r.city ? `, ${r.country}` : "");
          return (
            <div key={r.id} className="bg-panel flex flex-col gap-2 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-chalk flex items-center gap-2 text-[15px] font-medium">
                    <MapPin size={13} className="text-signal shrink-0" />
                    <span className="truncate">{label}</span>
                  </div>
                  <div className="legend text-mute mt-1">
                    {r.code ?? "—"}
                    {r.tier ? ` · ${r.tier}` : ""} · {r.endpoint ? "MEASURED ENDPOINT" : "NO ENDPOINT CONFIGURED"}
                  </div>
                </div>
                <span className={`legend flex shrink-0 items-center gap-1.5 border px-2 py-0.5 ${STATUS_STYLE[status]}`}>
                  {status === "online" ? <Wifi size={10} /> : <WifiOff size={10} />}
                  {STATUS_LABEL[status]}
                </span>
              </div>

              <div className="flex items-end justify-between gap-3">
                <div className="num flex items-baseline gap-2">
                  {measured != null ? (
                    <>
                      <span className="text-chalk text-[26px] leading-none font-semibold">{measured}</span>
                      <span className="legend text-mute">MS</span>
                    </>
                  ) : (
                    <span className="text-mute text-[22px] leading-none">N/A</span>
                  )}
                  {measured != null && (
                    <span className="legend text-mute/70 text-[8px]">{r.browserMs != null ? "BROWSER RTT" : "SERVER RTT"}</span>
                  )}
                </div>
                {!r.endpoint && <span className="legend text-mute/70 max-w-[140px] text-right text-[8px]">ADD AN ENDPOINT IN ADMIN</span>}
                {r.endpoint && measured == null && (
                  <span className="legend text-signal/80 max-w-[150px] text-right text-[8px]">{(r.error ?? "no response").toUpperCase()}</span>
                )}
              </div>
            </div>
          );
        })}

        {rows.length === 0 && !loading && (
          <div className="bg-panel col-span-full p-6 text-center">
            <p className="text-mute text-[13.5px]">No server locations configured yet.</p>
            <p className="legend text-mute/70 mt-2">ADD THEM IN ADMIN → SERVER LOCATIONS</p>
          </div>
        )}
      </div>

      {!compact && (
        <p className="legend text-mute/70 mt-3">
          VALUES ARE REAL ROUND-TRIP TIMES. LOCATIONS WITHOUT A REACHABLE ENDPOINT REPORT N/A — NO LATENCY IS EVER ESTIMATED.
        </p>
      )}
    </div>
  );
}
