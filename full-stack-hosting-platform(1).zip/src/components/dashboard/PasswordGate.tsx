"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ShieldAlert, Loader2 } from "lucide-react";
import { Wordmark } from "@/components/site/Mark";
import { useToast } from "@/components/ui/Toast";

/**
 * Blocks console access until a seeded default password is replaced.
 * Enforced server-side by the admin layout — not merely hidden in the UI.
 */
export function PasswordGate({ email, name }: { email: string; name: string }) {
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { push } = useToast();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (form.newPassword !== form.confirm) {
      setError("New password and confirmation do not match.");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/account/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: form.currentPassword, newPassword: form.newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Password change failed");
      push("Password updated — console access granted.", "ok");
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const input =
    "border-line bg-raised focus:border-signal/70 placeholder:text-mute/50 text-fore w-full border px-3.5 py-3 text-[14px] outline-none transition-colors";

  return (
    <div className="bg-void flex min-h-screen items-center justify-center px-5 py-16">
      <form onSubmit={submit} className="panel w-full max-w-[460px] p-7">
        <Wordmark />
        <div className="legend text-signal mt-8 flex items-center gap-2">
          <ShieldAlert size={13} /> DEFAULT PASSWORD · CHANGE REQUIRED
        </div>
        <h1 className="mt-3 text-[1.6rem] font-semibold">Rotate your password</h1>
        <p className="text-mute mt-2 text-[13.5px] leading-relaxed">
          This account is still using a seeded development password. Console access is blocked until it is replaced —
          required before any production deployment.
        </p>

        <div className="mt-6 flex flex-col gap-4">
          <label className="block">
            <span className="legend text-mute mb-2 block">SIGNED IN AS</span>
            <input value={`${name} · ${email}`} disabled className={`${input} opacity-70`} />
          </label>
          <label className="block">
            <span className="legend text-mute mb-2 block">CURRENT PASSWORD</span>
            <input
              type="password"
              required
              value={form.currentPassword}
              onChange={(e) => setForm({ ...form, currentPassword: e.target.value })}
              className={input}
              autoComplete="current-password"
            />
          </label>
          <label className="block">
            <span className="legend text-mute mb-2 block">NEW PASSWORD</span>
            <input
              type="password"
              required
              value={form.newPassword}
              onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
              className={input}
              autoComplete="new-password"
            />
          </label>
          <label className="block">
            <span className="legend text-mute mb-2 block">CONFIRM NEW PASSWORD</span>
            <input
              type="password"
              required
              value={form.confirm}
              onChange={(e) => setForm({ ...form, confirm: e.target.value })}
              className={input}
              autoComplete="new-password"
            />
          </label>

          {error && <p className="border-signal/40 bg-signal/10 text-signal-2 border px-3 py-2.5 text-[13px]">{error}</p>}

          <button
            type="submit"
            disabled={busy}
            className="bg-signal text-void hover:bg-signal-2 flex items-center justify-center gap-2 py-3.5 text-[14px] font-semibold transition-colors disabled:opacity-60"
          >
            {busy ? <Loader2 size={15} className="animate-spin" /> : null}
            {busy ? "SAVING…" : "Set password & continue"}
          </button>
        </div>
      </form>
    </div>
  );
}
