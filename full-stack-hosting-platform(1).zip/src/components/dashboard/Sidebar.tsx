"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronDown,
  LogOut,
  ExternalLink,
  X,
  Menu,
  LayoutDashboard,
  Boxes,
  FolderTree,
  Tags,
  ReceiptText,
  CreditCard,
  Users,
  Home,
  Settings,
  FileText,
  Terminal,
  MapPin,
  Wallet,
  Package,
  User,
  type LucideIcon,
} from "lucide-react";
import { useBranding } from "@/components/brand/BrandingProvider";

/**
 * Icons may be passed as components (client-defined nav) or as names
 * (server-defined nav) — server components cannot hand functions to the client.
 */
const ICONS: Record<string, LucideIcon> = {
  dashboard: LayoutDashboard,
  boxes: Boxes,
  folder: FolderTree,
  tags: Tags,
  orders: ReceiptText,
  payments: CreditCard,
  users: Users,
  home: Home,
  settings: Settings,
  content: FileText,
  terminal: Terminal,
  location: MapPin,
  wallet: Wallet,
  package: Package,
  user: User,
};

export function resolveIcon(icon: LucideIcon | string): LucideIcon {
  if (typeof icon === "string") return ICONS[icon] ?? Boxes;
  return icon;
}

export type SidebarItem = {
  key: string;
  label: string;
  href: string;
  icon: LucideIcon | string;
  /** Nested entries render as an expandable group with its own active state. */
  children?: { key: string; label: string; href: string; exact?: boolean }[];
};

export type SidebarUser = { name: string; email: string; role: string };

function isActive(pathname: string, href: string, exact?: boolean) {
  if (href === "/") return pathname === "/";
  if (exact) return pathname === href;
  return pathname === href || pathname.startsWith(`${href}/`);
}

function NavList({
  items,
  pathname,
  onNavigate,
  compact = false,
}: {
  items: SidebarItem[];
  pathname: string;
  onNavigate?: () => void;
  compact?: boolean;
}) {
  const [open, setOpen] = useState<Record<string, boolean>>({});

  // Auto-expand the group containing the active route.
  useEffect(() => {
    const next: Record<string, boolean> = {};
    items.forEach((item) => {
      if (item.children?.some((c) => isActive(pathname, c.href, c.exact))) next[item.key] = true;
    });
    setOpen((prev) => ({ ...next, ...prev }));
  }, [pathname, items]);

  return (
    <nav className="flex min-h-0 flex-1 flex-col gap-0.5 overflow-y-auto overflow-x-hidden px-3 py-3 thin-scroll" aria-label="Dashboard">
      {items.map((item) => {
        const parentActive = isActive(pathname, item.href) && !(item.children ?? []).some((c) => isActive(pathname, c.href, c.exact));
        const childActive = item.children?.some((c) => isActive(pathname, c.href, c.exact)) ?? false;
        const isOpen = open[item.key] ?? false;
        const Icon = resolveIcon(item.icon);

        return (
          <div key={item.key} className="shrink-0">
            <div
              className={`group flex items-center gap-3 border-l-2 pr-2 transition-all duration-200 ${
                parentActive || childActive
                  ? "border-signal bg-signal/10"
                  : "border-transparent hover:bg-raised hover:border-line-2"
              }`}
            >
              <Link
                href={item.href}
                onClick={onNavigate}
                className={`flex min-w-0 flex-1 items-center gap-3 py-2.5 pl-3 text-[13.5px] transition-colors ${
                  parentActive ? "text-chalk" : childActive ? "text-fore" : "text-mute group-hover:text-fore"
                }`}
              >
                <Icon size={15} className={parentActive || childActive ? "text-signal" : "text-mute group-hover:text-fore"} />
                <span className="truncate">{item.label}</span>
              </Link>
              {item.children && item.children.length > 0 && (
                <button
                  type="button"
                  aria-expanded={isOpen}
                  aria-label={isOpen ? `Collapse ${item.label}` : `Expand ${item.label}`}
                  onClick={() => setOpen((o) => ({ ...o, [item.key]: !isOpen }))}
                  className={`p-1.5 text-mute transition-all hover:text-signal ${isOpen ? "rotate-180" : ""}`}
                >
                  <ChevronDown size={13} />
                </button>
              )}
            </div>

            <AnimatePresence initial={false}>
              {item.children && item.children.length > 0 && isOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.24, ease: [0.16, 0.8, 0.3, 1] }}
                  className="overflow-hidden"
                >
                  <div className={`border-line ml-4 flex flex-col border-l pl-1 ${compact ? "" : ""}`}>
                    {item.children.map((child) => {
                      const on = isActive(pathname, child.href, child.exact);
                      return (
                        <Link
                          key={child.key}
                          href={child.href}
                          onClick={onNavigate}
                          className={`flex items-center justify-between gap-2 border-l-2 py-2 pl-3 text-[13px] transition-all ${
                            on
                              ? "border-signal bg-signal/8 text-chalk"
                              : "border-transparent text-mute hover:text-fore hover:bg-raised/60"
                          }`}
                        >
                          <span className="truncate">{child.label}</span>
                          {on && <span className="bg-signal h-1.5 w-1.5 rounded-full" />}
                        </Link>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </nav>
  );
}

function UserBlock({ user, onLogout, layout }: { user: SidebarUser; onLogout: () => void; layout: "panel" | "bar" }) {
  const branding = useBranding();
  if (layout === "bar") {
    return (
      <div className="flex min-w-0 items-center gap-3">
        <span className="bg-signal/15 text-signal legend flex h-8 w-8 shrink-0 items-center justify-center border border-signal/30">
          {user.name.slice(0, 1).toUpperCase()}
        </span>
        <div className="min-w-0">
          <div className="text-chalk truncate text-[13px] leading-tight">{user.name}</div>
          <div className="legend text-mute truncate text-[8px]">{String(user.role).replace("_", " ")}</div>
        </div>
      </div>
    );
  }
  return (
    <div className="border-line bg-raised/60 border p-3">
      <div className="legend text-mute mb-1 text-[8.5px]">{branding.siteName.toUpperCase()}</div>
      <div className="text-chalk truncate text-[13px]">{user.name}</div>
      <div className="legend text-signal mt-0.5 truncate">{String(user.role).replace("_", " ")}</div>
      <div className="mt-3 flex gap-2">
        <Link
          href="/"
          className="border-line text-mute hover:text-fore hover:border-line-2 flex flex-1 items-center justify-center gap-1.5 border py-1.5 text-[11px] transition-colors"
        >
          <ExternalLink size={11} /> Site
        </Link>
        <button
          onClick={onLogout}
          className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5 transition-colors"
          aria-label="Sign out"
        >
          <LogOut size={13} />
        </button>
      </div>
    </div>
  );
}

/**
 * The single sidebar implementation shared by the admin console and the
 * customer dashboard: fixed on desktop, drawer on mobile, always scrollable.
 */
export function Sidebar({
  items,
  user,
  homeHref = "/admin",
  variant = "admin",
  footer,
}: {
  items: SidebarItem[];
  user: SidebarUser;
  homeHref?: string;
  variant?: "admin" | "customer";
  footer?: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const isMobile = () => typeof window !== "undefined" && window.matchMedia("(max-width: 1023px)").matches;

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  };

  return (
    <>
      {/* Desktop: fixed rail with its own scroll container */}
      <aside className="border-line bg-panel/70 fixed inset-y-0 left-0 z-40 hidden w-[240px] flex-col border-r lg:flex">
        <div className="border-line shrink-0 px-5 py-5">
          <Link href={homeHref} aria-label={variant === "admin" ? "Console home" : "Dashboard home"}>
            <BrandLogo />
          </Link>
        </div>
        <div className="border-line mx-3 shrink-0 border-t" />
        <div className="legend text-mute px-5 pt-4 pb-1 shrink-0">{variant === "admin" ? "CONSOLE" : "ACCOUNT"}</div>
        <NavList items={items} pathname={pathname} />
        <div className="border-line shrink-0 border-t p-3">
          {footer ?? <UserBlock user={user} onLogout={logout} layout="panel" />}
        </div>
      </aside>

      {/* Mobile: top bar */}
      <div className="border-line bg-void/95 fixed inset-x-0 top-0 z-50 flex items-center justify-between gap-3 border-b px-4 py-3 backdrop-blur lg:hidden">
        <Link href={homeHref} className="min-w-0">
          <BrandLogo compact />
        </Link>
        <div className="flex items-center gap-2">
          <span className="legend text-mute hidden truncate sm:block">{String(user.role).replace("_", " ")}</span>
          <button
            onClick={() => setOpen((v) => !v)}
            className="border-line text-fore flex items-center gap-1.5 border px-3 py-2"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
          >
            {open ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="bg-black/60 fixed inset-0 z-50 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
              className="border-line bg-panel fixed inset-y-0 left-0 z-[60] flex w-[280px] max-w-[85vw] flex-col border-r shadow-2xl lg:hidden"
            >
              <div className="border-line flex shrink-0 items-center justify-between px-4 py-4">
                <Link href={homeHref} onClick={() => setOpen(false)}>
                  <BrandLogo compact />
                </Link>
                <button onClick={() => setOpen(false)} className="text-mute hover:text-signal" aria-label="Close menu">
                  <X size={17} />
                </button>
              </div>
              <div className="border-line mx-3 shrink-0 border-t" />
              <NavList items={items} pathname={pathname} onNavigate={() => setOpen(false)} />
              <div className="border-line shrink-0 border-t p-3">
                <UserBlock user={user} onLogout={logout} layout="panel" />
                {footer}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

function BrandLogo({ compact = false }: { compact?: boolean }) {
  const { siteName, logo, wordmark, submark, logoWidth, logoHeight } = useBranding();
  if (logo) {
    return (
      // Centralised branding: every surface renders the same configured image.
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={logo}
        alt={siteName}
        width={Math.round(compact ? logoWidth * 0.85 : logoWidth)}
        height={Math.round(compact ? logoHeight * 0.85 : logoHeight)}
        className="object-contain"
        style={{ maxHeight: compact ? 26 : logoHeight }}
      />
    );
  }
  return (
    <span className="flex items-center gap-2.5">
      <BrandMarkSvg size={compact ? 22 : 26} />
      <span className="flex flex-col leading-none">
        <span className="text-chalk font-display text-[14.5px] font-bold tracking-[0.02em]">{wordmark}</span>
        <span className="legend text-mute mt-0.5 text-[8px]">{submark}</span>
      </span>
    </span>
  );
}

function BrandMarkSvg({ size = 26 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <path d="M24 2.6 42.4 13.2v21.6L24 45.4 5.6 34.8V13.2L24 2.6Z" stroke="#FF6B18" strokeWidth="2.4" fill="rgba(255,107,24,0.06)" />
      <path d="M16.5 33V15.6l15 17.8V15" stroke="#EEF2F8" strokeWidth="3.1" strokeLinecap="square" fill="none" />
      <circle cx="24" cy="24" r="2.1" fill="#39D7E6" />
    </svg>
  );
}
