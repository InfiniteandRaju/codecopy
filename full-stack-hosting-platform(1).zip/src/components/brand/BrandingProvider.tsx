"use client";

import { createContext, useContext } from "react";

export type Branding = {
  siteName: string;
  tagline: string;
  logo: string | null;
  logoLight: string | null;
  logoDark: string | null;
  favicon: string | null;
  wordmark: string;
  submark: string;
  logoWidth: number;
  logoHeight: number;
};

const FALLBACK: Branding = {
  siteName: "Obsidian Node",
  tagline: "",
  logo: null,
  logoLight: null,
  logoDark: null,
  favicon: null,
  wordmark: "OBSIDIAN",
  submark: "NODE · INFRA",
  logoWidth: 132,
  logoHeight: 34,
};

const Ctx = createContext<Branding>(FALLBACK);

/** Injected once in the root layout from the database — no component hardcodes a logo path. */
export function BrandingProvider({ branding, children }: { branding: Branding; children: React.ReactNode }) {
  return <Ctx.Provider value={{ ...FALLBACK, ...(branding ?? {}) }}>{children}</Ctx.Provider>;
}

export function useBranding(): Branding {
  return useContext(Ctx);
}
