"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { RefreshCw, Send, Plug, PlugZap, TriangleAlert, Loader2, Terminal } from "lucide-react";
import { PageHead, Btn, useApi, Badge } from "@/components/admin/kit";
import { useToast } from "@/components/ui/Toast";

type ConsoleStatus = {
  connected: boolean;
  configured: boolean;
  baseUrl: string | null;
  message: string;
  servers?: { id: string; name: string; status?: string }[];
};

type Line = { id: string; kind: "out" | "err" | "sys"; text: string; at: string };

let lineSeq = 0;

/**
 * Server console. Every action proxies to the authorised server-management API
 * configured in Settings → Console integration; nothing is simulated. When no
 * integration exists the panel says so and command input stays disabled.
 */
export function ConsoleScreen() {
  const api = useApi();
  const { push } = useToast();
  const [status, setStatus] = useState<ConsoleStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [command, setCommand] = useState("");
  const [busy, setBusy] = useState(false);
  const [serverId, setServerId] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [resources, setResources] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const addLine = (kind: Line["kind"], text: string) =>
    setLines((prev) => [...prev.slice(-300), { id: `l${lineSeq++}`, kind, text, at: new Date().toISOString() }]);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.get("/api/admin/console");
      setStatus(data.status);
      if (data.status?.servers?.length) {
        setServerId((prev) => prev || data.status.servers![0].id);
      }
    } catch {
      /* toast shown by api */
    } finally {
      setLoading(false);
    }
  }, [api]);

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [lines]);

  const run = async (action: string, extra: Record<string, any> = {}, quiet = false) => {
    if (!quiet) setBusy(true);
    try {
      const data = await api.post("/api/admin/console", { action, serverId, ...extra });
      if (action === "logs") {
        const raw = data.result;
        const text =
          typeof raw === "string"
            ? raw
            : Array.isArray(raw?.lines)
              ? raw.lines.map((l: any) => (typeof l === "string" ? l : (l.line ?? l.message ?? JSON.stringify(l)))).join("\n")
              : (raw?.data ?? raw?.attributes?.current_log ?? raw);
        const chunk = typeof text === "string" ? text : JSON.stringify(text, null, 2);
        chunk.split("\n").filter(Boolean).slice(-120).forEach((l: string) => addLine("out", l));
      }
      if (action === "resources") setResources(data.result);
      if (action === "command") {
        addLine("sys", `> ${extra.command}`);
        if (data.result !== undefined && data.result !== null) {
          const text = typeof data.result === "string" ? data.result : JSON.stringify(data.result);
          text.split("\n").filter(Boolean).slice(-40).forEach((l: string) => addLine("out", l));
        }
      }
      if (action === "status") setStatus(data.status);
      return data;
    } catch (e: any) {
      addLine("err", e?.message ?? "request failed");
      if (!quiet) push(e?.message ?? "Console request failed", "err");
      return null;
    } finally {
      if (!quiet) setBusy(false);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim() || busy) return;
    const cmd = command;
    setCommand("");
    await run("command", { command: cmd });
  };

  // Poll logs + resources while connected.
  useEffect(() => {
    if (!status?.connected || !serverId) return;
    const id = setInterval(async () => {
      await run("logs", {}, true);
      await run("resources", {}, true);
    }, 8000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status?.connected, serverId]);

  const configured = Boolean(status?.configured);
  const connected = Boolean(status?.connected);

  return (
    <div>
      <PageHead
        title="Server console"
        subtitle="Authenticated command execution and live output through the server-management API. Real requests, real responses — no simulated terminal."
        actions={
          <>
            <Btn variant="ghost" onClick={refresh} disabled={loading}>
              <RefreshCw size={13} className={loading ? "animate-spin" : ""} /> Re-check connection
            </Btn>
          </>
        }
      />

      {/* connection state */}
      <div
        className={`mb-5 flex flex-wrap items-start justify-between gap-4 border px-4 py-3 ${
          connected ? "border-led/40 bg-led/8" : configured ? "border-signal/40 bg-signal/8" : "border-line bg-raised/50"
        }`}
      >
        <div className="flex items-start gap-3">
          {connected ? <PlugZap size={16} className="text-led mt-0.5" /> : <Plug size={16} className="text-mute mt-0.5" />}
          <div>
            <div className="legend flex flex-wrap items-center gap-2">
              <span className={connected ? "text-led" : configured ? "text-signal" : "text-mute"}>
                {connected ? "CONNECTED" : configured ? "CONFIGURED · UNREACHABLE" : "NOT CONFIGURED"}
              </span>
              {status?.baseUrl && <span className="text-mute">· {status.baseUrl}</span>}
            </div>
            <p className="text-fore mt-1.5 max-w-3xl text-[13.5px]">{loading ? "Checking connection…" : status?.message}</p>
            {!configured && (
              <p className="legend text-signal mt-2">
                MISSING INTEGRATION — ADD THE PANEL URL AND API TOKEN IN SETTINGS → CONSOLE INTEGRATION (SUPER ADMIN)
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {status?.servers && status.servers.length > 0 && (
            <select
              value={serverId}
              onChange={(e) => setServerId(e.target.value)}
              className="border-line bg-panel text-fore border px-3 py-2 text-[13px] outline-none"
              aria-label="Select server"
            >
              {status.servers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          )}
          <Badge tone={connected ? "ok" : configured ? "warn" : "mute"}>{connected ? "LIVE" : "OFFLINE"}</Badge>
        </div>
      </div>

      {/* live output */}
      <div className="panel overflow-hidden">
        <div className="border-line flex items-center justify-between border-b px-4 py-2.5">
          <span className="legend text-signal flex items-center gap-2">
            <Terminal size={13} /> LIVE OUTPUT {serverId ? `· SERVER ${serverId.slice(0, 8)}` : ""}
          </span>
          <span className="legend text-mute">{lines.length} LINES</span>
        </div>

        <div ref={scrollRef} className="bg-void/70 h-[340px] overflow-y-auto px-4 py-3 font-mono text-[12.5px] thin-scroll">
          {lines.length === 0 && (
            <p className="text-mute">
              {connected
                ? "Waiting for output — poll the panel for logs or run a command below."
                : "No output: the console is not connected to a server-management API."}
            </p>
          )}
          {lines.map((l) => (
            <div key={l.id} className="flex gap-3 py-0.5 leading-relaxed">
              <span className="text-mute/50 shrink-0 text-[10px]">{new Date(l.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span>
              <span className={l.kind === "err" ? "text-signal-2" : l.kind === "sys" ? "text-link" : "text-fore"}>{l.text}</span>
            </div>
          ))}
          {busy && <div className="text-signal mt-1 animate-pulse">working…</div>}
        </div>

        <form onSubmit={submit} className="border-line flex items-center gap-2 border-t p-3">
          <span className="text-signal font-mono text-[13px]">$</span>
          <input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            disabled={!connected || busy}
            placeholder={connected ? "Enter a command for the selected server" : "Console disabled until a management API is connected"}
            className="bg-panel border-line text-fore placeholder:text-mute/50 w-full border px-3 py-2.5 font-mono text-[13px] outline-none disabled:opacity-60"
          />
          <Btn type="submit" disabled={!connected || busy || !command.trim()}>
            {busy ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />} SEND
          </Btn>
        </form>
      </div>

      {/* live resources */}
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="panel p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="legend text-signal">RESOURCE SNAPSHOT</span>
            <Btn variant="ghost" disabled={!connected || busy} onClick={() => run("resources")}>
              <RefreshCw size={12} /> Refresh
            </Btn>
          </div>
          {resources ? (
            <dl className="grid grid-cols-2 gap-3 text-[13px]">
              {Object.entries(
                resources?.attributes ?? resources?.resources ?? resources,
              )
                .filter(([k, v]) => typeof v === "number" || typeof v === "string")
                .slice(0, 6)
                .map(([k, v]) => (
                  <div key={k}>
                    <dt className="legend text-mute text-[8.5px]">{k.replace(/_/g, " ")}</dt>
                    <dd className="num text-fore mt-1 truncate">{String(v)}</dd>
                  </div>
                ))}
            </dl>
          ) : (
            <p className="text-mute text-[13px]">Not loaded. Requires an active connection.</p>
          )}
        </div>

        <div className="panel p-4">
          <span className="legend text-signal mb-3 block">INTEGRATION STATUS</span>
          <div className="flex flex-col gap-2.5 text-[13px]">
            <Row label="Management API" value={configured ? status?.baseUrl ?? "configured" : "missing"} ok={configured} />
            <Row label="Authentication" value={configured ? "bearer token stored (encrypted)" : "no token"} ok={configured} />
            <Row label="Command execution" value={connected ? "available" : "unavailable"} ok={connected} />
            <Row label="Live log streaming" value={connected ? "polling every 8s" : "unavailable"} ok={connected} />
          </div>
          {!configured && (
            <div className="border-signal/40 bg-signal/8 mt-4 flex items-start gap-2 border p-3">
              <TriangleAlert size={14} className="text-signal mt-0.5 shrink-0" />
              <p className="text-fore text-[12.5px] leading-relaxed">
                This deployment has no server-management API (Pterodactyl, Wings, custom panel, …). The console stays
                disabled — it will not fake output. Configure credentials to activate it.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3 border-line border-b pb-2 last:border-0">
      <span className="text-mute">{label}</span>
      <span className={`legend ${ok ? "text-led" : "text-signal"}`}>{String(value).toUpperCase()}</span>
    </div>
  );
}
