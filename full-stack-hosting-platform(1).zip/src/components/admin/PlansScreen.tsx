"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Plus, Pencil, Copy, Trash2, Eye, EyeOff, ExternalLink, Star, Save, X } from "lucide-react";
import {
  PageHead,
  Btn,
  Modal,
  Field,
  input,
  Toggle,
  Toolbar,
  Table,
  Badge,
  Empty,
  useApi,
  Confirm,
} from "@/components/admin/kit";

const CYCLE_PRESETS = [
  { key: "monthly", label: "Monthly", months: 1 },
  { key: "quarterly", label: "Quarterly", months: 3 },
  { key: "semiannual", label: "Semi-Annual", months: 6 },
  { key: "annual", label: "Annual", months: 12 },
  { key: "biennial", label: "Biennial", months: 24 },
  { key: "custom", label: "Custom", months: 1 },
];

const blank = () => ({
  name: "",
  slug: "",
  shortDescription: "",
  description: "",
  categoryId: "",
  icon: "server",
  image: "",
  specs: [{ label: "", value: "" }],
  features: [""],
  locations: [""],
  faqs: [{ q: "", a: "" }],
  setupFee: 0,
  taxRate: 18,
  currency: "INR",
  sortOrder: 0,
  active: true,
  featured: false,
  bestSeller: false,
  archived: false,
  seoTitle: "",
  seoDescription: "",
  tagIds: [],
  cycles: [
    { key: "monthly", label: "Monthly", months: 1, price: 499, compareAt: 599, active: true },
  ],
  billing: {
    orderingEnabled: true,
    billingType: "internal",
    redirectMode: "internal",
    redirectPath: "",
    destinationUrl: "",
    trustedHosts: "",
    urlParams: [{ k: "source", v: "storefront" }],
    openIn: "same",
    buttonText: "Order Now",
  },
});

function rowsToPairs(obj: any) {
  return Object.entries(obj ?? {}).map(([k, v]) => ({ k, v: String(v) }));
}
function pairsToObj(rows: { k: string; v: string }[]) {
  const out: Record<string, string> = {};
  rows.forEach((r) => {
    if (r.k) out[r.k] = r.v;
  });
  return out;
}

export function PlansScreen() {
  const api = useApi();
  const [plans, setPlans] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [tags, setTags] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null);
  const [remove, setRemove] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [billingDefaults, setBillingDefaults] = useState<{ canonicalDomain: string; pathPrefix: string }>({
    canonicalDomain: "",
    pathPrefix: "/order/",
  });

  const load = async () => {
    setLoading(true);
    try {
      const [p, c, t] = await Promise.all([
        api.get("/api/admin/plans"),
        api.get("/api/admin/categories"),
        api.get("/api/admin/tags"),
      ]);
      setPlans(p.rows);
      setCategories(c.rows);
      setTags(t.rows);
      fetch("/api/home")
        .then((r) => r.json())
        .then((d) =>
          setBillingDefaults({
            canonicalDomain: (d?.settings?.billing?.canonicalDomain || "").replace(/\/+$/, ""),
            pathPrefix: d?.settings?.billing?.pathPrefix || "/order/",
          }),
        )
        .catch(() => {});
    } catch {
      /* handled */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return plans.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.slug.includes(q) ||
        (p.categoryName ?? "").toLowerCase().includes(q),
    );
  }, [plans, search]);

  const openNew = () => setEditing({ ...blank(), _new: true });
  const openEdit = (p: any) => {
    setEditing({
      ...blank(),
      ...p,
      tagIds: (p.tags ?? []).map((t: any) => t.id),
      cycles: (p.cycles ?? []).map((c: any) => ({
        key: c.key,
        label: c.label,
        months: c.months,
        price: Number(c.price),
        compareAt: c.compareAt ? Number(c.compareAt) : "",
        active: c.active,
      })),
      billing: {
        orderingEnabled: p.billing?.orderingEnabled ?? true,
        billingType: p.billing?.billingType ?? "internal",
        redirectMode: p.billing?.redirectMode ?? (p.billing?.destinationUrl ? "external" : "internal"),
        redirectPath: p.billing?.redirectPath ?? "",
        destinationUrl: p.billing?.destinationUrl ?? "",
        trustedHosts: p.billing?.trustedHosts ?? "",
        urlParams: rowsToPairs(p.billing?.urlParams),
        openIn: p.billing?.openIn ?? "same",
        buttonText: p.billing?.buttonText ?? "Order Now",
      },
    });
  };

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      const payload = {
        ...editing,
        urlParams: undefined,
        billing: { ...editing.billing, urlParams: pairsToObj(editing.billing.urlParams) },
      };
      if (editing._new) await api.post("/api/admin/plans", payload);
      else await api.put(`/api/admin/plans/${editing.id}`, payload);
      api.toast(editing._new ? "Plan published to the storefront." : "Plan updated — storefront reflects it immediately.");
      setEditing(null);
      load();
    } catch {
      /* toast shown */
    } finally {
      setBusy(false);
    }
  };

  const act = async (fn: () => Promise<any>, msg: string) => {
    try {
      await fn();
      api.toast(msg);
      load();
    } catch {
      /* toast */
    }
  };

  const price = (p: any) => {
    const m = (p.cycles ?? []).find((c: any) => c.key === "monthly") ?? (p.cycles ?? [])[0];
    return m ? Number(m.price) : null;
  };

  return (
    <div>
      <PageHead
        title="Hosting plans"
        subtitle="Create, price, tag and route every plan. Changes publish to the storefront instantly — no rebuild required."
        actions={
          <Btn onClick={openNew}>
            <Plus size={14} /> New plan
          </Btn>
        }
      />

      <Toolbar search={search} onSearch={setSearch} placeholder="Search plans, slugs, categories…">
        <span className="legend text-mute">{filtered.length} / {plans.length} UNITS</span>
      </Toolbar>

      {loading ? (
        <div className="legend text-mute border-line border border-dashed p-12 text-center">LOADING CATALOGUE…</div>
      ) : filtered.length === 0 ? (
        <Empty title="No plans yet" hint="Create your first plan — category, pricing and billing redirect are all configurable." action={<Btn onClick={openNew}><Plus size={14} /> New plan</Btn>} />
      ) : (
        <Table head={["PLAN", "CATEGORY", "PRICE /mo", "CYCLES", "TAGS", "STATUS", "ACTIONS"]}>
          {filtered.map((p) => (
            <tr key={p.id} className="border-line hover:bg-raised/50 border-b last:border-0">
              <td className="px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className={`led h-1.5 w-1.5 rounded-full ${p.active && !p.archived ? "bg-led text-led" : "bg-line-2"}`} />
                  <div>
                    <div className="text-chalk text-[13.5px] font-medium">{p.name}</div>
                    <div className="num text-mute text-[11px]">/{p.slug}</div>
                  </div>
                </div>
              </td>
              <td className="text-fore px-4 py-3 text-[13px]">{p.categoryName ?? "—"}</td>
              <td className="num text-fore px-4 py-3 text-[13px]">
                {price(p) != null ? `₹${price(p)!.toLocaleString("en-IN")}` : "—"}
              </td>
              <td className="num text-mute px-4 py-3 text-[12px]">{(p.cycles ?? []).length}</td>
              <td className="px-4 py-3">
                <div className="flex flex-wrap gap-1">
                  {(p.tags ?? []).slice(0, 3).map((t: any) => (
                    <span key={t.id} className="legend border px-1.5 py-0.5" style={{ color: t.color, borderColor: `${t.color}44` }}>
                      {t.name}
                    </span>
                  ))}
                </div>
              </td>
              <td className="px-4 py-3">
                <div className="flex flex-wrap gap-1">
                  {p.archived ? <Badge tone="mute">ARCHIVED</Badge> : p.active ? <Badge tone="ok">LIVE</Badge> : <Badge tone="warn">HIDDEN</Badge>}
                  {p.featured && <Badge tone="info">FEATURED</Badge>}
                  {p.bestSeller && <Badge tone="warn">BEST SELLER</Badge>}
                </div>
              </td>
              <td className="px-4 py-3">
                <div className="flex items-center gap-1.5">
                  <button onClick={() => openEdit(p)} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Edit">
                    <Pencil size={13} />
                  </button>
                  <button
                    onClick={() => act(() => api.post("/api/admin/actions", { action: "duplicate_plan", id: p.id }), "Plan duplicated (created inactive).")}
                    className="border-line text-mute hover:text-link hover:border-link/40 border p-1.5"
                    aria-label="Duplicate"
                  >
                    <Copy size={13} />
                  </button>
                  <button
                    onClick={() =>
                      act(
                        () => api.post("/api/admin/actions", { action: "toggle", table: "products", id: p.id, scope: "catalog" }),
                        "Visibility toggled.",
                      )
                    }
                    className="border-line text-mute hover:text-led hover:border-led/40 border p-1.5"
                    aria-label="Toggle active"
                  >
                    {p.active ? <Eye size={13} /> : <EyeOff size={13} />}
                  </button>
                  <a
                    href={`/plans/${p.slug}`}
                    target="_blank"
                    className="border-line text-mute hover:text-fore border p-1.5"
                    aria-label="View on site"
                  >
                    <ExternalLink size={13} />
                  </a>
                  <button onClick={() => setRemove(p)} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Delete">
                    <Trash2 size={13} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </Table>
      )}

      <Confirm
        open={Boolean(remove)}
        onClose={() => setRemove(null)}
        busy={busy}
        title="Delete plan"
        body={`Delete "${remove?.name}" permanently? Its billing cycles and redirect configuration are removed with it. Orders keep their own snapshot of the name and price.`}
        onConfirm={async () => {
          const target = remove;
          if (!target) return;
          setBusy(true);
          try {
            await api.del(`/api/admin/plans/${target.id}`);
            api.toast("Plan deleted.");
            setRemove(null);
            load();
          } catch {
            /* toast */
          } finally {
            setBusy(false);
          }
        }}
      />

      <PlanEditor
        state={editing}
        setState={setEditing}
        categories={categories}
        tags={tags}
        onSave={save}
        busy={busy}
        billingDefaults={billingDefaults}
      />
    </div>
  );
}

/* --------------------------------- editor --------------------------------- */
function PlanEditor({ state, setState, categories, tags, onSave, busy, billingDefaults }: any) {
  const set = (patch: any) => setState((s: any) => ({ ...s, ...patch }));
  const setBilling = (patch: any) => setState((s: any) => ({ ...s, billing: { ...s.billing, ...patch } }));
  const [tab, setTab] = useState("general");
  if (!state) return null;

  const tabs = [
    ["general", "General"],
    ["pricing", "Pricing & cycles"],
    ["specs", "Specs & features"],
    ["tags", "Tags"],
    ["billing", "Billing redirect"],
    ["seo", "SEO"],
  ];

  const listEditor = <T,>(key: string, placeholder: string, make: () => T) =>
    (state[key] as T[]).map((item, i) => (
      <div key={i} className="flex gap-2">
        <input
          value={typeof item === "string" ? (item as any) : (item as any).label ?? (item as any).q ?? ""}
          onChange={(e) => {
            const next = [...state[key]];
            if (typeof item === "string") next[i] = e.target.value as any;
            else if ("label" in (item as any)) next[i] = { ...(item as any), label: e.target.value } as any;
            else next[i] = { ...(item as any), q: e.target.value } as any;
            set({ [key]: next });
          }}
          placeholder={placeholder}
          className={input}
        />
        {typeof item !== "string" && "value" in (item as any) && (
          <input
            value={(item as any).value}
            onChange={(e) => {
              const next = [...state[key]];
              next[i] = { ...(item as any), value: e.target.value } as any;
              set({ [key]: next });
            }}
            placeholder="Value"
            className={input}
          />
        )}
        {typeof item !== "string" && "a" in (item as any) && (
          <input
            value={(item as any).a}
            onChange={(e) => {
              const next = [...state[key]];
              next[i] = { ...(item as any), a: e.target.value } as any;
              set({ [key]: next });
            }}
            placeholder="Answer"
            className={input}
          />
        )}
        <button
          onClick={() => set({ [key]: state[key].filter((_: any, j: number) => j !== i) })}
          className="text-mute hover:text-signal border-line border px-3"
          aria-label="Remove row"
        >
          <X size={13} />
        </button>
      </div>
    ));

  return (
    <Modal
      open={Boolean(state)}
      onClose={() => setState(null)}
      wide
      title={state._new ? "Create hosting plan" : `Edit — ${state.name || "plan"}`}
      footer={
        <>
          <Btn variant="ghost" onClick={() => setState(null)}>
            Cancel
          </Btn>
          <Btn onClick={onSave} disabled={busy}>
            <Save size={13} /> {busy ? "SAVING…" : state._new ? "Publish plan" : "Save changes"}
          </Btn>
        </>
      }
    >
      <div className="mb-5 flex flex-wrap gap-1.5 border-b border-line pb-4">
        {tabs.map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`legend border px-3 py-2 transition-all ${
              tab === key ? "border-signal/70 bg-signal/10 text-signal" : "border-line text-mute hover:border-line-2"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "general" && (
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="PLAN NAME" required>
            <input value={state.name} onChange={(e) => set({ name: e.target.value, slug: state._new || !state.slug ? e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") : state.slug })} className={input} placeholder="Minecraft Java Pro" />
          </Field>
          <Field label="SLUG" required hint="USED IN THE PUBLIC URL /plans/…">
            <input value={state.slug} onChange={(e) => set({ slug: e.target.value })} className={`${input} font-mono`} />
          </Field>
          <Field label="CATEGORY">
            <select value={state.categoryId ?? ""} onChange={(e) => set({ categoryId: e.target.value })} className={input}>
              <option value="">— unassigned —</option>
              {categories.map((c: any) => (
                <option key={c.id} value={c.id}>
                  {c.parentId ? "↳ " : ""}
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="ICON (LUCIDE NAME)">
            <input value={state.icon ?? ""} onChange={(e) => set({ icon: e.target.value })} className={input} placeholder="server" />
          </Field>
          <div className="md:col-span-2">
            <Field label="SHORT DESCRIPTION">
              <input value={state.shortDescription ?? ""} onChange={(e) => set({ shortDescription: e.target.value })} className={input} maxLength={320} />
            </Field>
          </div>
          <div className="md:col-span-2">
            <Field label="FULL DESCRIPTION">
              <textarea value={state.description ?? ""} onChange={(e) => set({ description: e.target.value })} rows={6} className={input} />
            </Field>
          </div>
          <Field label="IMAGE PATH OR URL">
            <input value={state.image ?? ""} onChange={(e) => set({ image: e.target.value })} className={input} placeholder="/images/rack-macro.jpg" />
          </Field>
          <Field label="DISPLAY ORDER">
            <input type="number" value={state.sortOrder} onChange={(e) => set({ sortOrder: Number(e.target.value) })} className={input} />
          </Field>
          <div className="md:col-span-2 flex flex-wrap gap-6 border-line border-t pt-4">
            <Toggle checked={state.active} onChange={(v) => set({ active: v })} label="Active on storefront" />
            <Toggle checked={state.featured} onChange={(v) => set({ featured: v })} label="Featured" />
            <Toggle checked={state.bestSeller} onChange={(v) => set({ bestSeller: v })} label="Best seller" />
            <Toggle checked={state.archived} onChange={(v) => set({ archived: v })} label="Archived" />
          </div>
        </div>
      )}

      {tab === "pricing" && (
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-3">
            <Field label="CURRENCY">
              <select value={state.currency} onChange={(e) => set({ currency: e.target.value })} className={input}>
                {["INR", "USD", "EUR", "GBP", "AED"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </Field>
            <Field label="SETUP FEE">
              <input type="number" value={state.setupFee} onChange={(e) => set({ setupFee: e.target.value })} className={input} />
            </Field>
            <Field label="TAX RATE %">
              <input type="number" value={state.taxRate} onChange={(e) => set({ taxRate: e.target.value })} className={input} />
            </Field>
          </div>

          <div>
            <div className="legend text-signal mb-2">BILLING CYCLES</div>
            <div className="flex flex-col gap-2">
              {state.cycles.map((c: any, i: number) => (
                <div key={i} className="border-line bg-raised/50 grid grid-cols-2 gap-2 border p-3 md:grid-cols-7">
                  <select
                    value={c.key}
                    onChange={(e) => {
                      const preset = CYCLE_PRESETS.find((p) => p.key === e.target.value)!;
                      const next = [...state.cycles];
                      next[i] = { ...c, key: preset.key, label: preset.label, months: preset.months };
                      set({ cycles: next });
                    }}
                    className={`${input} md:col-span-2`}
                  >
                    {CYCLE_PRESETS.map((p) => (
                      <option key={p.key} value={p.key}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                  <input
                    value={c.label}
                    onChange={(e) => {
                      const next = [...state.cycles];
                      next[i] = { ...c, label: e.target.value };
                      set({ cycles: next });
                    }}
                    className={input}
                    placeholder="Label"
                  />
                  <input
                    type="number"
                    value={c.months}
                    onChange={(e) => {
                      const next = [...state.cycles];
                      next[i] = { ...c, months: Number(e.target.value) };
                      set({ cycles: next });
                    }}
                    className={input}
                    placeholder="Months"
                  />
                  <input
                    type="number"
                    value={c.price}
                    onChange={(e) => {
                      const next = [...state.cycles];
                      next[i] = { ...c, price: e.target.value };
                      set({ cycles: next });
                    }}
                    className={input}
                    placeholder="Price"
                  />
                  <input
                    type="number"
                    value={c.compareAt}
                    onChange={(e) => {
                      const next = [...state.cycles];
                      next[i] = { ...c, compareAt: e.target.value };
                      set({ cycles: next });
                    }}
                    className={input}
                    placeholder="Compare at"
                  />
                  <div className="flex items-center justify-between gap-2">
                    <Toggle
                      checked={c.active}
                      onChange={(v) => {
                        const next = [...state.cycles];
                        next[i] = { ...c, active: v };
                        set({ cycles: next });
                      }}
                    />
                    <button
                      onClick={() => set({ cycles: state.cycles.filter((_: any, j: number) => j !== i) })}
                      className="text-mute hover:text-signal"
                      aria-label="Remove cycle"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <Btn
              variant="ghost"
              className="mt-3"
              onClick={() =>
                set({
                  cycles: [...state.cycles, { key: "custom", label: "Custom", months: 2, price: 999, compareAt: "", active: true }],
                })
              }
            >
              <Plus size={13} /> Add billing cycle
            </Btn>
            <p className="legend text-mute mt-3">PRICES ARE RECOMPUTED SERVER-SIDE FOR EVERY ORDER — NEVER TRUSTED FROM THE BROWSER.</p>
          </div>
        </div>
      )}

      {tab === "specs" && (
        <div className="flex flex-col gap-6">
          <div>
            <div className="legend text-signal mb-2">SPECIFICATIONS (UNLIMITED)</div>
            <div className="flex flex-col gap-2">{listEditor("specs", "Label", () => ({ label: "", value: "" }))}</div>
            <Btn variant="ghost" className="mt-3" onClick={() => set({ specs: [...state.specs, { label: "", value: "" }] })}>
              <Plus size={13} /> Add specification
            </Btn>
          </div>
          <div>
            <div className="legend text-signal mb-2">FEATURE LIST</div>
            <div className="flex flex-col gap-2">{listEditor("features", "Feature", () => "")}</div>
            <Btn variant="ghost" className="mt-3" onClick={() => set({ features: [...state.features, ""] })}>
              <Plus size={13} /> Add feature
            </Btn>
          </div>
          <div>
            <div className="legend text-signal mb-2">SERVER LOCATIONS</div>
            <div className="flex flex-col gap-2">{listEditor("locations", "City", () => "")}</div>
            <Btn variant="ghost" className="mt-3" onClick={() => set({ locations: [...state.locations, ""] })}>
              <Plus size={13} /> Add location
            </Btn>
          </div>
          <div>
            <div className="legend text-signal mb-2">PLAN FAQ</div>
            <div className="flex flex-col gap-2">{listEditor("faqs", "Question", () => ({ q: "", a: "" }))}</div>
            <Btn variant="ghost" className="mt-3" onClick={() => set({ faqs: [...state.faqs, { q: "", a: "" }] })}>
              <Plus size={13} /> Add question
            </Btn>
          </div>
        </div>
      )}

      {tab === "tags" && (
        <div>
          <div className="legend text-signal mb-3">ASSIGN TAGS</div>
          <div className="flex flex-wrap gap-2">
            {tags.map((t: any) => {
              const on = state.tagIds.includes(t.id);
              return (
                <button
                  key={t.id}
                  onClick={() =>
                    set({ tagIds: on ? state.tagIds.filter((x: string) => x !== t.id) : [...state.tagIds, t.id] })
                  }
                  className="legend border px-3 py-2 transition-all"
                  style={{
                    color: on ? t.color : "#8A94A8",
                    borderColor: on ? `${t.color}88` : "#1E2636",
                    background: on ? `${t.color}16` : "transparent",
                  }}
                >
                  {on ? "✓ " : ""}
                  {t.name}
                </button>
              );
            })}
            {tags.length === 0 && <p className="text-mute text-[13px]">No tags created yet.</p>}
          </div>
        </div>
      )}

      {tab === "billing" && (
        <div className="grid gap-4 md:grid-cols-2">
          <div className="md:col-span-2 flex flex-wrap items-center justify-between gap-4 border-line border-b pb-4">
            <Toggle checked={state.billing.orderingEnabled} onChange={(v) => setBilling({ orderingEnabled: v })} label="Ordering enabled" />
            <span className="legend text-mute">
              CANONICAL DOMAIN: {billingDefaults.canonicalDomain || "CURRENT ORIGIN"} · PREFIX {billingDefaults.pathPrefix}
            </span>
          </div>

          <div className="md:col-span-2">
            <span className="legend text-mute mb-2 block">REDIRECT TARGET</span>
            <div className="flex flex-wrap gap-2">
              {[
                ["internal", "Internal path on this site"],
                ["external", "External billing URL"],
                ["manual", "Manual order flow"],
              ].map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setBilling({ redirectMode: key })}
                  className={`legend border px-3.5 py-2.5 transition-all ${
                    state.billing.redirectMode === key
                      ? "border-signal/70 bg-signal/10 text-signal"
                      : "border-line text-mute hover:border-line-2 hover:text-fore"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {state.billing.redirectMode === "internal" && (
            <>
              <div className="md:col-span-2">
                <Field
                  label="PLAN REDIRECT PATH (UNIQUE PER PLAN)"
                  required
                  hint={`RELATIVE PATH ONLY — AUTO-GENERATED AS ${billingDefaults.pathPrefix}<slug> WHEN EMPTY. TRAVERSAL, SCHEMES AND DUPLICATES ARE REJECTED.`}
                >
                  <div className="flex flex-wrap gap-2">
                    <input
                      value={state.billing.redirectPath}
                      onChange={(e) => setBilling({ redirectPath: e.target.value })}
                      className={`${input} font-mono flex-1`}
                      placeholder={`${billingDefaults.pathPrefix}${state.slug || "plan-slug"}`}
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setBilling({
                          redirectPath: `${billingDefaults.pathPrefix}${(state.slug || "").toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "")}`,
                        })
                      }
                      className="border-line text-fore hover:border-signal/50 hover:text-signal border px-3 text-[12px] transition-all"
                    >
                      Generate from slug
                    </button>
                    {state.billing.redirectPath && (
                      <button
                        type="button"
                        onClick={() => setBilling({ redirectPath: "" })}
                        className="border-line text-mute hover:text-signal border px-3 text-[12px] transition-all"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                </Field>
              </div>
              <div className="md:col-span-2 border-line bg-raised/50 border p-4">
                <div className="legend text-mute mb-2">FINAL REDIRECT DESTINATION</div>
                <code className="text-signal-2 block text-[12.5px] break-all">
                  {billingDefaults.canonicalDomain || "(origin)"}
                  {state.billing.redirectPath || `${billingDefaults.pathPrefix}${state.slug || "plan-slug"}`}
                  ?billing_cycle=monthly&amp;plan_slug={state.slug || "plan-slug"}
                </code>
                <p className="legend text-mute mt-2">
                  CHANGING THE CANONICAL DOMAIN UPDATES EVERY INTERNAL PLAN DESTINATION — NO PER-PLAN EDITS REQUIRED.
                </p>
              </div>
            </>
          )}

          {(state.billing.redirectMode === "external" || state.billing.billingType === "external") &&
            state.billing.redirectMode === "external" && (
              <>
                <div className="md:col-span-2">
                  <Field label="EXTERNAL BILLING DESTINATION URL" required hint="MUST BE HTTP(S) ON A TRUSTED HOST — ADD THE HOST BELOW BEFORE SAVING. EXTERNAL TARGETS ARE PRESERVED WHEN THE CANONICAL DOMAIN CHANGES.">
                    <input
                      value={state.billing.destinationUrl}
                      onChange={(e) => setBilling({ destinationUrl: e.target.value })}
                      className={`${input} font-mono`}
                      placeholder="https://billing.example.com/order/plan-slug"
                    />
                  </Field>
                </div>
                <Field label="TRUSTED HOSTS (COMMA SEPARATED)" hint="REGISTRY-STYLE SUFFIX MATCHING IS SUPPORTED">
                  <input value={state.billing.trustedHosts} onChange={(e) => setBilling({ trustedHosts: e.target.value })} className={`${input} font-mono`} placeholder="billing.example.com" />
                </Field>
              </>
            )}

          {state.billing.redirectMode === "manual" && (
            <div className="md:col-span-2 border-line bg-raised/50 border p-4">
              <p className="text-fore text-[13.5px]">
                No automatic redirect. The order is created and the customer is sent to the support flow; an engineer
                completes provisioning manually.
              </p>
            </div>
          )}

          <Field label="REDIRECT BEHAVIOUR">
            <select value={state.billing.openIn} onChange={(e) => setBilling({ openIn: e.target.value })} className={input}>
              <option value="same">Same tab</option>
              <option value="new">New tab</option>
            </select>
          </Field>
          <Field label="BUTTON TEXT">
            <input value={state.billing.buttonText} onChange={(e) => setBilling({ buttonText: e.target.value })} className={input} />
          </Field>

          <div className="md:col-span-2">
            <div className="legend text-signal mb-2">URL PARAMETERS APPENDED TO THE REDIRECT</div>
            <div className="flex flex-col gap-2">
              {state.billing.urlParams.map((row: any, i: number) => (
                <div key={i} className="flex gap-2">
                  <input
                    value={row.k}
                    onChange={(e) => {
                      const next = [...state.billing.urlParams];
                      next[i] = { ...row, k: e.target.value };
                      setBilling({ urlParams: next });
                    }}
                    placeholder="param"
                    className={`${input} font-mono`}
                  />
                  <input
                    value={row.v}
                    onChange={(e) => {
                      const next = [...state.billing.urlParams];
                      next[i] = { ...row, v: e.target.value };
                      setBilling({ urlParams: next });
                    }}
                    placeholder="value"
                    className={`${input} font-mono`}
                  />
                  <button
                    onClick={() => setBilling({ urlParams: state.billing.urlParams.filter((_: any, j: number) => j !== i) })}
                    className="text-mute hover:text-signal border-line border px-3"
                    aria-label="Remove parameter"
                  >
                    <X size={13} />
                  </button>
                </div>
              ))}
            </div>
            <Btn variant="ghost" className="mt-3" onClick={() => setBilling({ urlParams: [...state.billing.urlParams, { k: "", v: "" }] })}>
              <Plus size={13} /> Add parameter
            </Btn>
            <p className="legend text-mute mt-3">PLAN_ID, PLAN_SLUG, BILLING_CYCLE, LOCATION AND COUPON ARE ALWAYS APPENDED AUTOMATICALLY.</p>
          </div>
        </div>
      )}

      {tab === "seo" && (
        <div className="grid gap-4">
          <Field label="SEO TITLE">
            <input value={state.seoTitle ?? ""} onChange={(e) => set({ seoTitle: e.target.value })} className={input} maxLength={190} />
          </Field>
          <Field label="SEO DESCRIPTION">
            <textarea value={state.seoDescription ?? ""} onChange={(e) => set({ seoDescription: e.target.value })} rows={3} className={input} maxLength={320} />
          </Field>
        </div>
      )}
    </Modal>
  );
}
