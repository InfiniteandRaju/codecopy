"use client";

import { useEffect, useState } from "react";
import { Save, Upload, ExternalLink } from "lucide-react";
import { PageHead, Btn, Field, input, Toggle, useApi, Badge, Toolbar } from "@/components/admin/kit";
import { BrandingTab, ConsoleIntegrationTab, DatabaseTab } from "@/components/admin/SettingsExtras";

const PRESETS = [
  { name: "Signal amber", primary: "#FF6B18", accent: "#39D7E6" },
  { name: "Deep violet", primary: "#8B5CF6", accent: "#22D3EE" },
  { name: "Cobalt", primary: "#3B82F6", accent: "#34D399" },
  { name: "Ember red", primary: "#F43F5E", accent: "#FBBF24" },
  { name: "Emerald", primary: "#10B981", accent: "#60A5FA" },
];

const TABS = [
  ["general", "General"],
  ["theme", "Branding & theme"],
  ["seo", "SEO"],
  ["social", "Social & footer"],
  ["branding", "Branding & logo"],
  ["payments", "Payment methods"],
  ["console", "Console integration"],
  ["database", "Database"],
] as const;

export function SettingsScreen() {
  const api = useApi();
  const [settings, setSettings] = useState<any>(null);
  const [methods, setMethods] = useState<any[]>([]);
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("general");
  const [busy, setBusy] = useState(false);
  const [role, setRole] = useState<string>("");

  const load = async () => {
    try {
      const [home, m] = await Promise.all([api.get("/api/home"), api.get("/api/admin/payment-methods")]);
      setSettings((prev: any) => ({ ...(prev ?? {}), ...home.settings, seo: home.settings.seo, footer: home.settings.footer }));
      setMethods(m.rows);
      fetch("/api/auth/me")
        .then((r) => r.json())
        .then((d) => setRole(d?.user?.role ?? ""))
        .catch(() => {});
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!settings) return <div className="legend text-mute py-20 text-center">LOADING SETTINGS…</div>;

  const set = (patch: any) => setSettings((s: any) => ({ ...s, ...patch }));

  const saveGroup = async (key: string, value: any, label: string) => {
    setBusy(true);
    try {
      await api.put(`/api/admin/settings/${key}`, { key, value });
      api.toast(`${label} saved.`);
      if (key === "theme") {
        document.documentElement.style.setProperty("--color-signal", value.primary);
        document.documentElement.style.setProperty("--color-link", value.accent);
      }
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const saveMethod = async (m: any) => {
    setBusy(true);
    try {
      await api.put(`/api/admin/payment-methods/${m.id}`, { name: m.name, enabled: m.enabled, config: m.config });
      api.toast(`${m.name} updated.`);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const setMethod = (id: string, patch: any) =>
    setMethods((list) => list.map((m) => (m.id === id ? { ...m, ...patch, config: { ...m.config, ...(patch.config ?? {}) } } : m)));

  const SaveBar = ({ onSave, hint }: { onSave: () => void; hint?: string }) => (
    <div className="border-line mt-5 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
      <span className="legend text-mute">{hint ?? "CHANGES APPLY IMMEDIATELY — NO REBUILD"}</span>
      <Btn onClick={onSave} disabled={busy}>
        <Save size={13} /> {busy ? "SAVING…" : "Save changes"}
      </Btn>
    </div>
  );

  return (
    <div>
      <PageHead
        title="Settings"
        subtitle="Identity, branding, SEO, compliance text and every payment integration. Secrets are stored server-side and never rendered back to the browser."
        actions={
          <a href="/admin/plans" className="legend border-line text-fore hover:border-signal/50 hover:text-signal border px-4 py-2.5">
            BILLING REDIRECTS LIVE ON EACH PLAN <ExternalLink size={12} className="ml-1 inline" />
          </a>
        }
      />

      <div className="mb-5 flex flex-wrap gap-1.5">
        {TABS.map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`legend border px-3.5 py-2 transition-all ${
              tab === key ? "border-signal/70 bg-signal/10 text-signal" : "border-line text-mute hover:border-line-2"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "general" && (
        <section className="panel p-5">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="SITE NAME" required><input value={settings.siteName ?? ""} onChange={(e) => set({ siteName: e.target.value })} className={input} /></Field>
            <Field label="TAGLINE"><input value={settings.tagline ?? ""} onChange={(e) => set({ tagline: e.target.value })} className={input} /></Field>
            <Field label="CONTACT EMAIL"><input value={settings.contactEmail ?? ""} onChange={(e) => set({ contactEmail: e.target.value })} className={input} /></Field>
            <Field label="SUPPORT DISCORD"><input value={settings.supportDiscord ?? ""} onChange={(e) => set({ supportDiscord: e.target.value })} className={input} /></Field>
            <Field label="CURRENCY CODE"><input value={settings.currency ?? ""} onChange={(e) => set({ currency: e.target.value })} className={input} /></Field>
            <Field label="CURRENCY SYMBOL"><input value={settings.currencySymbol ?? ""} onChange={(e) => set({ currencySymbol: e.target.value })} className={input} /></Field>
            <Field label="TAX LABEL"><input value={settings.taxLabel ?? ""} onChange={(e) => set({ taxLabel: e.target.value })} className={input} placeholder="GST" /></Field>
            <Field label="DEFAULT TAX RATE %"><input type="number" value={settings.taxRate ?? 0} onChange={(e) => set({ taxRate: Number(e.target.value) })} className={input} /></Field>
            <div className="md:col-span-2 border-line border-t pt-4">
              <Toggle checked={Boolean(settings.maintenanceMode)} onChange={(v) => set({ maintenanceMode: v })} label="Maintenance mode — pauses new checkout orders" />
            </div>
            <div className="md:col-span-2">
              <Field label="MAINTENANCE MESSAGE"><textarea rows={2} value={settings.maintenanceMessage ?? ""} onChange={(e) => set({ maintenanceMessage: e.target.value })} className={input} /></Field>
            </div>
            <div className="md:col-span-2 grid gap-4 md:grid-cols-2">
              <Field label="CANONICAL WEBSITE DOMAIN" hint="HTTPS://EXAMPLE.COM — EVERY INTERNAL PLAN PATH RESOLVES AGAINST THIS DOMAIN">
                <input
                  value={settings.billing?.canonicalDomain ?? ""}
                  onChange={(e) => set({ billing: { ...(settings.billing ?? {}), canonicalDomain: e.target.value } })}
                  className={`${input} font-mono`}
                  placeholder="https://example.com"
                />
              </Field>
              <Field label="DEFAULT PLAN PATH PREFIX" hint="AUTO-GENERATED ORDER PATH FOR NEW PLANS, E.G. /ORDER/">
                <input
                  value={settings.billing?.pathPrefix ?? "/order/"}
                  onChange={(e) => set({ billing: { ...(settings.billing ?? {}), pathPrefix: e.target.value } })}
                  className={`${input} font-mono`}
                  placeholder="/order/"
                />
              </Field>
            </div>
            <div className="md:col-span-2">
              <Field label="TRUSTED BILLING HOSTS (COMMA SEPARATED)" hint="ONLY THESE HOSTS MAY BE USED AS EXTERNAL BILLING REDIRECT TARGETS — APPLIES TO EVERY PLAN"><input value={settings.billing?.trustedHosts ?? ""} onChange={(e) => set({ billing: { ...(settings.billing ?? {}), trustedHosts: e.target.value } })} className={`${input} font-mono`} placeholder="billing.example.com" /></Field>
            </div>
          </div>
          <SaveBar
            onSave={() =>
              saveGroup("general", {
                siteName: settings.siteName,
                tagline: settings.tagline,
                contactEmail: settings.contactEmail,
                supportDiscord: settings.supportDiscord,
                currency: settings.currency,
                currencySymbol: settings.currencySymbol,
                taxLabel: settings.taxLabel,
                taxRate: settings.taxRate,
                maintenanceMode: settings.maintenanceMode,
                maintenanceMessage: settings.maintenanceMessage,
              }, "General settings")
            }
          />
          <div className="mt-3">
            <Btn variant="ghost" onClick={() => saveGroup("billing", settings.billing ?? {}, "Billing & redirects")}>
              Save billing & redirect settings
            </Btn>
          </div>
        </section>
      )}

      {tab === "theme" && (
        <section className="panel p-5">
          <div className="mb-4 flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <button
                key={p.name}
                onClick={() => set({ theme: { ...(settings.theme ?? {}), primary: p.primary, accent: p.accent } })}
                className="legend border-line hover:border-line-2 flex items-center gap-2 border px-3 py-2 transition-all"
              >
                <span className="h-3 w-3" style={{ background: p.primary }} />
                <span className="h-3 w-3" style={{ background: p.accent }} />
                {p.name}
              </button>
            ))}
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              ["primary", "PRIMARY COLOUR"],
              ["accent", "ACCENT COLOUR"],
              ["surface", "SURFACE COLOUR"],
            ].map(([key, label]) => (
              <Field key={key} label={label}>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={settings.theme?.[key] ?? "#FF6B18"}
                    onChange={(e) => set({ theme: { ...(settings.theme ?? {}), [key]: e.target.value } })}
                    className="border-line h-[42px] w-14 border bg-raised"
                    aria-label={label}
                  />
                  <input
                    value={settings.theme?.[key] ?? ""}
                    onChange={(e) => set({ theme: { ...(settings.theme ?? {}), [key]: e.target.value } })}
                    className={`${input} font-mono`}
                  />
                </div>
              </Field>
            ))}
          </div>
          <div className="border-line bg-raised/50 mt-5 flex items-center gap-4 border p-4">
            <span className="legend text-mute">LIVE PREVIEW</span>
            <span className="bg-signal text-void legend px-4 py-2">PRIMARY ACTION</span>
            <span className="border-link text-link legend border px-4 py-2">ACCENT</span>
          </div>
          <SaveBar onSave={() => saveGroup("theme", settings.theme ?? {}, "Branding")} hint="APPLIED LIVE TO THE STOREFRONT AND THIS CONSOLE" />
        </section>
      )}

      {tab === "seo" && (
        <section className="panel p-5">
          <div className="grid gap-4">
            <Field label="DEFAULT PAGE TITLE"><input value={settings.seo?.title ?? ""} onChange={(e) => set({ seo: { ...settings.seo, title: e.target.value } })} className={input} /></Field>
            <Field label="DEFAULT META DESCRIPTION"><textarea rows={3} value={settings.seo?.description ?? ""} onChange={(e) => set({ seo: { ...settings.seo, description: e.target.value } })} className={input} /></Field>
            <Field label="OPEN GRAPH IMAGE"><input value={settings.seo?.ogImage ?? ""} onChange={(e) => set({ seo: { ...settings.seo, ogImage: e.target.value } })} className={input} /></Field>
          </div>
          <div className="border-line bg-raised/50 mt-4 border p-4">
            <div className="legend text-mute mb-2">SEARCH PREVIEW</div>
            <div className="text-link text-[15px]">{settings.seo?.title}</div>
            <div className="text-mute mt-1 text-[13px] line-clamp-2">{settings.seo?.description}</div>
          </div>
          <SaveBar onSave={() => saveGroup("seo", settings.seo ?? {}, "SEO")} />
        </section>
      )}

      {tab === "social" && (
        <section className="panel p-5">
          <div className="grid gap-4 md:grid-cols-2">
            {["twitter", "github", "discord", "youtube"].map((k) => (
              <Field key={k} label={`${k.toUpperCase()} URL`}>
                <input value={settings.social?.[k] ?? ""} onChange={(e) => set({ social: { ...settings.social, [k]: e.target.value } })} className={input} />
              </Field>
            ))}
            <div className="md:col-span-2">
              <Field label="FOOTER BLURB"><textarea rows={3} value={settings.footer?.blurb ?? ""} onChange={(e) => set({ footer: { ...settings.footer, blurb: e.target.value } })} className={input} /></Field>
            </div>
            <div className="md:col-span-2">
              <Field label="FOOTER LEGAL LINE"><input value={settings.footer?.legal ?? ""} onChange={(e) => set({ footer: { ...settings.footer, legal: e.target.value } })} className={input} /></Field>
            </div>
          </div>
          <SaveBar onSave={() => saveGroup("footer", settings.footer ?? {}, "Footer")} hint="THE WHOLE SET IS PERSISTED UNDER THE 'footer' KEY" />
          <div className="mt-3">
            <Btn variant="ghost" onClick={() => saveGroup("social", settings.social ?? {}, "Social links")}>
              Save social links
            </Btn>
          </div>
        </section>
      )}

      {tab === "branding" && <BrandingTab />}

      {tab === "console" &&
        (["super_admin", "finance_manager", "support"].includes(role) ? (
          <ConsoleIntegrationTab />
        ) : (
          <div className="border-line bg-raised/50 border p-5 text-[13.5px] text-mute">
            Console integration is restricted to roles with operations access.
          </div>
        ))}

      {tab === "database" && <DatabaseTab isSuperAdmin={role === "super_admin"} />}

      {tab === "payments" && (
        <div className="flex flex-col gap-5">
          <div className="border-signal/30 bg-signal/8 border px-4 py-3">
            <p className="text-fore text-[13px]">
              Keys and secrets are held in the database and used only inside server routes. Blank secret fields mean
              “keep the stored value”. Integrations without credentials are clearly marked and never pretend to work.
            </p>
          </div>

          {methods.map((m) => (
            <section key={m.id} className="panel p-5">
              <div className="border-line mb-4 flex flex-wrap items-center justify-between gap-3 border-b pb-4">
                <div className="flex items-center gap-3">
                  <h3 className="text-[15.5px] font-semibold">{m.name}</h3>
                  <Badge tone={m.enabled ? "ok" : "mute"}>{m.enabled ? "ENABLED" : "DISABLED"}</Badge>
                  {["razorpay", "crypto"].includes(m.key) && (
                    <Badge tone={m.config?.configured === false ? "warn" : "info"}>
                      {m.config?.configured === false ? "AWAITING CREDENTIALS" : "CONFIGURED"}
                    </Badge>
                  )}
                </div>
                <Toggle checked={m.enabled} onChange={(v) => setMethod(m.id, { enabled: v })} label="Enabled" />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                {m.key === "razorpay" && (
                  <>
                    <Field label="KEY ID"><input value={m.config?.keyId ?? ""} onChange={(e) => setMethod(m.id, { config: { keyId: e.target.value } })} className={input} placeholder="rzp_live_…" /></Field>
                    <Field label="KEY SECRET" hint="STORED SERVER-SIDE · LEAVE BLANK TO KEEP CURRENT"><input type="password" value="" onChange={(e) => setMethod(m.id, { config: { keySecret: e.target.value } })} className={input} placeholder="••••••••••••" /></Field>
                    <Field label="WEBHOOK SECRET"><input type="password" value="" onChange={(e) => setMethod(m.id, { config: { webhookSecret: e.target.value } })} className={input} placeholder="••••••••••••" /></Field>
                    <Field label="MODE">
                      <select value={m.config?.mode ?? "test"} onChange={(e) => setMethod(m.id, { config: { mode: e.target.value } })} className={input}>
                        <option value="test">Test</option>
                        <option value="live">Live</option>
                      </select>
                    </Field>
                  </>
                )}

                {m.key === "crypto" && (
                  <>
                    <Field label="PROVIDER">
                      <select value={m.config?.provider ?? "nowpayments"} onChange={(e) => setMethod(m.id, { config: { provider: e.target.value } })} className={input}>
                        <option value="nowpayments">NOWPayments</option>
                        <option value="coinpayments">CoinPayments</option>
                      </select>
                    </Field>
                    <Field label="API KEY" hint="SERVER-SIDE ONLY · LEAVE BLANK TO KEEP CURRENT"><input type="password" value="" onChange={(e) => setMethod(m.id, { config: { apiKey: e.target.value } })} className={input} placeholder="••••••••" /></Field>
                    <Field label="IPN / WEBHOOK SECRET"><input type="password" value="" onChange={(e) => setMethod(m.id, { config: { ipnSecret: e.target.value } })} className={input} placeholder="••••••••" /></Field>
                    <Field label="ACCEPTED COINS (COMMA SEPARATED)"><input value={(m.config?.coins ?? []).join(", ")} onChange={(e) => setMethod(m.id, { config: { coins: e.target.value.split(",").map((s: string) => s.trim()).filter(Boolean) } })} className={input} placeholder="BTC, ETH, USDT-TRC20" /></Field>
                  </>
                )}

                {m.key === "qr" && (
                  <>
                    <Field label="UPI / PAYEE ID"><input value={m.config?.upiId ?? ""} onChange={(e) => setMethod(m.id, { config: { upiId: e.target.value } })} className={input} /></Field>
                    <div className="md:col-span-2">
                      <Field label="PAYMENT INSTRUCTIONS"><textarea rows={2} value={m.config?.instructions ?? ""} onChange={(e) => setMethod(m.id, { config: { instructions: e.target.value } })} className={input} /></Field>
                    </div>
                    <div className="md:col-span-2">
                      <Field label="QR CODE IMAGE" hint="UPLOAD UNDER 1.2 MB — STORED AS A DATA URL AND SHOWN AT CHECKOUT">
                        <div className="flex flex-wrap items-center gap-3">
                          <label className="border-line text-fore hover:border-signal/50 flex cursor-pointer items-center gap-2 border px-3 py-2.5 text-[13px]">
                            <Upload size={13} className="text-signal" /> Upload QR
                            <input
                              type="file"
                              accept="image/*"
                              className="sr-only"
                              onChange={(e) => {
                                const f = e.target.files?.[0];
                                if (!f) return;
                                if (f.size > 600_000) return api.toast("QR image must be under 600 KB.", "err");
                                const reader = new FileReader();
                                reader.onload = () => setMethod(m.id, { config: { qrImage: String(reader.result) } });
                                reader.readAsDataURL(f);
                              }}
                            />
                          </label>
                          <Toggle checked={Boolean(m.config?.requireScreenshot)} onChange={(v) => setMethod(m.id, { config: { requireScreenshot: v } })} label="Ask for screenshot" />
                        </div>
                      </Field>
                      {m.config?.qrImage && <img src={m.config.qrImage} alt="QR code" className="mt-3 h-36 w-36 border border-line bg-white p-1" />}
                    </div>
                  </>
                )}

                {m.key === "wallet" && (
                  <>
                    <div className="md:col-span-2">
                      <Field label="INSTRUCTIONS"><textarea rows={2} value={m.config?.instructions ?? ""} onChange={(e) => setMethod(m.id, { config: { instructions: e.target.value } })} className={input} /></Field>
                    </div>
                    <div className="md:col-span-2">
                      <Field label="TOP-UP PRESETS (COMMA SEPARATED ₹)">
                        <input
                          value={(m.config?.topups ?? []).join(", ")}
                          onChange={(e) => setMethod(m.id, { config: { topups: e.target.value.split(",").map((s: string) => Number(s.trim())).filter((n: number) => n >= 100) } })}
                          className={input}
                          placeholder="500, 1000, 2500, 5000"
                        />
                      </Field>
                    </div>
                  </>
                )}
              </div>

              <SaveBar onSave={() => saveMethod(m)} hint="WALLET DEBITS AND PAYMENT STATUS ARE ALWAYS SET SERVER-SIDE" />
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
