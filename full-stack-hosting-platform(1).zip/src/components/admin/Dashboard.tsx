"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, RefreshCw } from "lucide-react";
import { PageHead, Stat, Table, Badge, Empty, useApi, Btn } from "@/components/admin/kit";
import { AreaChart, BarsChart, Donut } from "@/components/admin/Charts";

const TONE: Record<string, string> = {
  paid: "ok",
  active: "ok",
  verified: "ok",
  pending: "warn",
  awaiting_verification: "warn",
  awaiting_payment: "warn",
  processing: "info",
  failed: "bad",
  rejected: "bad",
  cancelled: "mute",
  refunded: "info",
};

export function Dashboard() {
  const api = useApi();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      setData(await api.get("/api/admin/metrics"));
    } catch {
      /* toast shown */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading && !data)
    return (
      <div className="flex items-center gap-3 py-24 text-mute">
        <RefreshCw size={16} className="animate-spin" />
        <span className="legend">READING METRICS FROM DATABASE…</span>
      </div>
    );

  if (!data) return <Empty title="Metrics unavailable" hint="Check API permissions and try again." />;

  const t = data.totals;
  const mix = data.methodMix.map((m: any) => ({ label: m.method, value: m.count }));
  const cats = data.categoryMix.map((c: any) => ({ label: c.name, value: c.n }));
  const best = data.bestPlans.map((p: any) => ({ label: p.name, value: p.sales }));

  return (
    <div>
      <PageHead
        title="Console overview"
        subtitle="Live figures from the catalogue, orders and payment ledger. Nothing on this screen is stored client-side."
        actions={
          <Btn variant="ghost" onClick={load}>
            <RefreshCw size={13} className={loading ? "animate-spin" : ""} /> Refresh
          </Btn>
        }
      />

      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="REVENUE (SETTLED)" value={`₹${t.revenue.toLocaleString("en-IN")}`} hint="PAID · ACTIVE · PROCESSING ORDERS" />
        <Stat label="TOTAL ORDERS" value={String(t.orders)} hint={`${t.pendingOrders} AWAITING PAYMENT`} />
        <Stat label="CUSTOMERS" value={String(t.customers)} hint={`${t.plans} PLANS · ${t.activeCategories} ACTIVE CATEGORIES`} tone="text-chalk" />
        <Stat label="WALLET BALANCES" value={`₹${Math.round(t.walletBalance).toLocaleString("en-IN")}`} hint="AGGREGATE CUSTOMER FUNDS" tone="text-link" />
        <Stat label="SUCCESSFUL PAYMENTS" value={String(t.successfulPayments)} hint="VERIFIED BY SIGNATURE, WEBHOOK OR ADMIN" tone="text-led" />
        <Stat label="PENDING VERIFICATION" value={String(t.pendingPayments)} hint="MANUAL QR / UTR REVIEW QUEUE" tone="text-signal" />
        <Stat label="REGIONS ONLINE" value="12" hint="AS204312 · 40 Tbit/s MITIGATION" />
        <Stat label="UPTIME 90D" value="99.99%" hint="ACROSS ALL SHARED NODES" tone="text-led" />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.55fr_1fr]">
        <AreaChart data={data.series} />
        <Donut data={mix} label="PAYMENT METHOD DISTRIBUTION" />
        <BarsChart data={best.slice(0, 6)} label="BEST-SELLING PLANS" />
        <BarsChart data={cats} label="PLANS PER CATEGORY" />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <div>
          <div className="mb-3 flex items-center justify-between">
            <span className="legend text-signal">RECENT ORDERS</span>
            <Link href="/admin/orders" className="legend text-mute hover:text-fore flex items-center gap-1">
              ALL <ArrowUpRight size={11} />
            </Link>
          </div>
          <Table head={["REF", "PLAN", "AMOUNT", "STATUS", "WHEN"]}>
            {data.recentOrders.map((o: any) => (
              <tr key={o.id} className="border-line border-b last:border-0">
                <td className="num text-fore px-4 py-3 text-[12.5px]">{o.reference}</td>
                <td className="text-chalk max-w-[180px] truncate px-4 py-3 text-[13px]">
                  {o.plan}
                  <span className="text-mute block text-[11px]">{o.customer ?? "Guest"}</span>
                </td>
                <td className="num text-fore px-4 py-3 text-[13px]">₹{Number(o.total).toLocaleString("en-IN")}</td>
                <td className="px-4 py-3">
                  <Badge tone={TONE[o.status] ?? "mute"}>{String(o.status).replace("_", " ")}</Badge>
                </td>
                <td className="num text-mute px-4 py-3 text-[11.5px]">{new Date(o.createdAt).toLocaleDateString("en-IN")}</td>
              </tr>
            ))}
          </Table>
        </div>

        <div>
          <div className="mb-3 flex items-center justify-between">
            <span className="legend text-signal">RECENT PAYMENT ACTIVITY</span>
            <Link href="/admin/payments" className="legend text-mute hover:text-fore flex items-center gap-1">
              QUEUE <ArrowUpRight size={11} />
            </Link>
          </div>
          <Table head={["REF", "METHOD", "AMOUNT", "STATUS", "WHEN"]}>
            {data.recentPayments.map((p: any) => (
              <tr key={p.id} className="border-line border-b last:border-0">
                <td className="num text-fore px-4 py-3 text-[12.5px]">{p.reference}</td>
                <td className="legend text-fore px-4 py-3">{p.method}</td>
                <td className="num text-fore px-4 py-3 text-[13px]">₹{Number(p.amount).toLocaleString("en-IN")}</td>
                <td className="px-4 py-3">
                  <Badge tone={TONE[p.status] ?? "mute"}>{String(p.status).replace("_", " ")}</Badge>
                </td>
                <td className="num text-mute px-4 py-3 text-[11.5px]">{new Date(p.createdAt).toLocaleDateString("en-IN")}</td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <span className="legend text-signal mb-3 block">RECENT CUSTOMERS</span>
          <Table head={["NAME", "EMAIL", "REGISTERED"]}>
            {data.recentCustomers.map((c: any) => (
              <tr key={c.id} className="border-line border-b last:border-0">
                <td className="text-chalk px-4 py-3 text-[13.5px]">{c.name}</td>
                <td className="text-mute px-4 py-3 text-[13px]">{c.email}</td>
                <td className="num text-mute px-4 py-3 text-[12px]">{new Date(c.createdAt).toLocaleDateString("en-IN")}</td>
              </tr>
            ))}
          </Table>
        </div>
        <div>
          <span className="legend text-signal mb-3 block">ADMIN ACTIVITY LOG</span>
          <div className="panel divide-line max-h-[320px] divide-y overflow-y-auto thin-scroll">
            {data.activity.map((a: any) => (
              <motion.div key={a.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="px-4 py-3">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-fore text-[13px]">{a.action}</span>
                  <span className="num text-mute text-[11px]">
                    {new Date(a.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
                <div className="legend text-mute mt-1 text-[8.5px]">
                  {a.actor} {a.entity ? `· ${a.entity}` : ""} {a.entityId ? `· ${String(a.entityId).slice(0, 8)}` : ""}
                </div>
              </motion.div>
            ))}
            {data.activity.length === 0 && <p className="text-mute px-4 py-6 text-[13px]">No activity recorded yet.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
