"use client";

import { useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2, ChevronUp, ChevronDown, GripVertical } from "lucide-react";
import {
  PageHead, Btn, Modal, Field, input, Toggle, Toolbar, Table, Badge, Empty, useApi, Confirm,
} from "@/components/admin/kit";

/* ------------------------------ categories -------------------------------- */
export function CategoriesScreen() {
  const api = useApi();
  const [rows, setRows] = useState<any[]>([]);
  const [editing, setEditing] = useState<any>(null);
  const [remove, setRemove] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");

  const load = async () => {
    try {
      setRows((await api.get("/api/admin/categories")).rows);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const tree = useMemo(() => {
    const map = new Map<string, any>();
    rows.forEach((r) => map.set(r.id, { ...r, children: [] }));
    const roots: any[] = [];
    rows.forEach((r) => {
      const node = map.get(r.id);
      const parent = r.parentId ? map.get(r.parentId) : null;
      if (parent) parent.children.push(node);
      else roots.push(node);
    });
    return roots;
  }, [rows]);

  const flat = useMemo(() => {
    const out: { node: any; depth: number }[] = [];
    const walk = (list: any[], depth: number) =>
      list.forEach((n) => {
        out.push({ node: n, depth });
        walk(n.children, depth + 1);
      });
    walk(tree, 0);
    return out;
  }, [tree]);

  const filtered = flat.filter((f) => f.node.name.toLowerCase().includes(search.toLowerCase()));

  const save = async () => {
    setBusy(true);
    try {
      if (editing._new) await api.post("/api/admin/categories", editing);
      else await api.put(`/api/admin/categories/${editing.id}`, editing);
      api.toast("Category saved — reflected on the storefront immediately.");
      setEditing(null);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const move = async (node: any, dir: -1 | 1) => {
    const siblings = node.parentId ? rows.filter((r) => r.parentId === node.parentId) : rows.filter((r) => !r.parentId);
    siblings.sort((a, b) => a.sortOrder - b.sortOrder);
    const idx = siblings.findIndex((s) => s.id === node.id);
    const other = siblings[idx + dir];
    if (!other) return;
    await api.post("/api/admin/actions", {
      action: "reorder",
      table: "categories",
      scope: "catalog",
      items: [
        { id: node.id, sortOrder: other.sortOrder },
        { id: other.id, sortOrder: node.sortOrder },
      ],
    });
    load();
  };

  return (
    <div>
      <PageHead
        title="Categories & subcategories"
        subtitle="Unlimited nesting. Each level carries its own icon, banner, SEO copy and display order."
        actions={
          <Btn onClick={() => setEditing({ _new: true, name: "", slug: "", description: "", icon: "server", parentId: "", sortOrder: rows.length + 1, active: true })}>
            <Plus size={14} /> New category
          </Btn>
        }
      />
      <Toolbar search={search} onSearch={setSearch} placeholder="Search categories…">
        <span className="legend text-mute">{filtered.length} NODES · {tree.length} ROOTS</span>
      </Toolbar>

      {filtered.length === 0 ? (
        <Empty title="No categories" hint="Create a root category, then nest subcategories under it." />
      ) : (
        <div className="panel">
          {filtered.map(({ node, depth }) => (
            <div
              key={node.id}
              className="border-line hover:bg-raised/50 flex items-center gap-3 border-b px-4 py-3 transition-colors last:border-0"
              style={{ paddingLeft: 16 + depth * 26 }}
            >
              <GripVertical size={14} className="text-line-2 shrink-0" />
              <span className="num text-mute w-6 text-[11px]">{String(node.sortOrder).padStart(2, "0")}</span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-chalk text-[13.5px] font-medium">{node.name}</span>
                  <span className="num text-mute text-[11px]">/{node.slug}</span>
                  {depth > 0 && <Badge tone="mute">NESTED L{depth + 1}</Badge>}
                </div>
                <p className="text-mute truncate text-[12px]">{node.description}</p>
              </div>
              <span className={`led h-1.5 w-1.5 shrink-0 rounded-full ${node.active ? "bg-led text-led" : "bg-line-2"}`} />
              <div className="flex items-center gap-1">
                <button onClick={() => move(node, -1)} className="text-mute hover:text-fore p-1.5" aria-label="Move up"><ChevronUp size={13} /></button>
                <button onClick={() => move(node, 1)} className="text-mute hover:text-fore p-1.5" aria-label="Move down"><ChevronDown size={13} /></button>
                <button
                  onClick={() => api.post("/api/admin/actions", { action: "toggle", table: "categories", id: node.id, scope: "catalog" }).then(load)}
                  className="border-line text-mute hover:border-led/40 hover:text-led border p-1.5"
                  aria-label="Toggle active"
                >
                  {node.active ? <Badge tone="ok">LIVE</Badge> : <Badge tone="warn">HIDDEN</Badge>}
                </button>
                <button onClick={() => setEditing({ ...node, _new: false })} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Edit"><Pencil size={13} /></button>
                <button onClick={() => setRemove(node)} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Delete"><Trash2 size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={editing?._new ? "New category" : `Edit — ${editing?.name ?? ""}`}
        footer={
          <>
            <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn onClick={save} disabled={busy}>{busy ? "SAVING…" : "Save category"}</Btn>
          </>
        }
      >
        {editing && (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="NAME" required>
              <input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value, slug: editing._new || !editing.slug ? e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") : editing.slug })} className={input} />
            </Field>
            <Field label="SLUG" required>
              <input value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: e.target.value })} className={`${input} font-mono`} />
            </Field>
            <div className="md:col-span-2">
              <Field label="DESCRIPTION">
                <textarea rows={3} value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className={input} />
              </Field>
            </div>
            <Field label="PARENT CATEGORY">
              <select value={editing.parentId ?? ""} onChange={(e) => setEditing({ ...editing, parentId: e.target.value })} className={input}>
                <option value="">— top level —</option>
                {rows.filter((r) => r.id !== editing.id).map((r) => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </Field>
            <Field label="ICON (LUCIDE NAME)">
              <input value={editing.icon ?? ""} onChange={(e) => setEditing({ ...editing, icon: e.target.value })} className={input} />
            </Field>
            <div className="md:col-span-2">
              <Field label="BANNER IMAGE PATH OR URL">
                <input value={editing.image ?? ""} onChange={(e) => setEditing({ ...editing, image: e.target.value })} className={input} placeholder="/images/hero-aisle.jpg" />
              </Field>
            </div>
            <Field label="SEO TITLE">
              <input value={editing.seoTitle ?? ""} onChange={(e) => setEditing({ ...editing, seoTitle: e.target.value })} className={input} />
            </Field>
            <Field label="DISPLAY ORDER">
              <input type="number" value={editing.sortOrder ?? 0} onChange={(e) => setEditing({ ...editing, sortOrder: Number(e.target.value) })} className={input} />
            </Field>
            <div className="md:col-span-2">
              <Field label="SEO DESCRIPTION">
                <textarea rows={2} value={editing.seoDescription ?? ""} onChange={(e) => setEditing({ ...editing, seoDescription: e.target.value })} className={input} />
              </Field>
            </div>
            <div className="md:col-span-2 border-line border-t pt-4">
              <Toggle checked={editing.active} onChange={(v) => setEditing({ ...editing, active: v })} label="Active (visible on storefront)" />
            </div>
          </div>
        )}
      </Modal>

      <Confirm
        open={Boolean(remove)}
        onClose={() => setRemove(null)}
        busy={busy}
        title="Delete category"
        body={`Delete "${remove?.name}"? Its subcategories become top-level rather than being deleted, and plans keep working with an unassigned category.`}
        onConfirm={async () => {
          const target = remove;
          if (!target) return;
          setBusy(true);
          try {
            await api.del(`/api/admin/categories/${target.id}`);
            api.toast("Category deleted.");
            setRemove(null);
            load();
          } catch {
            /* toast */
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}

/* ---------------------------------- tags ---------------------------------- */
export function TagsScreen() {
  const api = useApi();
  const [rows, setRows] = useState<any[]>([]);
  const [editing, setEditing] = useState<any>(null);
  const [remove, setRemove] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setRows((await api.get("/api/admin/tags")).rows);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    setBusy(true);
    try {
      if (editing._new) await api.post("/api/admin/tags", editing);
      else await api.put(`/api/admin/tags/${editing.id}`, editing);
      api.toast("Tag saved.");
      setEditing(null);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <PageHead
        title="Tags"
        subtitle="Reusable labels with their own colours. Decide per tag whether it prints on the public pricing panels."
        actions={
          <Btn onClick={() => setEditing({ _new: true, name: "", slug: "", color: "#FF6B18", showOnCards: true, active: true, sortOrder: rows.length + 1 })}>
            <Plus size={14} /> New tag
          </Btn>
        }
      />

      {rows.length === 0 ? (
        <Empty title="No tags yet" hint="Create tags like Best Seller, Budget Friendly or DDoS Protected." />
      ) : (
        <Table head={["TAG", "SLUG", "COLOUR", "ON CARDS", "ORDER", "STATUS", "ACTIONS"]}>
          {rows.map((t) => (
            <tr key={t.id} className="border-line hover:bg-raised/50 border-b last:border-0">
              <td className="px-4 py-3">
                <span className="legend border px-2 py-1" style={{ color: t.color, borderColor: `${t.color}55`, background: `${t.color}14` }}>
                  {t.name}
                </span>
              </td>
              <td className="num text-mute px-4 py-3 text-[12px]">{t.slug}</td>
              <td className="px-4 py-3">
                <span className="flex items-center gap-2">
                  <span className="h-4 w-4 border border-line" style={{ background: t.color }} />
                  <span className="num text-mute text-[12px]">{t.color}</span>
                </span>
              </td>
              <td className="px-4 py-3">{t.showOnCards ? <Badge tone="ok">YES</Badge> : <Badge tone="mute">NO</Badge>}</td>
              <td className="num text-mute px-4 py-3 text-[12px]">{t.sortOrder}</td>
              <td className="px-4 py-3">{t.active ? <Badge tone="ok">ACTIVE</Badge> : <Badge tone="warn">DISABLED</Badge>}</td>
              <td className="px-4 py-3">
                <div className="flex gap-1.5">
                  <button onClick={() => setEditing({ ...t, _new: false })} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Edit"><Pencil size={13} /></button>
                  <button onClick={() => setRemove(t)} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Delete"><Trash2 size={13} /></button>
                </div>
              </td>
            </tr>
          ))}
        </Table>
      )}

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={editing?._new ? "New tag" : `Edit — ${editing?.name ?? ""}`}
        footer={
          <>
            <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn onClick={save} disabled={busy}>{busy ? "SAVING…" : "Save tag"}</Btn>
          </>
        }
      >
        {editing && (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="TAG NAME" required>
              <input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value, slug: e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") })} className={input} />
            </Field>
            <Field label="SLUG" required>
              <input value={editing.slug} onChange={(e) => setEditing({ ...editing, slug: e.target.value })} className={`${input} font-mono`} />
            </Field>
            <Field label="COLOUR">
              <div className="flex gap-2">
                <input type="color" value={editing.color} onChange={(e) => setEditing({ ...editing, color: e.target.value })} className="border-line h-[42px] w-14 border bg-raised" aria-label="Tag colour" />
                <input value={editing.color} onChange={(e) => setEditing({ ...editing, color: e.target.value })} className={`${input} font-mono`} />
              </div>
            </Field>
            <Field label="DISPLAY ORDER">
              <input type="number" value={editing.sortOrder ?? 0} onChange={(e) => setEditing({ ...editing, sortOrder: Number(e.target.value) })} className={input} />
            </Field>
            <div className="md:col-span-2 flex flex-wrap gap-6 border-line border-t pt-4">
              <Toggle checked={editing.showOnCards} onChange={(v) => setEditing({ ...editing, showOnCards: v })} label="Show on pricing panels" />
              <Toggle checked={editing.active} onChange={(v) => setEditing({ ...editing, active: v })} label="Active" />
            </div>
          </div>
        )}
      </Modal>

      <Confirm
        open={Boolean(remove)}
        onClose={() => setRemove(null)}
        busy={busy}
        title="Delete tag"
        body={`Delete "${remove?.name}"? It is removed from every plan it is attached to.`}
        onConfirm={async () => {
          const target = remove;
          if (!target) return;
          setBusy(true);
          try {
            await api.del(`/api/admin/tags/${target.id}`);
            api.toast("Tag deleted.");
            setRemove(null);
            load();
          } catch {
            /* toast */
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}
