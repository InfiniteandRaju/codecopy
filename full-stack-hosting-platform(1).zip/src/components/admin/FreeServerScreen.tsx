"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Save,
  Plus,
  Trash2,
  Play,
  Square,
  RotateCcw,
  Clock,
  ShieldOff,
  ShieldCheck,
  RefreshCw,
  Server,
  Rocket,
} from "lucide-react";
import { PageHead, Btn, Field, input, Toggle, Table, Badge, Empty, useApi, Confirm } from "@/components/admin/kit";
import { useToast } from "@/components/ui/Toast";

const numList = (v: unknown) => (Array.isArray(v) ? v.map(Number).filter((n) => Number.isFinite(n)) : []);

const numField = (label: string, value: any, onChange: (n: number) => void, hint?: string) => (
  <Field label={label} hint={hint}>
    <input type="number" value={value ?? 0} onChange={(e) => onChange(Number(e.target.value))} className={input} />
  </Field>
);

/** Full admin control of the free demo server system. */
export function FreeServerScreen() {
  const api = useApi();
  const { push } = useToast();
  const [cfg, setCfg] = useState<any>(null);
  const [prov, setProv] = useState<any>(null);
  const [provForm, setProvForm] = useState<any>(null);
  const [servers, setServers] = useState<any[]>([]);
  const [role, setRole] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState<any>(null);

  const load = useCallback(async () => {
    try {
      const data = await api.get("/api/admin/free-server");
      setCfg(data.settings);
      setProv(data.provisioning);
      setServers(data.servers);
      setRole(data.actorRole);
      setProvForm((prev: any) => ({
        ...(prev ?? {}),
        enabled: prev?.enabled ?? data.provisioning.configured ?? false,
        baseUrl: prev?.baseUrl ?? data.provisioning.baseUrl ?? "",
        appKey: "",
        clientToken: "",
        nodeStrategy: prev?.nodeStrategy ?? "auto",
        fixedNodeId: prev?.fixedNodeId ?? 0,
        defaultEgg: prev?.defaultEgg ?? 1,
        defaultDockerImage: prev?.defaultDockerImage ?? "",
        allocationPort: prev?.allocationPort ?? 25565,
        environment: prev?.environment ?? "{}",
      }));
    } catch {
      /* toast shown */
    }
  }, [api]);

  useEffect(() => {
    load();
  }, [load]);

  if (!cfg) return <div className="legend text-mute py-20 text-center">LOADING FREE SERVER SETTINGS…</div>;

  const set = (patch: any) => setCfg((c: any) => ({ ...c, ...patch }));
  const nested = (group: string, key: string, value: any) =>
    setCfg((c: any) => ({ ...c, [group]: { ...c[group], [key]: value } }));

  const save = async () => {
    setBusy(true);
    try {
      const data = await api.post("/api/admin/free-server", { action: "save_settings", value: cfg });
      setCfg(data.settings);
      push("Free server settings saved — the configurator updates immediately.", "ok");
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const saveProvisioning = async () => {
    setBusy(true);
    try {
      const data = await api.post("/api/admin/free-server", {
        action: "save_provisioning",
        ...provForm,
        environment: safeJson(provForm.environment),
      });
      setProv(data.provisioning);
      push(data.provisioning.configured ? "Provisioning backend connected." : "Saved — still not connected.", data.provisioning.configured ? "ok" : "err");
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const serverAct = async (id: string, action: string, extra: any = {}) => {
    setBusy(true);
    try {
      await api.post("/api/admin/free-server", { action, id, ...extra });
      push(`${action} completed.`, "ok");
      setConfirm(null);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const software = cfg.software ?? [];

  return (
    <div className="flex flex-col gap-6">
      <PageHead
        title="Free server demo"
        subtitle="Everything the public configurator offers — resources, pricing rules, durations, software, abuse limits and the provisioning backend."
        actions={
          <Btn onClick={save} disabled={busy}>
            <Save size={13} /> {busy ? "SAVING…" : "Save settings"}
          </Btn>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="panel p-4">
          <div className="legend text-mute">DEMO STATUS</div>
          <div className={`mt-2 text-[20px] font-semibold ${cfg.enabled ? "text-led" : "text-signal"}`}>
            {cfg.enabled ? "ENABLED" : "DISABLED"}
          </div>
        </div>
        <div className="panel p-4">
          <div className="legend text-mute">PROVISIONING BACKEND</div>
          <div className={`mt-2 text-[20px] font-semibold ${prov?.configured ? "text-led" : "text-signal"}`}>
            {prov?.configured ? "CONNECTED" : "NOT CONFIGURED"}
          </div>
          <p className="legend text-mute mt-1">{prov?.baseUrl ?? "—"}</p>
        </div>
        <div className="panel p-4">
          <div className="legend text-mute">ACTIVE DEMOS</div>
          <div className="num mt-2 text-[20px] font-semibold text-chalk">
            {servers.filter((s) => ["running", "pending", "stopped"].includes(s.server.status)).length} / {cfg.access.maxActiveGlobal}
          </div>
        </div>
      </div>

      {/* ---------------------------- general ---------------------------- */}
      <Section title="General settings" icon={<Server size={15} />} onSave={save} busy={busy}>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="flex items-end pb-1">
            <Toggle checked={cfg.enabled} onChange={(v) => set({ enabled: v })} label="Free server demo enabled" />
          </div>
          <Field label="CTA BUTTON TEXT">
            <input value={cfg.cta} onChange={(e) => set({ cta: e.target.value })} className={input} />
          </Field>
          <Field label="PAGE TITLE">
            <input value={cfg.title} onChange={(e) => set({ title: e.target.value })} className={input} />
          </Field>
          <Field label="BANNER IMAGE">
            <input value={cfg.banner} onChange={(e) => set({ banner: e.target.value })} className={input} placeholder="/images/rack-macro.jpg" />
          </Field>
          <div className="md:col-span-2">
            <Field label="DESCRIPTION">
              <textarea rows={2} value={cfg.description} onChange={(e) => set({ description: e.target.value })} className={input} />
            </Field>
          </div>
          <div className="flex items-end pb-1">
            <Toggle checked={cfg.requireRegistration} onChange={(v) => set({ requireRegistration: v })} label="Require registration" />
          </div>
          {numField("DEFAULT RAM (MB)", cfg.defaults.ramMb, (n) => nested("defaults", "ramMb", n))}
          {numField("DEFAULT CPU (%)", cfg.defaults.cpuPercent, (n) => nested("defaults", "cpuPercent", n))}
          {numField("DEFAULT DISK (MB)", cfg.defaults.diskMb, (n) => nested("defaults", "diskMb", n))}
          {numField("DEFAULT DURATION (MIN)", cfg.defaults.durationMinutes, (n) => nested("defaults", "durationMinutes", n))}
          <Field label="DEFAULT SOFTWARE ID">
            <input value={cfg.defaults.software} onChange={(e) => nested("defaults", "software", e.target.value)} className={input} />
          </Field>
          <Field label="CURRENCY">
            <input value={cfg.currency} onChange={(e) => set({ currency: e.target.value })} className={input} />
          </Field>
        </div>
      </Section>

      {/* ---------------------------- resources -------------------------- */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Section title="RAM" icon={<Server size={15} />} onSave={save} busy={busy} compact>
          <div className="grid gap-3">
            {numField("FREE ALLOWANCE (MB)", cfg.ram.freeMb, (n) => nested("ram", "freeMb", n))}
            {numField("MAXIMUM (MB)", cfg.ram.maxMb, (n) => nested("ram", "maxMb", n))}
            {numField("PRICE PER EXTRA GB", cfg.ram.pricePerGb, (n) => nested("ram", "pricePerGb", n))}
            <Field label="AVAILABLE OPTIONS (MB, COMMA SEPARATED)">
              <input
                value={cfg.ram.options.join(", ")}
                onChange={(e) => nested("ram", "options", numList(e.target.value.split(",")))}
                className={`${input} font-mono`}
              />
            </Field>
            <Toggle checked={cfg.ram.allowPaid} onChange={(v) => nested("ram", "allowPaid", v)} label="Allow paid RAM upgrades" />
          </div>
        </Section>

        <Section title="CPU" icon={<Rocket size={15} />} onSave={save} busy={busy} compact>
          <div className="grid gap-3">
            {numField("FREE ALLOWANCE (%)", cfg.cpu.freePercent, (n) => nested("cpu", "freePercent", n))}
            {numField("MAXIMUM (%)", cfg.cpu.maxPercent, (n) => nested("cpu", "maxPercent", n))}
            {numField("PRICE PER +100%", cfg.cpu.pricePer100, (n) => nested("cpu", "pricePer100", n))}
            <Field label="AVAILABLE OPTIONS (%)" hint="PASSED TO THE PANEL AS A REAL CPU LIMIT">
              <input
                value={cfg.cpu.options.join(", ")}
                onChange={(e) => nested("cpu", "options", numList(e.target.value.split(",")))}
                className={`${input} font-mono`}
              />
            </Field>
            <Toggle checked={cfg.cpu.allowPaid} onChange={(v) => nested("cpu", "allowPaid", v)} label="Allow paid CPU upgrades" />
          </div>
        </Section>

        <Section title="Storage" icon={<Server size={15} />} onSave={save} busy={busy} compact>
          <div className="grid gap-3">
            {numField("FREE ALLOWANCE (MB)", cfg.disk.freeMb, (n) => nested("disk", "freeMb", n))}
            {numField("MAXIMUM (MB)", cfg.disk.maxMb, (n) => nested("disk", "maxMb", n))}
            {numField("PRICE PER EXTRA GB", cfg.disk.pricePerGb, (n) => nested("disk", "pricePerGb", n))}
            <Field label="DISK TYPE LABEL">
              <input value={cfg.disk.type} onChange={(e) => nested("disk", "type", e.target.value)} className={input} />
            </Field>
            <Field label="AVAILABLE OPTIONS (MB)">
              <input
                value={cfg.disk.options.join(", ")}
                onChange={(e) => nested("disk", "options", numList(e.target.value.split(",")))}
                className={`${input} font-mono`}
              />
            </Field>
            <Toggle checked={cfg.disk.allowPaid} onChange={(v) => nested("disk", "allowPaid", v)} label="Allow paid storage upgrades" />
          </div>
        </Section>
      </div>

      {/* ---------------------------- duration --------------------------- */}
      <Section title="Duration & cleanup" icon={<Clock size={15} />} onSave={save} busy={busy}>
        <div className="grid gap-4 md:grid-cols-3">
          <Field label="AVAILABLE DURATIONS (MINUTES)">
            <input
              value={cfg.duration.options.join(", ")}
              onChange={(e) => nested("duration", "options", numList(e.target.value.split(",")))}
              className={`${input} font-mono`}
            />
          </Field>
          {numField("DEFAULT DURATION (MIN)", cfg.duration.defaultMinutes, (n) => nested("duration", "defaultMinutes", n))}
          {numField("MAXIMUM DURATION (MIN)", cfg.duration.maxMinutes, (n) => nested("duration", "maxMinutes", n))}
          {numField("EXTENSION INCREMENT (MIN)", cfg.duration.extensionMinutes, (n) => nested("duration", "extensionMinutes", n))}
          <Field label="ON EXPIRY">
            <select value={cfg.duration.expireAction} onChange={(e) => nested("duration", "expireAction", e.target.value)} className={input}>
              <option value="stop">Stop the server</option>
              <option value="delete">Destroy the server</option>
            </select>
          </Field>
          <div className="flex flex-col justify-center gap-3 pb-1">
            <Toggle checked={cfg.duration.allowExtension} onChange={(v) => nested("duration", "allowExtension", v)} label="Allow customers to extend" />
            <Toggle checked={cfg.duration.cleanup} onChange={(v) => nested("duration", "cleanup", v)} label="Automatic cleanup enabled" />
          </div>
        </div>
      </Section>

      {/* ---------------------------- software --------------------------- */}
      <Section title="Server software" icon={<Rocket size={15} />} onSave={save} busy={busy}>
        <div className="flex flex-col gap-3">
          {software.map((sw: any, i: number) => {
            const patch = (p: any) =>
              setCfg((c: any) => ({ ...c, software: c.software.map((s: any, j: number) => (j === i ? { ...s, ...p } : s)) }));
            return (
              <div key={i} className="border-line grid gap-3 border p-3 md:grid-cols-12">
                <Field label="ID"><input value={sw.id} onChange={(e) => patch({ id: e.target.value })} className={`${input} font-mono`} /></Field>
                <Field label="NAME" ><input value={sw.name} onChange={(e) => patch({ name: e.target.value })} className={input} /></Field>
                <Field label="VERSION"><input value={sw.version} onChange={(e) => patch({ version: e.target.value })} className={input} /></Field>
                <Field label="EGG ID"><input type="number" value={sw.egg ?? ""} onChange={(e) => patch({ egg: e.target.value ? Number(e.target.value) : null })} className={input} /></Field>
                <div className="md:col-span-4">
                  <Field label="DOCKER IMAGE">
                    <input value={sw.dockerImage} onChange={(e) => patch({ dockerImage: e.target.value })} className={`${input} font-mono`} />
                  </Field>
                </div>
                <div className="flex items-end justify-between gap-2 pb-1 md:col-span-1">
                  <Toggle checked={sw.enabled} onChange={(v) => patch({ enabled: v })} />
                  <button
                    onClick={() => setCfg((c: any) => ({ ...c, software: c.software.filter((_: any, j: number) => j !== i) }))}
                    className="text-mute hover:text-signal"
                    aria-label="Remove software"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="md:col-span-12">
                  <Field label="STARTUP COMMAND" hint="{{SERVER_MEMORY}} IS REPLACED WITH THE ALLOCATED RAM">
                    <input value={sw.startup} onChange={(e) => patch({ startup: e.target.value })} className={`${input} font-mono`} />
                  </Field>
                </div>
              </div>
            );
          })}
          {software.length === 0 && <Empty title="No software configured" hint="Add at least one server type for demos." />}
          <Btn
            variant="ghost"
            onClick={() =>
              setCfg((c: any) => ({
                ...c,
                software: [...c.software, { id: `sw${c.software.length + 1}`, name: "New software", version: "", enabled: true, egg: null, dockerImage: "", startup: "" }],
              }))
            }
          >
            <Plus size={13} /> Add software
          </Btn>
        </div>
      </Section>

      {/* ----------------------------- access ---------------------------- */}
      <Section title="Access & abuse protection" icon={<ShieldCheck size={15} />} onSave={save} busy={busy}>
        <div className="grid gap-4 md:grid-cols-3">
          {numField("MAX ACTIVE DEMOS PER ACCOUNT", cfg.access.maxPerAccount, (n) => nested("access", "maxPerAccount", n))}
          {numField("COOLDOWN BETWEEN DEMOS (MIN)", cfg.access.cooldownMinutes, (n) => nested("access", "cooldownMinutes", n))}
          {numField("MAX ACTIVE DEMOS GLOBALLY", cfg.access.maxActiveGlobal, (n) => nested("access", "maxActiveGlobal", n))}
          {numField("IP LIMIT (0 = OFF)", cfg.access.ipLimit, (n) => nested("access", "ipLimit", n))}
          {numField("IP WINDOW (MINUTES)", cfg.access.ipWindowMinutes, (n) => nested("access", "ipWindowMinutes", n))}
          <div className="flex items-end pb-1">
            <Toggle checked={cfg.access.oneActivePerUser} onChange={(v) => nested("access", "oneActivePerUser", v)} label="One active demo per customer" />
          </div>
        </div>
      </Section>

      {/* -------------------------- provisioning ------------------------- */}
      <Section title="Provisioning backend (Pterodactyl Application API)" icon={<Rocket size={15} />} onSave={saveProvisioning} busy={busy} superOnly={role !== "super_admin"}>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-mute max-w-2xl text-[12.5px]">
            Keys are stored encrypted on the server and never returned to the browser. Leave the key fields blank to keep
            the stored values. Without a backend the configurator reports provisioning as unavailable instead of faking servers.
          </p>
          <Badge tone={prov?.configured ? "ok" : "warn"}>{prov?.configured ? "CONNECTED" : "NOT CONNECTED"}</Badge>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="flex items-end pb-1">
            <Toggle checked={Boolean(provForm?.enabled)} onChange={(v) => setProvForm((p: any) => ({ ...p, enabled: v }))} label="Enable provisioning" />
          </div>
          <Field label="PANEL BASE URL">
            <input value={provForm?.baseUrl ?? ""} onChange={(e) => setProvForm((p: any) => ({ ...p, baseUrl: e.target.value }))} className={`${input} font-mono`} placeholder="https://panel.example.com" />
          </Field>
          <Field label="APPLICATION API KEY" hint={prov?.configured ? "STORED (ENCRYPTED)" : "REQUIRED"}>
            <input type="password" value={provForm?.appKey ?? ""} onChange={(e) => setProvForm((p: any) => ({ ...p, appKey: e.target.value }))} className={input} placeholder="••••••••••••" autoComplete="off" />
          </Field>
          <Field label="CLIENT API TOKEN (START/STOP/RESTART)" hint="CLIENT KEY OF AN ADMIN PANEL USER — ENCRYPTED">
            <input type="password" value={provForm?.clientToken ?? ""} onChange={(e) => setProvForm((p: any) => ({ ...p, clientToken: e.target.value }))} className={input} placeholder="••••••••••••" autoComplete="off" />
          </Field>
          <Field label="NODE STRATEGY">
            <select value={provForm?.nodeStrategy ?? "auto"} onChange={(e) => setProvForm((p: any) => ({ ...p, nodeStrategy: e.target.value }))} className={input}>
              <option value="auto">Automatic — pick the node with free capacity</option>
              <option value="fixed">Fixed node</option>
            </select>
          </Field>
          {provForm?.nodeStrategy === "fixed" && numField("FIXED NODE ID", provForm?.fixedNodeId ?? 0, (n) => setProvForm((p: any) => ({ ...p, fixedNodeId: n })))}
          {numField("DEFAULT EGG ID", provForm?.defaultEgg ?? 0, (n) => setProvForm((p: any) => ({ ...p, defaultEgg: n })))}
          {numField("ALLOCATION PORT", provForm?.allocationPort ?? 25565, (n) => setProvForm((p: any) => ({ ...p, allocationPort: n })))}
          <Field label="DEFAULT DOCKER IMAGE">
            <input value={provForm?.defaultDockerImage ?? ""} onChange={(e) => setProvForm((p: any) => ({ ...p, defaultDockerImage: e.target.value }))} className={`${input} font-mono`} />
          </Field>
          <Field label="EXTRA ENVIRONMENT (JSON)">
            <input value={provForm?.environment ?? "{}"} onChange={(e) => setProvForm((p: any) => ({ ...p, environment: e.target.value }))} className={`${input} font-mono`} />
          </Field>
        </div>
        <div className="border-line mt-4 border-t pt-3">
          <div className="legend text-mute mb-2">STATUS</div>
          <p className="text-fore text-[13px]">{prov?.message ?? "—"}</p>
          {prov?.nodes?.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {prov.nodes.map((n: any) => (
                <span key={n.id} className="border-line text-mute border px-2.5 py-1 text-[12px]">
                  #{n.id} {n.name} · {Math.round(((n.memoryUsed ?? 0) / (n.memory || 1)) * 100)}% RAM ·{" "}
                  {Math.round(((n.diskUsed ?? 0) / (n.disk || 1)) * 100)}% DISK
                </span>
              ))}
            </div>
          )}
        </div>
      </Section>

      {/* ------------------------- demo server table --------------------- */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-[15.5px] font-semibold">Demo servers</h3>
          <div className="flex gap-2">
            <Btn variant="ghost" onClick={() => api.post("/api/admin/free-server", { action: "sweep" }).then(() => { push("Expiry sweep completed.", "ok"); load(); })}>
              <RefreshCw size={13} /> Run expiry sweep
            </Btn>
          </div>
        </div>

        {servers.length === 0 ? (
          <Empty title="No demo servers yet" hint="Servers created from the public configurator appear here." />
        ) : (
          <Table head={["CUSTOMER", "SERVER", "SOFTWARE", "RAM / CPU / DISK", "CREATED", "EXPIRES", "STATUS", "ACTIONS"]}>
            {servers.map((row) => {
              const s = row.server;
              const expired = s.expiresAt && new Date(s.expiresAt).getTime() <= Date.now();
              return (
                <tr key={s.id} className="border-line hover:bg-raised/50 border-b last:border-0">
                  <td className="px-4 py-3">
                    <div className="text-chalk text-[13.5px]">{row.customer ?? "—"}</div>
                    <div className="text-mute text-[11.5px]">{row.email ?? ""}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-fore text-[13px]">{s.name}</div>
                    <div className="num text-mute text-[11px]">{s.reference}</div>
                  </td>
                  <td className="legend text-mute px-4 py-3">{s.software}</td>
                  <td className="num text-fore px-4 py-3 text-[12.5px]">
                    {s.ramMb} MB · {s.cpuPercent}% · {s.diskMb} MB
                  </td>
                  <td className="num text-mute px-4 py-3 text-[11.5px]">{new Date(s.createdAt).toLocaleDateString("en-IN")}</td>
                  <td className="num px-4 py-3 text-[11.5px]">
                    {s.expiresAt ? (
                      <span className={expired ? "text-signal" : "text-fore"}>
                        {new Date(s.expiresAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                      </span>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone={s.status === "running" ? "ok" : s.status === "failed" || s.status === "terminated" ? "bad" : "mute"}>
                      {s.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1.5">
                      <MiniBtn onClick={() => serverAct(s.id, "stop")} disabled={s.status !== "running"} title="Stop"><Square size={12} /></MiniBtn>
                      <MiniBtn onClick={() => serverAct(s.id, "extend", { minutes: cfg.duration.extensionMinutes })} title="Extend"><Clock size={12} /></MiniBtn>
                      <MiniBtn onClick={() => setConfirm({ kind: "allocate", row })} title="Reallocate"><Play size={12} /></MiniBtn>
                      <MiniBtn onClick={() => setConfirm({ kind: "terminate", row })} title="Terminate" danger><Trash2 size={12} /></MiniBtn>
                      <MiniBtn
                        onClick={() => setConfirm({ kind: row.userStatus === "suspended" ? "unblock" : "block", row })}
                        title={row.userStatus === "suspended" ? "Unblock customer" : "Block customer"}
                      >
                        {row.userStatus === "suspended" ? <ShieldCheck size={12} /> : <ShieldOff size={12} />}
                      </MiniBtn>
                    </div>
                  </td>
                </tr>
              );
            })}
          </Table>
        )}
      </div>

      {/* confirmations */}
      <Confirm
        open={Boolean(confirm?.kind === "terminate")}
        onClose={() => setConfirm(null)}
        busy={busy}
        title="Terminate demo server"
        body={`Destroy "${confirm?.row?.server?.name}" on the panel and mark it terminated? This cannot be undone.`}
        onConfirm={() => serverAct(confirm.row.server.id, "terminate")}
      />
      <Confirm
        open={Boolean(confirm?.kind === "block")}
        onClose={() => setConfirm(null)}
        busy={busy}
        title="Block customer"
        body={`Suspend ${confirm?.row?.email} and terminate all of their demo servers? They will not be able to sign in or create demos.`}
        onConfirm={() => serverAct(confirm.row.server.id, "block_user")}
      />
      <Confirm
        open={Boolean(confirm?.kind === "unblock")}
        onClose={() => setConfirm(null)}
        busy={busy}
        title="Unblock customer"
        body={`Re-enable ${confirm?.row?.email}?`}
        onConfirm={() => serverAct(confirm.row.server.id, "unblock_user")}
      />
      <AllocateModal
        open={Boolean(confirm?.kind === "allocate")}
        cfg={cfg}
        server={confirm?.row?.server}
        busy={busy}
        onClose={() => setConfirm(null)}
        onSave={(values) => serverAct(confirm.row.server.id, "allocate", values)}
      />
    </div>
  );
}

function MiniBtn({ children, onClick, disabled, title, danger }: any) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      aria-label={title}
      className={`border p-1.5 transition-colors disabled:opacity-40 ${
        danger ? "border-signal/40 text-signal hover:bg-signal/10" : "border-line text-mute hover:text-fore hover:border-line-2"
      }`}
    >
      {children}
    </button>
  );
}

function Section({ title, icon, children, onSave, busy, compact = false, superOnly = false }: any) {
  return (
    <section className="panel p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-line border-b pb-4">
        <div className="flex items-center gap-3">
          <span className="border-line text-signal flex h-8 w-8 items-center justify-center border">{icon}</span>
          <div>
            <h3 className="text-[15.5px] font-semibold">{title}</h3>
            {superOnly && <p className="legend text-signal mt-0.5">SUPER ADMIN ONLY</p>}
          </div>
        </div>
        <Btn onClick={onSave} disabled={busy || superOnly}>
          <Save size={13} /> {busy ? "SAVING…" : "Save"}
        </Btn>
      </div>
      <div className={compact ? "grid gap-3" : ""}>{children}</div>
    </section>
  );
}

function AllocateModal({
  open,
  cfg,
  server,
  busy,
  onClose,
  onSave,
}: {
  open: boolean;
  cfg: any;
  server: any;
  busy: boolean;
  onClose: () => void;
  onSave: (values: { ramMb: number; cpuPercent: number; diskMb: number }) => void;
}) {
  const [ram, setRam] = useState(0);
  const [cpu, setCpu] = useState(0);
  const [disk, setDisk] = useState(0);

  useEffect(() => {
    if (server) {
      setRam(server.ramMb);
      setCpu(server.cpuPercent);
      setDisk(server.diskMb);
    }
  }, [server]);

  if (!open || !server) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="panel w-full max-w-lg p-5" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-[16px] font-semibold">Change allocation — {server.reference}</h3>
        <p className="text-mute mt-1 text-[12.5px]">Values must exist in the configured option lists and are pushed to the panel.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Field label="RAM (MB)">
            <select value={ram} onChange={(e) => setRam(Number(e.target.value))} className={input}>
              {cfg.ram.options.map((o: number) => <option key={o} value={o}>{o} MB</option>)}
            </select>
          </Field>
          <Field label="CPU (%)">
            <select value={cpu} onChange={(e) => setCpu(Number(e.target.value))} className={input}>
              {cfg.cpu.options.map((o: number) => <option key={o} value={o}>{o}%</option>)}
            </select>
          </Field>
          <Field label="DISK (MB)">
            <select value={disk} onChange={(e) => setDisk(Number(e.target.value))} className={input}>
              {cfg.disk.options.map((o: number) => <option key={o} value={o}>{o} MB</option>)}
            </select>
          </Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn disabled={busy} onClick={() => onSave({ ramMb: ram, cpuPercent: cpu, diskMb: disk })}>
            {busy ? "APPLYING…" : "Apply allocation"}
          </Btn>
        </div>
      </div>
    </div>
  );
}

function safeJson(raw: string) {
  try {
    const parsed = JSON.parse(raw || "{}");
    return typeof parsed === "object" && parsed ? parsed : {};
  } catch {
    return {};
  }
}
