"use client";

import { motion } from "framer-motion";

const fmt = (n: number) =>
  n >= 100000 ? `${(n / 100000).toFixed(1)}L` : n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(Math.round(n));

/** Revenue over time — an amber plot line on the console surface. */
export function AreaChart({ data }: { data: { day: string; revenue: number; orders: number }[] }) {
  const w = 720;
  const h = 200;
  const pad = 28;
  const max = Math.max(...data.map((d) => d.revenue), 1);
  const x = (i: number) => pad + (i / Math.max(1, data.length - 1)) * (w - pad * 2);
  const y = (v: number) => h - pad - (v / max) * (h - pad * 2);
  const line = data.map((d, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(d.revenue).toFixed(1)}`).join(" ");
  const area = `${line} L${x(data.length - 1).toFixed(1)},${h - pad} L${pad},${h - pad} Z`;

  return (
    <div className="panel p-4">
      <div className="mb-3 flex items-center justify-between">
        <span className="legend text-signal">REVENUE · LAST 30 DAYS</span>
        <span className="num text-chalk text-[15px] font-semibold">
          ₹{data.reduce((s, d) => s + d.revenue, 0).toLocaleString("en-IN")}
        </span>
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} className="h-[200px] w-full" role="img" aria-label="Revenue chart">
        <defs>
          <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FF6B18" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#FF6B18" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 0.25, 0.5, 0.75, 1].map((t) => (
          <line key={t} x1={pad} x2={w - pad} y1={pad + t * (h - pad * 2)} y2={pad + t * (h - pad * 2)} stroke="#1E2636" strokeWidth="1" />
        ))}
        <motion.path
          d={area}
          fill="url(#revFill)"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7 }}
        />
        <motion.path
          d={line}
          fill="none"
          stroke="#FF6B18"
          strokeWidth="2"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.1, ease: [0.16, 0.8, 0.3, 1] }}
        />
        <text x={pad} y={h - 8} fill="#8A94A8" fontSize="10" fontFamily="IBM Plex Mono">
          {data[0]?.day.slice(5)}
        </text>
        <text x={w - pad} y={h - 8} fill="#8A94A8" fontSize="10" textAnchor="end" fontFamily="IBM Plex Mono">
          {data[data.length - 1]?.day.slice(5)}
        </text>
        <text x={4} y={pad + 4} fill="#8A94A8" fontSize="10" fontFamily="IBM Plex Mono">
          {fmt(max)}
        </text>
      </svg>
    </div>
  );
}

export function BarsChart({ data, label }: { data: { label: string; value: number }[]; label: string }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div className="panel p-4">
      <span className="legend text-signal">{label}</span>
      <div className="mt-4 flex flex-col gap-3">
        {data.map((d, i) => (
          <div key={d.label}>
            <div className="mb-1 flex items-center justify-between">
              <span className="text-fore truncate text-[12.5px]">{d.label}</span>
              <span className="num text-mute text-[12px]">{d.value}</span>
            </div>
            <div className="bg-line/70 h-2">
              <motion.div
                className="from-signal to-signal-2 h-full bg-gradient-to-r"
                initial={{ width: 0 }}
                animate={{ width: `${(d.value / max) * 100}%` }}
                transition={{ duration: 0.7, delay: i * 0.06, ease: [0.16, 0.8, 0.3, 1] }}
              />
            </div>
          </div>
        ))}
        {data.length === 0 && <p className="text-mute text-[12.5px]">No data yet.</p>}
      </div>
    </div>
  );
}

const PALETTE = ["#FF6B18", "#39D7E6", "#3DDC84", "#F5B942", "#7C9BFF", "#B07CFF", "#8A94A8"];

export function Donut({ data, label }: { data: { label: string; value: number }[]; label: string }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  let acc = 0;
  const radius = 54;
  const c = 2 * Math.PI * radius;

  return (
    <div className="panel p-4">
      <span className="legend text-signal">{label}</span>
      <div className="mt-4 flex items-center gap-5">
        <svg viewBox="0 0 140 140" className="h-[132px] w-[132px] shrink-0 -rotate-90">
          <circle cx="70" cy="70" r={radius} fill="none" stroke="#1E2636" strokeWidth="16" />
          {data.map((d, i) => {
            const frac = d.value / total;
            const dash = frac * c;
            const offset = -acc * c;
            acc += frac;
            return (
              <motion.circle
                key={d.label}
                cx="70"
                cy="70"
                r={radius}
                fill="none"
                stroke={PALETTE[i % PALETTE.length]}
                strokeWidth="16"
                strokeDasharray={`${dash} ${c - dash}`}
                strokeDashoffset={offset}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
              />
            );
          })}
        </svg>
        <ul className="flex flex-1 flex-col gap-2">
          {data.map((d, i) => (
            <li key={d.label} className="flex items-center justify-between gap-3">
              <span className="flex min-w-0 items-center gap-2">
                <span className="h-2.5 w-2.5 shrink-0" style={{ background: PALETTE[i % PALETTE.length] }} />
                <span className="text-fore truncate text-[12.5px]">{d.label}</span>
              </span>
              <span className="num text-mute text-[12px]">
                {Math.round((d.value / total) * 100)}%
              </span>
            </li>
          ))}
          {data.length === 0 && <li className="text-mute text-[12.5px]">No payments recorded.</li>}
        </ul>
      </div>
    </div>
  );
}
