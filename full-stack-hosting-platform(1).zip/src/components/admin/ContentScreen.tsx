"use client";

import { useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Save } from "lucide-react";
import {
  PageHead, Btn, Modal, Field, input, Toggle, Table, Badge, Empty, useApi, Confirm,
} from "@/components/admin/kit";

/* ------------------------------ testimonials ------------------------------- */
export function ContentScreen() {
  const api = useApi();
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [faqs, setFaqs] = useState<any[]>([]);
  const [coupons, setCoupons] = useState<any[]>([]);
  const [editing, setEditing] = useState<{ kind: string; row: any; isNew?: boolean } | null>(null);
  const [remove, setRemove] = useState<{ kind: string; row: any } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const [t, f, c] = await Promise.all([
        api.get("/api/admin/testimonials"),
        api.get("/api/admin/faqs"),
        api.get("/api/admin/coupons"),
      ]);
      setTestimonials(t.rows);
      setFaqs(f.rows);
      setCoupons(c.rows);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    if (!editing) return;
    setBusy(true);
    try {
      const { kind, row, isNew } = editing;
      if (isNew) await api.post(`/api/admin/${kind}`, row);
      else await api.put(`/api/admin/${kind}/${row.id}`, row);
      api.toast("Saved.");
      setEditing(null);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const doDelete = async () => {
    if (!remove) return;
    setBusy(true);
    try {
      await api.del(`/api/admin/${remove.kind}/${remove.row.id}`);
      api.toast("Deleted.");
      setRemove(null);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const tabs = [
    ["testimonials", testimonials, "Customer testimonials"],
    ["faqs", faqs, "Frequently asked questions"],
    ["coupons", coupons, "Coupons & discounts"],
  ] as const;

  return (
    <div>
      <PageHead
        title="Content"
        subtitle="Testimonials, FAQs and coupon codes — all rendered on the public site from these records."
      />
      <div className="flex flex-col gap-8">
        {tabs.map(([kind, rows, title]) => (
          <section key={kind}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-[15.5px] font-semibold">{title}</h3>
              <Btn
                variant="ghost"
                onClick={() =>
                  setEditing({
                    kind,
                    isNew: true,
                    row:
                      kind === "testimonials"
                        ? { name: "", role: "", company: "", quote: "", rating: 5, sortOrder: rows.length + 1, active: true }
                        : kind === "faqs"
                          ? { question: "", answer: "", group: "General", sortOrder: rows.length + 1, active: true }
                          : { code: "", type: "percent", value: 10, maxUses: 100, active: true },
                  })
                }
              >
                <Plus size={13} /> New
              </Btn>
            </div>

            {rows.length === 0 ? (
              <Empty title={`No ${kind} yet`} hint="Add the first record." />
            ) : (
              <Table
                head={
                  kind === "testimonials"
                    ? ["NAME", "QUOTE", "RATING", "ORDER", "STATUS", "ACTIONS"]
                    : kind === "faqs"
                      ? ["QUESTION", "ANSWER", "GROUP", "STATUS", "ACTIONS"]
                      : ["CODE", "TYPE", "VALUE", "USED", "STATUS", "ACTIONS"]
                }
              >
                {rows.map((r: any) => (
                  <tr key={r.id} className="border-line hover:bg-raised/50 border-b last:border-0">
                    {kind === "testimonials" && (
                      <>
                        <td className="px-4 py-3">
                          <div className="text-chalk text-[13.5px]">{r.name}</div>
                          <div className="text-mute text-[11.5px]">{[r.role, r.company].filter(Boolean).join(" · ")}</div>
                        </td>
                        <td className="text-mute max-w-[340px] truncate px-4 py-3 text-[13px]">{r.quote}</td>
                        <td className="num text-signal px-4 py-3 text-[13px]">{"★".repeat(r.rating)}</td>
                        <td className="num text-mute px-4 py-3 text-[12px]">{r.sortOrder}</td>
                        <td className="px-4 py-3">{r.active ? <Badge tone="ok">VISIBLE</Badge> : <Badge tone="warn">HIDDEN</Badge>}</td>
                      </>
                    )}
                    {kind === "faqs" && (
                      <>
                        <td className="text-chalk max-w-[280px] px-4 py-3 text-[13.5px]">{r.question}</td>
                        <td className="text-mute max-w-[340px] truncate px-4 py-3 text-[12.5px]">{r.answer}</td>
                        <td className="legend text-mute px-4 py-3">{r.group}</td>
                        <td className="px-4 py-3">{r.active ? <Badge tone="ok">VISIBLE</Badge> : <Badge tone="warn">HIDDEN</Badge>}</td>
                      </>
                    )}
                    {kind === "coupons" && (
                      <>
                        <td className="num text-chalk px-4 py-3 text-[13.5px]">{r.code}</td>
                        <td className="legend text-mute px-4 py-3">{r.type}</td>
                        <td className="num text-signal px-4 py-3 text-[13.5px]">{r.type === "percent" ? `${r.value}%` : `₹${r.value}`}</td>
                        <td className="num text-mute px-4 py-3 text-[12.5px]">{r.used} / {r.maxUses || "∞"}</td>
                        <td className="px-4 py-3">{r.active ? <Badge tone="ok">ACTIVE</Badge> : <Badge tone="warn">DISABLED</Badge>}</td>
                      </>
                    )}
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => setEditing({ kind, row: { ...r } })}
                          className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5"
                          aria-label="Edit"
                        >
                          <Pencil size={13} />
                        </button>
                        <button
                          onClick={() => setRemove({ kind, row: r })}
                          className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5"
                          aria-label="Delete"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </Table>
            )}
          </section>
        ))}
      </div>

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={`${editing?.isNew ? "New" : "Edit"} ${editing?.kind?.slice(0, -1) ?? ""}`}
        footer={
          <>
            <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn onClick={save} disabled={busy}>{busy ? "SAVING…" : "Save"}</Btn>
          </>
        }
      >
        {editing && (
          <div className="grid gap-4">
            {editing.kind === "testimonials" && (
              <>
                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="NAME" required><input value={editing.row.name} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, name: e.target.value } })} className={input} /></Field>
                  <Field label="ROLE"><input value={editing.row.role ?? ""} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, role: e.target.value } })} className={input} /></Field>
                  <Field label="COMPANY"><input value={editing.row.company ?? ""} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, company: e.target.value } })} className={input} /></Field>
                  <Field label="RATING (1-5)"><input type="number" min={1} max={5} value={editing.row.rating} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, rating: Number(e.target.value) } })} className={input} /></Field>
                </div>
                <Field label="QUOTE" required><textarea rows={4} value={editing.row.quote} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, quote: e.target.value } })} className={input} /></Field>
                <Toggle checked={editing.row.active} onChange={(v) => setEditing({ ...editing, row: { ...editing.row, active: v } })} label="Visible on storefront" />
              </>
            )}
            {editing.kind === "faqs" && (
              <>
                <Field label="QUESTION" required><input value={editing.row.question} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, question: e.target.value } })} className={input} /></Field>
                <Field label="ANSWER" required><textarea rows={4} value={editing.row.answer} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, answer: e.target.value } })} className={input} /></Field>
                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="GROUP"><input value={editing.row.group} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, group: e.target.value } })} className={input} /></Field>
                  <Field label="DISPLAY ORDER"><input type="number" value={editing.row.sortOrder} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, sortOrder: Number(e.target.value) } })} className={input} /></Field>
                </div>
                <Toggle checked={editing.row.active} onChange={(v) => setEditing({ ...editing, row: { ...editing.row, active: v } })} label="Visible on storefront" />
              </>
            )}
            {editing.kind === "coupons" && (
              <>
                <div className="grid gap-4 md:grid-cols-2">
                  <Field label="CODE" required><input value={editing.row.code} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, code: e.target.value.toUpperCase() } })} className={`${input} font-mono uppercase`} /></Field>
                  <Field label="TYPE">
                    <select value={editing.row.type} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, type: e.target.value } })} className={input}>
                      <option value="percent">Percentage</option>
                      <option value="fixed">Fixed amount</option>
                    </select>
                  </Field>
                  <Field label="VALUE"><input type="number" value={editing.row.value} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, value: e.target.value } })} className={input} /></Field>
                  <Field label="MAX USES (0 = UNLIMITED)"><input type="number" value={editing.row.maxUses ?? 0} onChange={(e) => setEditing({ ...editing, row: { ...editing.row, maxUses: Number(e.target.value) } })} className={input} /></Field>
                </div>
                <Toggle checked={editing.row.active} onChange={(v) => setEditing({ ...editing, row: { ...editing.row, active: v } })} label="Active" />
              </>
            )}
          </div>
        )}
      </Modal>

      <Confirm
        open={Boolean(remove)}
        onClose={() => setRemove(null)}
        busy={busy}
        title="Delete record"
        body="This removes the record from the public site immediately. This cannot be undone."
        onConfirm={doDelete}
      />
    </div>
  );
}
