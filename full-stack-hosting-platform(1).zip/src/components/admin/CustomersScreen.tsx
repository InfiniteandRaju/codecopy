"use client";

import { useEffect, useMemo, useState } from "react";
import { Wallet, Ban, RotateCcw, Mail } from "lucide-react";
import {
  PageHead, Btn, Modal, Field, input, Toolbar, Table, Badge, Empty, useApi, Confirm,
} from "@/components/admin/kit";

export function CustomersScreen() {
  const api = useApi();
  const [rows, setRows] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [wallet, setWallet] = useState<any>(null);
  const [amount, setAmount] = useState(500);
  const [kind, setKind] = useState<"credit" | "debit">("credit");
  const [note, setNote] = useState("");
  const [suspend, setSuspend] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const [c, o] = await Promise.all([api.get("/api/admin/customers"), api.get("/api/admin/orders")]);
      setRows(c.rows);
      setOrders(o.rows);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(
    () =>
      rows.filter(
        (c) => c.name.toLowerCase().includes(search.toLowerCase()) || (c.email ?? "").toLowerCase().includes(search.toLowerCase()),
      ),
    [rows, search],
  );

  const adjust = async () => {
    setBusy(true);
    try {
      const res = await api.post("/api/admin/actions", {
        action: "adjust_wallet",
        userId: wallet.id,
        amount,
        kind,
        note,
      });
      api.toast(`${kind === "credit" ? "Credited" : "Debited"} ₹${amount} — new balance ₹${Number(res.balance).toLocaleString("en-IN")}`);
      setWallet(null);
      setNote("");
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const customerOrders = profile ? orders.filter((o) => o.email === profile.email) : [];

  return (
    <div>
      <PageHead title="Customers" subtitle="Account status, wallet balance, order count and auditable wallet adjustments. Every adjustment requires an audit note." />

      <Toolbar search={search} onSearch={setSearch} placeholder="Name or email…">
        <span className="legend text-mute">{filtered.length} ACCOUNTS</span>
      </Toolbar>

      {filtered.length === 0 ? (
        <Empty title="No customers found" />
      ) : (
        <Table head={["CUSTOMER", "EMAIL", "REGISTERED", "WALLET", "ORDERS", "STATUS", "ACTIONS"]}>
          {filtered.map((c) => (
            <tr key={c.id} className="border-line hover:bg-raised/50 border-b last:border-0">
              <td className="px-4 py-3">
                <div className="flex items-center gap-2.5">
                  <span className="bg-signal/15 text-signal legend flex h-8 w-8 items-center justify-center border border-signal/30">
                    {c.name.slice(0, 1)}
                  </span>
                  <span className="text-chalk text-[13.5px]">{c.name}</span>
                </div>
              </td>
              <td className="text-mute px-4 py-3 text-[13px]">{c.email}</td>
              <td className="num text-mute px-4 py-3 text-[11.5px]">{new Date(c.createdAt).toLocaleDateString("en-IN")}</td>
              <td className="num text-link px-4 py-3 text-[13.5px]">₹{Number(c.balance).toLocaleString("en-IN")}</td>
              <td className="num text-fore px-4 py-3 text-[13px]">{c.orderCount}</td>
              <td className="px-4 py-3">{c.status === "active" ? <Badge tone="ok">ACTIVE</Badge> : <Badge tone="bad">SUSPENDED</Badge>}</td>
              <td className="px-4 py-3">
                <div className="flex gap-1.5">
                  <button
                    onClick={() => { setWallet(c); setNote(""); }}
                    className="border-line text-mute hover:text-link hover:border-link/40 border p-1.5"
                    aria-label="Adjust wallet"
                  >
                    <Wallet size={13} />
                  </button>
                  <button
                    onClick={() => setProfile(c)}
                    className="border-line text-mute hover:text-fore border p-1.5"
                    aria-label="View orders"
                  >
                    <Mail size={13} />
                  </button>
                  <button
                    onClick={() => setSuspend(c)}
                    className={`border p-1.5 ${c.status === "active" ? "border-signal/40 text-signal hover:bg-signal/10" : "border-led/40 text-led hover:bg-led/10"}`}
                    aria-label="Toggle account"
                  >
                    <Ban size={13} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </Table>
      )}

      <Modal
        open={Boolean(wallet)}
        onClose={() => setWallet(null)}
        title={`Wallet · ${wallet?.name ?? ""}`}
        footer={
          <>
            <Btn variant="ghost" onClick={() => setWallet(null)}>Cancel</Btn>
            <Btn onClick={adjust} disabled={busy || note.trim().length < 5}>
              {busy ? "WRITING LEDGER…" : "APPLY ADJUSTMENT"}
            </Btn>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <div className="border-line bg-raised/60 flex items-center justify-between border p-4">
            <span className="legend text-mute">CURRENT BALANCE</span>
            <span className="num text-chalk text-[20px] font-semibold">₹{Number(wallet?.balance ?? 0).toLocaleString("en-IN")}</span>
          </div>
          <div className="flex gap-2">
            {(["credit", "debit"] as const).map((k) => (
              <button
                key={k}
                onClick={() => setKind(k)}
                className={`legend flex-1 border px-3 py-2.5 transition-all ${
                  kind === k ? "border-signal/70 bg-signal/10 text-signal" : "border-line text-mute hover:border-line-2"
                }`}
              >
                {k === "credit" ? "CREDIT WALLET" : "DEBIT WALLET"}
              </button>
            ))}
          </div>
          <Field label="AMOUNT" required>
            <input type="number" min={1} value={amount} onChange={(e) => setAmount(Number(e.target.value))} className={input} />
          </Field>
          <Field
            label="AUDIT NOTE (MANDATORY)"
            required
            hint="RECORDED AGAINST YOUR ADMIN ID IN THE ACTIVITY LOG AND THE WALLET LEDGER"
          >
            <textarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} className={input} placeholder="Goodwill credit after provisioning delay on ORD…" />
          </Field>
          <p className="legend text-mute">WRITES TO wallet_transactions WITH ROW LOCKING — NO DOUBLE SPEND, NO RACE.</p>
        </div>
      </Modal>

      <Modal
        open={Boolean(profile)}
        onClose={() => setProfile(null)}
        title={`Orders · ${profile?.name ?? ""}`}
        footer={<Btn variant="ghost" onClick={() => setProfile(null)}>Close</Btn>}
      >
        {customerOrders.length === 0 ? (
          <p className="text-mute text-[13.5px]">No orders for this customer yet.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {customerOrders.map((o) => (
              <div key={o.id} className="border-line bg-raised/50 flex items-center justify-between gap-3 border p-3">
                <div>
                  <div className="text-chalk text-[13.5px]">{o.planName}</div>
                  <div className="num text-mute text-[11.5px]">{o.reference} · {new Date(o.createdAt).toLocaleDateString("en-IN")}</div>
                </div>
                <div className="text-right">
                  <div className="num text-fore text-[13.5px]">₹{Number(o.total).toLocaleString("en-IN")}</div>
                  <Badge tone={["paid", "active"].includes(o.status) ? "ok" : "warn"}>{String(o.status).replace("_", " ")}</Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </Modal>

      <Confirm
        open={Boolean(suspend)}
        onClose={() => setSuspend(null)}
        busy={busy}
        title={suspend?.status === "active" ? "Suspend account" : "Reactivate account"}
        body={
          suspend?.status === "active"
            ? `Suspend ${suspend?.email}? They will be signed out and blocked from signing in. Existing orders are untouched.`
            : `Reactivate ${suspend?.email}? They will be able to sign in again.`
        }
        onConfirm={async () => {
          const target = suspend;
          if (!target) return;
          setBusy(true);
          try {
            await api.post("/api/admin/actions", { action: "suspend_customer", id: target.id });
            api.toast("Account status updated.");
            setSuspend(null);
            load();
          } catch {
            /* toast */
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}
