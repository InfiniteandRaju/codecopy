"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, Save, ImagePlus, ChevronUp, ChevronDown, Check } from "lucide-react";
import { PageHead, Btn, Field, input, Toggle, useApi, Badge, Confirm } from "@/components/admin/kit";

type FieldSpec =
  | { key: string; label: string; type: "text" | "textarea" | "color" | "image" }
  | { key: string; label: string; type: "object"; fields: { key: string; label: string; type: "text" | "textarea" }[] }
  | {
      key: string;
      label: string;
      type: "list";
      itemFields: { key: string; label: string; type: "text" | "textarea" | "number" | "icon" }[];
      make: () => any;
    };

const SECTIONS: { key: string; title: string; hint: string; spec: FieldSpec[] }[] = [
  {
    key: "hero",
    title: "Hero",
    hint: "The first screen: headline, description, buttons and background image.",
    spec: [
      { key: "eyebrow", label: "EYEBROW (MICRO LEGEND)", type: "text" },
      { key: "title", label: "HEADLINE (LINE BREAKS RENDER AS-IS)", type: "textarea" },
      { key: "description", label: "DESCRIPTION", type: "textarea" },
      { key: "image", label: "BACKGROUND IMAGE", type: "image" },
      {
        key: "primaryCta",
        label: "PRIMARY BUTTON",
        type: "object",
        fields: [
          { key: "label", label: "LABEL", type: "text" },
          { key: "href", label: "HREF", type: "text" },
        ],
      },
      {
        key: "secondaryCta",
        label: "SECONDARY BUTTON",
        type: "object",
        fields: [
          { key: "label", label: "LABEL", type: "text" },
          { key: "href", label: "HREF", type: "text" },
        ],
      },
    ],
  },
  {
    key: "whyUs",
    title: "Why choose us",
    hint: "Four operating principles shown as an asymmetric grid.",
    spec: [
      { key: "title", label: "SECTION TITLE", type: "text" },
      {
        key: "items",
        label: "ITEMS",
        type: "list",
        make: () => ({ icon: "zap", title: "", body: "" }),
        itemFields: [
          { key: "icon", label: "ICON (zap · shield · cpu · headphones)", type: "icon" },
          { key: "title", label: "TITLE", type: "text" },
          { key: "body", label: "BODY", type: "textarea" },
        ],
      },
    ],
  },
  {
    key: "locations",
    title: "Server locations",
    hint: "Regions and their latency readout.",
    spec: [
      { key: "title", label: "SECTION TITLE", type: "text" },
      { key: "description", label: "DESCRIPTION", type: "textarea" },
      {
        key: "items",
        label: "LOCATIONS",
        type: "list",
        make: () => ({ city: "", code: "", country: "", latency: 20, tier: "Edge" }),
        itemFields: [
          { key: "city", label: "CITY", type: "text" },
          { key: "code", label: "CODE", type: "text" },
          { key: "country", label: "COUNTRY", type: "text" },
          { key: "latency", label: "LATENCY MS", type: "number" },
          { key: "tier", label: "TIER (Core · Edge)", type: "text" },
        ],
      },
    ],
  },
  {
    key: "infrastructure",
    title: "Infrastructure specifications",
    hint: "Hardware list paired with the rack photograph.",
    spec: [
      { key: "title", label: "SECTION TITLE", type: "text" },
      { key: "description", label: "DESCRIPTION", type: "textarea" },
      { key: "image", label: "IMAGE", type: "image" },
      {
        key: "items",
        label: "SPEC ROWS",
        type: "list",
        make: () => ({ label: "", value: "" }),
        itemFields: [
          { key: "label", label: "LABEL", type: "text" },
          { key: "value", label: "VALUE", type: "text" },
        ],
      },
    ],
  },
  {
    key: "ddos",
    title: "DDoS protection band",
    hint: "Full-bleed band with four headline statistics.",
    spec: [
      { key: "title", label: "TITLE", type: "text" },
      { key: "description", label: "DESCRIPTION", type: "textarea" },
      { key: "image", label: "BACKGROUND IMAGE", type: "image" },
      {
        key: "stats",
        label: "STATISTICS",
        type: "list",
        make: () => ({ value: "", label: "" }),
        itemFields: [
          { key: "value", label: "VALUE", type: "text" },
          { key: "label", label: "LABEL", type: "text" },
        ],
      },
    ],
  },
  {
    key: "support",
    title: "Contact & support",
    hint: "Support block at the end of the homepage.",
    spec: [
      { key: "title", label: "TITLE", type: "text" },
      { key: "description", label: "DESCRIPTION", type: "textarea" },
      { key: "image", label: "IMAGE", type: "image" },
      { key: "email", label: "SUPPORT EMAIL", type: "text" },
      { key: "discord", label: "DISCORD URL", type: "text" },
      { key: "responseTime", label: "RESPONSE TIME LINE", type: "text" },
    ],
  },
];

const PLAN_MODES = [
  { key: "category", label: "Group by category" },
  { key: "featured", label: "Featured only" },
  { key: "manual", label: "Manual selection & order" },
];

/** Lets the admin choose which plans appear on the homepage, how many, and in what order. */
function PlansSectionEditor() {
  const api = useApi();
  const [cfg, setCfg] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const home = await api.get("/api/home");
      const [p, c] = await Promise.all([api.get("/api/admin/plans"), api.get("/api/admin/categories")]);
      setCfg({
        title: home.sections?.plansSection?.title ?? "Hosting plans, priced individually",
        description: home.sections?.plansSection?.description ?? "",
        mode: home.sections?.plansSection?.mode ?? "category",
        limit: home.sections?.plansSection?.limit ?? 12,
        perCategory: home.sections?.plansSection?.perCategory ?? 3,
        showSpecs: home.sections?.plansSection?.showSpecs ?? true,
        showTags: home.sections?.plansSection?.showTags ?? true,
        manualOrder: home.sections?.plansSection?.manualOrder ?? [],
        categoryOrder: home.sections?.plansSection?.categoryOrder ?? [],
        popularLimit: home.sections?.plansSection?.popularLimit ?? 6,
        pricingSections: home.sections?.plansSection?.pricingSections ?? [],
      });
      setPlans(p.rows);
      setCategories(c.rows.filter((x: any) => !x.parentId));
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!cfg) return <div className="legend text-mute border-line border border-dashed p-6 text-center">LOADING PLANS SECTION…</div>;

  const save = async () => {
    setBusy(true);
    try {
      await api.put("/api/admin/homepage/plansSection", { key: "plansSection", value: cfg });
      api.toast("Homepage pricing section saved — reflected immediately.");
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const move = (list: string[], id: string, dir: -1 | 1, apply: (next: string[]) => void) => {
    const idx = list.indexOf(id);
    const nextIdx = idx + dir;
    if (idx === -1 || nextIdx < 0 || nextIdx >= list.length) return;
    const next = [...list];
    [next[idx], next[nextIdx]] = [next[nextIdx], next[idx]];
    apply(next);
  };

  const manual = cfg.manualOrder ?? [];
  const catOrder = cfg.categoryOrder ?? [];

  return (
    <section className="panel p-5">
      <div className="border-line mb-4 flex flex-wrap items-center justify-between gap-3 border-b pb-4">
        <div>
          <h3 className="text-[15.5px] font-semibold">Plans & pricing</h3>
          <p className="text-mute mt-1 text-[12.5px]">Controls the individual product pricing cards on the homepage — selection, count and order.</p>
        </div>
        <Btn onClick={save} disabled={busy}>
          <Save size={13} /> {busy ? "SAVING…" : "Save section"}
        </Btn>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Field label="SECTION TITLE"><input value={cfg.title} onChange={(e) => setCfg({ ...cfg, title: e.target.value })} className={input} /></Field>
        <Field label="SELECTION MODE">
          <select value={cfg.mode} onChange={(e) => setCfg({ ...cfg, mode: e.target.value })} className={input}>
            {PLAN_MODES.map((m) => (
              <option key={m.key} value={m.key}>{m.label}</option>
            ))}
          </select>
        </Field>
        <div className="md:col-span-2">
          <Field label="SECTION DESCRIPTION"><textarea rows={2} value={cfg.description} onChange={(e) => setCfg({ ...cfg, description: e.target.value })} className={input} /></Field>
        </div>
        <Field label="MAXIMUM PLANS SHOWN">
          <input type="number" min={1} max={48} value={cfg.limit} onChange={(e) => setCfg({ ...cfg, limit: Number(e.target.value) })} className={input} />
        </Field>
        <Field label="PLANS PER CATEGORY" hint="ONLY FOR 'GROUP BY CATEGORY'">
          <input type="number" min={1} max={12} value={cfg.perCategory} onChange={(e) => setCfg({ ...cfg, perCategory: Number(e.target.value) })} className={input} />
        </Field>
        <div className="flex flex-wrap items-end gap-6 pb-2">
          <Toggle checked={cfg.showSpecs} onChange={(v) => setCfg({ ...cfg, showSpecs: v })} label="Show specifications" />
          <Toggle checked={cfg.showTags} onChange={(v) => setCfg({ ...cfg, showTags: v })} label="Show promotional tags" />
        </div>
        <Field label="POPULAR PLANS SHOWN" hint="SIZE OF THE 'POPULAR HOSTING PLANS' BAND">
          <input
            type="number"
            min={0}
            max={24}
            value={cfg.popularLimit}
            onChange={(e) => setCfg({ ...cfg, popularLimit: Number(e.target.value) })}
            className={input}
          />
        </Field>
      </div>

      <div className="border-line mt-5 border-t pt-4">
        <div className="legend text-signal mb-3">PRICING BANDS (GAME · BOT · VPS · WEB)</div>
        <p className="text-mute mb-3 text-[12.5px]">
          Each band renders real products from the chosen root category. Reorder, retitle, re-point or disable them — the
          homepage adapts without any code change.
        </p>
        <div className="flex flex-col gap-3">
          {(cfg.pricingSections ?? []).map((band: any, i: number) => {
            const move = (dir: -1 | 1) => {
              const list = [...cfg.pricingSections];
              const j = i + dir;
              if (j < 0 || j >= list.length) return;
              [list[i], list[j]] = [list[j], list[i]];
              setCfg({ ...cfg, pricingSections: list });
            };
            const patch = (p: any) =>
              setCfg({ ...cfg, pricingSections: cfg.pricingSections.map((b: any, j: number) => (j === i ? { ...b, ...p } : b)) });
            return (
              <div key={band.id ?? i} className="border-line grid gap-3 border p-3 md:grid-cols-12">
                <div className="md:col-span-4">
                  <Field label="BAND TITLE">
                    <input value={band.title} onChange={(e) => patch({ title: e.target.value })} className={input} />
                  </Field>
                </div>
                <div className="md:col-span-4">
                  <Field label="ROOT CATEGORY">
                    <select value={band.categorySlug} onChange={(e) => patch({ categorySlug: e.target.value })} className={input}>
                      <option value="">— select —</option>
                      {categories.map((c: any) => (
                        <option key={c.id} value={c.slug}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>
                <div className="md:col-span-2">
                  <Field label="PLANS">
                    <input
                      type="number"
                      min={1}
                      max={12}
                      value={band.limit}
                      onChange={(e) => patch({ limit: Number(e.target.value) })}
                      className={input}
                    />
                  </Field>
                </div>
                <div className="flex items-center justify-between gap-2 md:col-span-2">
                  <Toggle checked={band.enabled !== false} onChange={(v) => patch({ enabled: v })} label="Show" />
                  <div className="flex gap-1">
                    <button onClick={() => move(-1)} className="text-mute hover:text-fore p-1" aria-label="Move up"><ChevronUp size={13} /></button>
                    <button onClick={() => move(1)} className="text-mute hover:text-fore p-1" aria-label="Move down"><ChevronDown size={13} /></button>
                    <button
                      onClick={() => setCfg({ ...cfg, pricingSections: cfg.pricingSections.filter((_: any, j: number) => j !== i) })}
                      className="text-mute hover:text-signal p-1"
                      aria-label="Remove band"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          {(cfg.pricingSections ?? []).length === 0 && (
            <p className="text-mute text-[13px]">No pricing bands — add one to group products by category.</p>
          )}
          <Btn
            variant="ghost"
            onClick={() =>
              setCfg({
                ...cfg,
                pricingSections: [
                  ...(cfg.pricingSections ?? []),
                  { id: `band${(cfg.pricingSections ?? []).length + 1}`, title: "New pricing band", categorySlug: "", limit: 3, enabled: true },
                ],
              })
            }
          >
            <Plus size={13} /> Add pricing band
          </Btn>
        </div>
      </div>

      {cfg.mode === "manual" && (
        <div className="border-line mt-5 border-t pt-4">
          <div className="legend text-signal mb-3">SELECT & ORDER PLANS ({manual.length} SELECTED)</div>
          <div className="max-h-[360px] overflow-y-auto thin-scroll">
            {plans.map((p) => {
              const on = manual.includes(p.id);
              return (
                <div key={p.id} className="border-line flex items-center gap-3 border-b py-2 last:border-0">
                  <button
                    onClick={() =>
                      setCfg({
                        ...cfg,
                        manualOrder: on ? manual.filter((x: string) => x !== p.id) : [...manual, p.id],
                      })
                    }
                    className={`flex h-4 w-4 shrink-0 items-center justify-center border ${on ? "border-signal bg-signal text-void" : "border-line-2"}`}
                    aria-label={on ? "Remove from homepage" : "Add to homepage"}
                  >
                    {on && <Check size={11} />}
                  </button>
                  <span className="num text-mute w-6 text-[11px]">{on ? manual.indexOf(p.id) + 1 : "–"}</span>
                  <span className="flex-1 truncate text-[13.5px] text-fore">{p.name}</span>
                  <span className="legend text-mute">{p.categoryName ?? "—"}</span>
                  <div className="flex gap-1">
                    <button onClick={() => move(manual, p.id, -1, (next) => setCfg({ ...cfg, manualOrder: next }))} className="text-mute hover:text-fore p-1" aria-label="Move up"><ChevronUp size={13} /></button>
                    <button onClick={() => move(manual, p.id, 1, (next) => setCfg({ ...cfg, manualOrder: next }))} className="text-mute hover:text-fore p-1" aria-label="Move down"><ChevronDown size={13} /></button>
                  </div>
                </div>
              );
            })}
            {plans.length === 0 && <p className="text-mute text-[13px]">No plans in the catalogue yet.</p>}
          </div>
        </div>
      )}

      {cfg.mode === "category" && (
        <div className="border-line mt-5 border-t pt-4">
          <div className="legend text-signal mb-3">CATEGORY ORDER</div>
          <div className="flex flex-wrap gap-2">
            {[...catOrder, ...categories.map((c: any) => c.id).filter((id: string) => !catOrder.includes(id))].map((id) => {
              const cat = categories.find((c: any) => c.id === id);
              if (!cat) return null;
              return (
                <span key={id} className="border-line bg-raised/50 flex items-center gap-1 border px-2 py-1 text-[12.5px] text-fore">
                  {cat.name}
                  <button onClick={() => move(catOrder.length ? catOrder : categories.map((c: any) => c.id), id, -1, (next) => setCfg({ ...cfg, categoryOrder: next }))} className="text-mute hover:text-signal" aria-label="Move up"><ChevronUp size={12} /></button>
                  <button onClick={() => move(catOrder.length ? catOrder : categories.map((c: any) => c.id), id, 1, (next) => setCfg({ ...cfg, categoryOrder: next }))} className="text-mute hover:text-signal" aria-label="Move down"><ChevronDown size={12} /></button>
                </span>
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
}

export function HomepageScreen() {
  const api = useApi();
  const [data, setData] = useState<Record<string, any> | null>(null);
  const [dirty, setDirty] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const home = await api.get("/api/home");
      setData(home.sections);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!data) return <div className="legend text-mute py-20 text-center">LOADING HOMEPAGE SECTIONS…</div>;

  const update = (sectionKey: string, patch: any) => {
    setData((d) => ({ ...d!, [sectionKey]: { ...d![sectionKey], ...patch } }));
    setDirty(sectionKey);
  };

  const save = async (sectionKey: string) => {
    setBusy(true);
    try {
      await api.put(`/api/admin/homepage/${sectionKey}`, { key: sectionKey, value: data![sectionKey] });
      api.toast(`${sectionKey} saved — the storefront updates on next render.`);
      setDirty(null);
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const renderSpec = (sectionKey: string, spec: FieldSpec) => {
    const value = data![sectionKey] ?? {};
    if (spec.type === "text" || spec.type === "textarea" || spec.type === "image" || spec.type === "color") {
      return (
        <Field key={spec.key} label={spec.label}>
          {spec.type === "textarea" ? (
            <textarea rows={4} value={value[spec.key] ?? ""} onChange={(e) => update(sectionKey, { [spec.key]: e.target.value })} className={input} />
          ) : spec.type === "image" ? (
            <div className="flex gap-2">
              <input value={value[spec.key] ?? ""} onChange={(e) => update(sectionKey, { [spec.key]: e.target.value })} className={input} placeholder="/images/hero-aisle.jpg" />
              <label className="border-line text-mute hover:text-fore flex cursor-pointer items-center gap-2 border px-3 py-2 text-[12px]">
                <ImagePlus size={13} />
                <input
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    if (f.size > 1_500_000) return api.toast("Image must be under 1.5 MB.", "err");
                    const reader = new FileReader();
                    reader.onload = () => update(sectionKey, { [spec.key]: String(reader.result) });
                    reader.readAsDataURL(f);
                  }}
                />
              </label>
            </div>
          ) : (
            <input value={value[spec.key] ?? ""} onChange={(e) => update(sectionKey, { [spec.key]: e.target.value })} className={input} />
          )}
          {spec.type === "image" && String(value[spec.key] ?? "").startsWith("data:image") && (
            <img src={value[spec.key]} alt="" className="mt-2 h-24 border border-line object-cover" />
          )}
        </Field>
      );
    }

    if (spec.type === "object") {
      const obj = value[spec.key] ?? {};
      return (
        <div key={spec.key} className="border-line bg-raised/50 border p-4">
          <div className="legend text-signal mb-3">{spec.label}</div>
          <div className="grid gap-3 md:grid-cols-2">
            {spec.fields.map((f) => (
              <Field key={f.key} label={f.label}>
                <input
                  value={obj[f.key] ?? ""}
                  onChange={(e) => update(sectionKey, { [spec.key]: { ...obj, [f.key]: e.target.value } })}
                  className={input}
                />
              </Field>
            ))}
          </div>
        </div>
      );
    }

    // list
    const listSpec = spec as Extract<FieldSpec, { type: "list" }>;
    const list: any[] = value[listSpec.key] ?? [];
    return (
      <div key={listSpec.key} className="border-line border p-4">
        <div className="mb-3 flex items-center justify-between">
          <span className="legend text-signal">{listSpec.label}</span>
          <Badge tone="mute">{list.length} ROWS</Badge>
        </div>
        <div className="flex flex-col gap-3">
          {list.map((item, i) => (
            <div key={i} className="border-line bg-raised/40 relative border p-3">
              <div className="grid gap-3 md:grid-cols-2">
                {listSpec.itemFields.map((f) => (
                  <Field key={f.key} label={f.label}>
                    {f.type === "textarea" ? (
                      <textarea
                        rows={2}
                        value={String(item[f.key] ?? "")}
                        onChange={(e) => {
                          const next = [...list];
                          next[i] = { ...item, [f.key]: e.target.value };
                          update(sectionKey, { [spec.key]: next });
                        }}
                        className={input}
                      />
                    ) : (
                      <input
                        value={String(item[f.key] ?? "")}
                        onChange={(e) => {
                          const next = [...list];
                          next[i] = { ...item, [f.key]: f.type === "number" ? Number(e.target.value) : e.target.value };
                          update(sectionKey, { [spec.key]: next });
                        }}
                        className={input}
                      />
                    )}
                  </Field>
                ))}
              </div>
              <button
                onClick={() => update(sectionKey, { [spec.key]: list.filter((_, j) => j !== i) })}
                className="text-mute hover:text-signal absolute top-2 right-2"
                aria-label="Remove row"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
        <Btn variant="ghost" className="mt-3" onClick={() => update(sectionKey, { [listSpec.key]: [...list, listSpec.make()] })}>
          <Plus size={13} /> Add row
        </Btn>
      </div>
    );
  };

  return (
    <div>
      <PageHead
        title="Homepage editor"
        subtitle="Every headline, button, image, statistic and list on the home screen. Save and the storefront reflects it on the next render — no code changes, no rebuild."
      />

      <div className="flex flex-col gap-6">
        <PlansSectionEditor />
        {SECTIONS.map((section) => (
          <section key={section.key} className="panel p-5">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-line border-b pb-4">
              <div>
                <h3 className="text-[15.5px] font-semibold">{section.title}</h3>
                <p className="text-mute mt-1 text-[12.5px]">{section.hint}</p>
              </div>
              <div className="flex items-center gap-3">
                {dirty === section.key && <Badge tone="warn">UNSAVED</Badge>}
                <Btn onClick={() => save(section.key)} disabled={busy}>
                  <Save size={13} /> {busy && dirty === section.key ? "SAVING…" : "Save section"}
                </Btn>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">{section.spec.map((s) => renderSpec(section.key, s))}</div>
          </section>
        ))}
      </div>
    </div>
  );
}
