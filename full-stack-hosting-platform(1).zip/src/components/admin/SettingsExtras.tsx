"use client";

import { useEffect, useState } from "react";
import { Upload, Trash2, Save, Loader2, ShieldCheck, RefreshCw, CheckCircle2, XCircle } from "lucide-react";
import { PageHead, Btn, Field, input, Toggle, useApi, Badge } from "@/components/admin/kit";
import { useToast } from "@/components/ui/Toast";

const MAX_IMAGE = 1_200_000;

function useImageField(label: string, hint?: string) {
  const { push } = useToast();
  const pick = (current: string | null, onSet: (v: string | null) => void) => (
    <div className="flex flex-wrap items-center gap-3">
      <label className="border-line text-fore hover:border-signal/50 flex cursor-pointer items-center gap-2 border px-3 py-2.5 text-[13px]">
        <Upload size={13} className="text-signal" /> Upload
        <input
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            if (f.size > MAX_IMAGE) return push("Image must be under 1.2 MB.", "err");
            const reader = new FileReader();
            reader.onload = () => onSet(String(reader.result));
            reader.readAsDataURL(f);
          }}
        />
      </label>
      {current && (
        <button onClick={() => onSet(null)} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-2.5" aria-label={`Remove ${label}`}>
          <Trash2 size={13} />
        </button>
      )}
      {current && (
        <span className="border-line border bg-white p-1">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={current} alt={label} className="h-9 w-auto max-w-[180px] object-contain" />
        </span>
      )}
      {!current && <span className="legend text-mute/70">USING DEFAULT MARK</span>}
    </div>
  );
  return pick;
}

/* -------------------------------- branding -------------------------------- */
export function BrandingTab() {
  const api = useApi();
  const [b, setB] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const field = useImageField("logo");

  const load = async () => {
    try {
      const home = await api.get("/api/home");
      const branding = home.settings?.branding ?? {};
      setB({
        siteName: branding.siteName || home.settings?.siteName || "",
        wordmark: branding.wordmark || home.settings?.logoText || "",
        submark: branding.submark || "NODE · INFRA",
        logo: branding.logo ?? null,
        logoLight: branding.logoLight ?? null,
        logoDark: branding.logoDark ?? null,
        favicon: branding.favicon ?? null,
        logoWidth: branding.logoWidth ?? 132,
        logoHeight: branding.logoHeight ?? 34,
      });
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!b) return <div className="legend text-mute py-12 text-center">LOADING BRANDING…</div>;

  const save = async () => {
    setBusy(true);
    try {
      await api.put("/api/admin/settings/branding", { key: "branding", value: b });
      api.toast("Branding saved — reflected across the site, dashboards and favicon.");
      window.location.reload();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const set = (patch: any) => setB((prev: any) => ({ ...prev, ...patch }));

  return (
    <div className="flex flex-col gap-5">
      <section className="panel p-5">
        <div className="border-line mb-4 flex flex-wrap items-center justify-between gap-3 border-b pb-4">
          <div>
            <h3 className="text-[15.5px] font-semibold">Identity</h3>
            <p className="text-mute mt-1 text-[12.5px]">Used by the navigation, footer, login, customer dashboard, admin console and browser tab.</p>
          </div>
          <Btn onClick={save} disabled={busy}>
            <Save size={13} /> {busy ? "SAVING…" : "Save branding"}
          </Btn>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Field label="WEBSITE NAME" required>
            <input value={b.siteName} onChange={(e) => set({ siteName: e.target.value })} className={input} />
          </Field>
          <Field label="TAGLINE">
            <input value={b.tagline ?? ""} onChange={(e) => set({ tagline: e.target.value })} className={input} />
          </Field>
          <Field label="WORDMARK (WHEN NO LOGO IMAGE)" hint="TEXT BESIDE THE SVG MARK">
            <input value={b.wordmark} onChange={(e) => set({ wordmark: e.target.value })} className={input} />
          </Field>
          <Field label="SUB-MARK">
            <input value={b.submark} onChange={(e) => set({ submark: e.target.value })} className={input} />
          </Field>
          <Field label="LOGO WIDTH (PX)">
            <input type="number" min={40} max={320} value={b.logoWidth} onChange={(e) => set({ logoWidth: Number(e.target.value) })} className={input} />
          </Field>
          <Field label="LOGO HEIGHT (PX)">
            <input type="number" min={16} max={96} value={b.logoHeight} onChange={(e) => set({ logoHeight: Number(e.target.value) })} className={input} />
          </Field>
        </div>
      </section>

      <section className="panel p-5">
        <div className="border-line mb-4 border-b pb-4">
          <h3 className="text-[15.5px] font-semibold">Logo images</h3>
          <p className="text-mute mt-1 text-[12.5px]">Uploaded images are stored centrally and rendered everywhere — no component hardcodes a logo path.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <Field label="PRIMARY LOGO (DARK SURFACES)">
            {field(b.logo, (v) => set({ logo: v }))}
          </Field>
          <Field label="LIGHT-THEME LOGO">{field(b.logoLight, (v) => set({ logoLight: v }))}</Field>
          <Field label="DARK-THEME LOGO">{field(b.logoDark, (v) => set({ logoDark: v }))}</Field>
          <Field label="FAVICON" hint="PNG OR SVG UP TO 1.2 MB · APPLIED TO THE BROWSER TAB SITE-WIDE">
            {field(b.favicon, (v) => set({ favicon: v }))}
          </Field>
        </div>
        <div className="border-line mt-5 border-t pt-4">
          <div className="legend text-mute mb-2">PREVIEW</div>
          <div className="bg-void border-line flex items-center gap-4 border p-4">
            {b.logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={b.logo} alt="Logo preview" style={{ height: b.logoHeight, width: "auto" }} className="object-contain" />
            ) : (
              <span className="text-chalk font-display text-[15px] font-bold">{b.wordmark || "LOGO"}</span>
            )}
            <span className="legend text-mute">
              {b.logoWidth}×{b.logoHeight} · {b.logo ? "IMAGE" : "SVG MARK FALLBACK"}
            </span>
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <Btn onClick={save} disabled={busy}>
            <Save size={13} /> {busy ? "SAVING…" : "Save branding"}
          </Btn>
        </div>
      </section>
    </div>
  );
}

/* ------------------------------- console tab ------------------------------ */
export function ConsoleIntegrationTab() {
  const api = useApi();
  const [form, setForm] = useState<any>(null);
  const [status, setStatus] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const [st] = await Promise.all([api.get("/api/admin/console")]);
      setStatus(st.status);
      setForm((prev: any) => ({
        ...(prev ?? {}),
        enabled: st.status?.configured ? true : false,
        baseUrl: st.status?.baseUrl ? (st.status.baseUrl.startsWith("http") ? st.status.baseUrl : `https://${st.status.baseUrl}`) : "",
        token: "",
        serversPath: "/api/client/servers",
        commandPath: "/command",
        logPath: "/logs",
        resourcePath: "/resources",
        timeoutMs: 8000,
        tokenSet: Boolean(st.status?.configured),
      }));
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!form) return <div className="legend text-mute py-12 text-center">LOADING INTEGRATION…</div>;

  const save = async () => {
    setBusy(true);
    try {
      const data = await api.post("/api/admin/console", { action: "configure", ...form, token: form.token || undefined });
      setStatus(data.status);
      api.toast(data.status.connected ? "Console integration connected." : "Saved — connection still failing.", data.status.connected ? "ok" : "err");
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-5">
      <section className="panel p-5">
        <div className="border-line mb-4 flex flex-wrap items-center justify-between gap-3 border-b pb-4">
          <div>
            <h3 className="text-[15.5px] font-semibold">Server-management API</h3>
            <p className="text-mute mt-1 max-w-2xl text-[12.5px]">
              The console executes real commands against this API (Pterodactyl client API, Wings, or any compatible
              panel). The bearer token is encrypted at rest and never returned to the browser.
            </p>
          </div>
          <Badge tone={status?.connected ? "ok" : status?.configured ? "warn" : "mute"}>
            {status?.connected ? "CONNECTED" : status?.configured ? "UNREACHABLE" : "NOT CONFIGURED"}
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Field label="BASE URL" required>
            <input value={form.baseUrl} onChange={(e) => setForm({ ...form, baseUrl: e.target.value })} className={`${input} font-mono`} placeholder="https://panel.example.com" />
          </Field>
          <Field label="API TOKEN" hint={form.tokenSet ? "STORED (ENCRYPTED) — LEAVE BLANK TO KEEP" : "REQUIRED"}>
            <input type="password" value={form.token} onChange={(e) => setForm({ ...form, token: e.target.value })} className={input} placeholder="••••••••••••" autoComplete="off" />
          </Field>
          <Field label="SERVERS PATH">
            <input value={form.serversPath} onChange={(e) => setForm({ ...form, serversPath: e.target.value })} className={`${input} font-mono`} />
          </Field>
          <Field label="COMMAND PATH (SUFFIX)">
            <input value={form.commandPath} onChange={(e) => setForm({ ...form, commandPath: e.target.value })} className={`${input} font-mono`} />
          </Field>
          <Field label="LOG PATH (SUFFIX)">
            <input value={form.logPath} onChange={(e) => setForm({ ...form, logPath: e.target.value })} className={`${input} font-mono`} />
          </Field>
          <Field label="RESOURCE PATH (SUFFIX)">
            <input value={form.resourcePath} onChange={(e) => setForm({ ...form, resourcePath: e.target.value })} className={`${input} font-mono`} />
          </Field>
          <Field label="TIMEOUT (MS)">
            <input type="number" min={2000} max={30000} step={500} value={form.timeoutMs} onChange={(e) => setForm({ ...form, timeoutMs: Number(e.target.value) })} className={input} />
          </Field>
          <div className="flex items-end pb-2">
            <Toggle checked={form.enabled} onChange={(v) => setForm({ ...form, enabled: v })} label="Enable console integration" />
          </div>
        </div>

        <div className="border-line mt-5 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
          <span className="legend text-mute">TOKENS NEVER LEAVE THE SERVER</span>
          <Btn onClick={save} disabled={busy}>
            {busy ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />} Save & connect
          </Btn>
        </div>
      </section>

      <section className="panel p-5">
        <span className="legend text-signal mb-3 block">CONNECTION STATUS</span>
        <p className="text-fore text-[13.5px]">{status?.message ?? "—"}</p>
        {status?.servers?.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {status.servers.slice(0, 12).map((s: any) => (
              <span key={s.id} className="border-line text-fore border px-2.5 py-1 text-[12px]">
                {s.name}
              </span>
            ))}
          </div>
        )}
        <div className="mt-4">
          <Btn variant="ghost" onClick={load}>
            <RefreshCw size={12} /> Refresh
          </Btn>
        </div>
      </section>
    </div>
  );
}

/* ------------------------------- database tab ----------------------------- */
type DbForm = {
  provider: string;
  projectUrl: string;
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  ssl: string;
  anonKey: string;
  passwordSet?: boolean;
  configured?: boolean;
  appliedAt?: string | null;
  status?: string;
};

export function DatabaseTab({ isSuperAdmin }: { isSuperAdmin: boolean }) {
  const api = useApi();
  const { push } = useToast();
  const [form, setForm] = useState<DbForm | null>(null);
  const [meta, setMeta] = useState<any>(null);
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [action, setAction] = useState<string>("");

  const load = async () => {
    try {
      const data = await api.get("/api/admin/dbconfig");
      setMeta(data);
      setForm(data.current);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    if (!isSuperAdmin) return; // never request credentials without the role
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSuperAdmin]);

  if (!isSuperAdmin) {
    return (
      <div className="border-signal/40 bg-signal/8 border p-5">
        <p className="text-fore text-[14px]">
          Database configuration is restricted to the <strong>Super Admin</strong> role. Your session cannot access
          connection credentials.
        </p>
      </div>
    );
  }
  if (!form) return <div className="legend text-mute py-12 text-center">LOADING CONFIGURATION…</div>;

  const run = async (act: string) => {
    setBusy(true);
    setAction(act);
    setResult(null);
    try {
      const data = await api.post("/api/admin/dbconfig", { action: act, config: form });
      setResult(data.result ? { ...data.result, note: data.note ?? data.result?.message } : { ok: act !== "rollback" ? false : true, stage: "info", message: act === "rollback" ? "Rolled back." : "" });
      if (data.current) setForm(data.current);
      if (data.result && data.result.ok) push(act === "test" ? "Connection verified." : act === "apply" ? "Configuration validated, backed up and applied." : "Configuration saved.", "ok");
      else if (data.result) push(data.result.message, "err");
      if (act === "rollback" && data.rolledBack) push("Rolled back to the previous configuration.", "ok");
      load();
    } catch (e: any) {
      /* toast already shown with the API error */
    } finally {
      setBusy(false);
      setAction("");
    }
  };

  const set = (patch: Partial<DbForm>) => setForm((f) => ({ ...(f as DbForm), ...patch }));

  return (
    <div className="flex flex-col gap-5">
      <section className="panel p-5">
        <div className="border-line mb-4 flex flex-wrap items-center justify-between gap-3 border-b pb-4">
          <div>
            <h3 className="text-[15.5px] font-semibold">Database connection</h3>
            <p className="text-mute mt-1 max-w-2xl text-[12.5px]">
              Credentials are encrypted with AES-256-GCM in a private table — never in the public settings table and
              never sent to the browser. Every change is tested (TCP → authentication → schema) before it can be stored.
            </p>
          </div>
          <Badge tone={meta?.current?.configured ? "ok" : "mute"}>{meta?.current?.status ?? "NOT CONFIGURED"}</Badge>
        </div>

        <div className="border-line bg-raised/50 mb-4 grid gap-3 border p-4 sm:grid-cols-3">
          <div>
            <div className="legend text-mute text-[8.5px]">RUNNING PROVIDER</div>
            <div className="num text-fore mt-1">{meta?.live?.provider ?? "postgres"}</div>
          </div>
          <div>
            <div className="legend text-mute text-[8.5px]">ACTIVE HOST</div>
            <div className="num text-fore mt-1 truncate">{meta?.live?.host ?? "from DATABASE_URL"}</div>
          </div>
          <div>
            <div className="legend text-mute text-[8.5px]">SOURCE</div>
            <div className="num text-fore mt-1">{meta?.live?.configuredIn ?? "—"}</div>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Field label="PROVIDER" required>
            <select value={form.provider} onChange={(e) => set({ provider: e.target.value })} className={input}>
              <option value="postgres">PostgreSQL</option>
              <option value="supabase">Supabase (Postgres)</option>
              <option value="local">Local PostgreSQL</option>
              <option value="mysql">MySQL (reachability only)</option>
            </select>
          </Field>
          {form.provider === "supabase" && (
            <Field label="SUPABASE PROJECT URL" hint="HTTPS://XYZ.supabase.co — PUBLIC CLIENT URL, NOT THE SERVICE ROLE KEY">
              <input value={form.projectUrl ?? ""} onChange={(e) => set({ projectUrl: e.target.value })} className={`${input} font-mono`} placeholder="https://project.supabase.co" />
            </Field>
          )}
          <Field label="HOST" required>
            <input value={form.host ?? ""} onChange={(e) => set({ host: e.target.value })} className={`${input} font-mono`} placeholder="db.example.com" />
          </Field>
          <Field label="PORT" required>
            <input type="number" value={form.port ?? 5432} onChange={(e) => set({ port: Number(e.target.value) })} className={input} />
          </Field>
          <Field label="DATABASE NAME" required>
            <input value={form.database ?? ""} onChange={(e) => set({ database: e.target.value })} className={input} />
          </Field>
          <Field label="USERNAME" required>
            <input value={form.username ?? ""} onChange={(e) => set({ username: e.target.value })} className={input} autoComplete="off" />
          </Field>
          <Field label="PASSWORD" hint={form.passwordSet ? "STORED (ENCRYPTED) — LEAVE BLANK TO KEEP CURRENT" : "NOT SET"}>
            <input type="password" value={form.password ?? ""} onChange={(e) => set({ password: e.target.value })} className={input} placeholder="••••••••••••" autoComplete="new-password" />
          </Field>
          <Field label="SSL MODE">
            <select value={form.ssl ?? "require"} onChange={(e) => set({ ssl: e.target.value })} className={input}>
              <option value="require">require</option>
              <option value="prefer">prefer</option>
              <option value="disable">disable</option>
            </select>
          </Field>
          {form.provider === "supabase" && (
            <Field label="ANON (PUBLIC) KEY" hint="OPTIONAL PUBLIC CLIENT KEY — NEVER STORE THE SERVICE ROLE KEY HERE">
              <input value={form.anonKey ?? ""} onChange={(e) => set({ anonKey: e.target.value })} className={input} autoComplete="off" />
            </Field>
          )}
        </div>

        <div className="border-line mt-5 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
          <span className="legend text-mute">SUPER ADMIN ONLY · ALL PROCESSING SERVER-SIDE</span>
          <div className="flex flex-wrap gap-2">
            <Btn variant="ghost" onClick={() => run("test")} disabled={busy}>
              {busy && action === "test" ? <Loader2 size={13} className="animate-spin" /> : <ShieldCheck size={13} />} Test connection
            </Btn>
            <Btn variant="ghost" onClick={() => run("save")} disabled={busy}>
              {busy && action === "save" ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />} Save
            </Btn>
            <Btn onClick={() => run("apply")} disabled={busy}>
              {busy && action === "apply" ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />} Validate & apply
            </Btn>
            <Btn variant="danger" onClick={() => run("rollback")} disabled={busy || !meta?.current?.configured}>
              {busy && action === "rollback" ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />} Roll back
            </Btn>
          </div>
        </div>
      </section>

      {result && (
        <section className={`border p-5 ${result.ok ? "border-led/40 bg-led/8" : "border-signal/40 bg-signal/8"}`}>
          <div className="flex items-center gap-2">
            {result.ok ? <CheckCircle2 size={15} className="text-led" /> : <XCircle size={15} className="text-signal" />}
            <span className="legend">{result.ok ? "CONNECTION OK" : "FAILED"} · STAGE {String(result.stage ?? "").toUpperCase()}</span>
            {typeof result.latencyMs === "number" && <span className="legend text-mute">{result.latencyMs} MS</span>}
          </div>
          <p className="text-fore mt-2 text-[13.5px]">{result.message}</p>
          {result.tables && (
            <div className="mt-3 flex flex-wrap gap-2">
              {result.tables.map((t: any) => (
                <span key={t.name} className={`legend border px-2 py-0.5 ${t.present ? "border-led/40 text-led" : "border-signal/40 text-signal"}`}>
                  {t.name}
                </span>
              ))}
            </div>
          )}
        </section>
      )}

      <section className="panel p-5">
        <span className="legend text-signal mb-3 block">REQUIRED SCHEMA</span>
        <div className="flex flex-wrap gap-2">
          {(meta?.requiredTables ?? []).map((t: string) => (
            <span key={t} className="border-line text-mute border px-2.5 py-1 text-[12px]">
              {t}
            </span>
          ))}
        </div>
        <p className="text-mute mt-4 text-[12.5px] leading-relaxed">
          <strong className="text-fore">Deployment note:</strong> the running process holds its connection pool from{" "}
          <code className="num text-fore">DATABASE_URL</code> at boot. A new configuration is validated, encrypted and
          backed up here, and takes effect on the next application restart. If the new connection fails at boot, use
          <strong className="text-fore"> Roll back</strong> to restore the previous configuration. MySQL cannot host
          this deployment — the schema and ORM are PostgreSQL.
        </p>
      </section>
    </div>
  );
}
