"use client";

import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, XCircle, Image as ImageIcon, ShieldCheck } from "lucide-react";
import {
  PageHead, Btn, Modal, Field, input, Toolbar, Table, Badge, Empty, useApi, Confirm,
} from "@/components/admin/kit";

const TONE: Record<string, string> = {
  verified: "ok", pending: "warn", awaiting_verification: "warn",
  rejected: "bad", failed: "bad", refunded: "info",
};

export function PaymentsScreen() {
  const api = useApi();
  const [rows, setRows] = useState<any[]>([]);
  const [tab, setTab] = useState<"queue" | "all">("queue");
  const [search, setSearch] = useState("");
  const [approve, setApprove] = useState<any>(null);
  const [reject, setReject] = useState<any>(null);
  const [reason, setReason] = useState("");
  const [proof, setProof] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setRows((await api.get("/api/admin/payments")).rows);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return rows.filter((p) => {
      const inTab = tab === "all" || p.status === "awaiting_verification" || p.status === "pending";
      const match =
        p.reference.toLowerCase().includes(q) ||
        (p.orderRef ?? "").toLowerCase().includes(q) ||
        (p.customer ?? "").toLowerCase().includes(q) ||
        (p.externalId ?? "").toLowerCase().includes(q);
      return inTab && match;
    });
  }, [rows, tab, search]);

  const run = async (fn: () => Promise<any>, msg: string) => {
    try {
      await fn();
      api.toast(msg);
      load();
    } catch {
      /* toast */
    }
  };

  return (
    <div>
      <PageHead
        title="Payment verification"
        subtitle="A QR reference or screenshot never settles a payment on its own — verified here by an authorised finance or super admin."
        actions={
          <a href="/admin/settings" className="legend border-line text-fore hover:border-signal/50 hover:text-signal border px-4 py-2.5">
            <ShieldCheck size={13} className="mr-1 inline" /> PAYMENT SETTINGS
          </a>
        }
      />

      <div className="mb-4 flex gap-1.5">
        {(["queue", "all"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`legend border px-3.5 py-2 transition-all ${
              tab === t ? "border-signal/70 bg-signal/10 text-signal" : "border-line text-mute hover:border-line-2"
            }`}
          >
            {t === "queue" ? "VERIFICATION QUEUE" : "ALL PAYMENTS"}
          </button>
        ))}
      </div>

      <Toolbar search={search} onSearch={setSearch} placeholder="Payment ref, order ref, UTR…">
        <span className="legend text-mute">
          {filtered.filter((p) => p.status === "awaiting_verification").length} AWAITING REVIEW
        </span>
      </Toolbar>

      {filtered.length === 0 ? (
        <Empty title={tab === "queue" ? "Verification queue is clear" : "No payments recorded"} hint="Manual QR submissions will appear here for review." />
      ) : (
        <Table head={["REFERENCE", "ORDER", "CUSTOMER", "METHOD", "EXTERNAL ID", "AMOUNT", "STATUS", "SUBMITTED", "ACTIONS"]}>
          {filtered.map((p) => (
            <tr key={p.id} className="border-line hover:bg-raised/50 border-b last:border-0">
              <td className="num text-fore px-4 py-3 text-[12.5px]">{p.reference}</td>
              <td className="num text-mute px-4 py-3 text-[12px]">{p.orderRef ?? "—"}</td>
              <td className="px-4 py-3">
                <div className="text-chalk text-[13px]">{p.customer}</div>
                <div className="text-mute text-[11.5px]">{p.plan ?? p.email ?? ""}</div>
              </td>
              <td className="legend text-fore px-4 py-3">{p.method}</td>
              <td className="num text-mute max-w-[160px] truncate px-4 py-3 text-[11.5px]">{p.externalId ?? "—"}</td>
              <td className="num text-chalk px-4 py-3 text-[13.5px]">₹{Number(p.amount).toLocaleString("en-IN")}</td>
              <td className="px-4 py-3"><Badge tone={TONE[p.status] ?? "mute"}>{String(p.status).replace("_", " ")}</Badge></td>
              <td className="num text-mute px-4 py-3 text-[11.5px]">{new Date(p.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</td>
              <td className="px-4 py-3">
                <div className="flex items-center gap-1.5">
                  {p.proofUrl && (
                    <button onClick={() => setProof(p)} className="border-line text-mute hover:text-link hover:border-link/40 border p-1.5" aria-label="View proof">
                      <ImageIcon size={13} />
                    </button>
                  )}
                  {(p.status === "awaiting_verification" || p.status === "pending") && (
                    <>
                      <button
                        onClick={() => setApprove(p)}
                        className="border-led/40 text-led hover:bg-led/10 border p-1.5"
                        aria-label="Approve"
                      >
                        <CheckCircle2 size={13} />
                      </button>
                      <button
                        onClick={() => { setReject(p); setReason(""); }}
                        className="border-signal/40 text-signal hover:bg-signal/10 border p-1.5"
                        aria-label="Reject"
                      >
                        <XCircle size={13} />
                      </button>
                    </>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </Table>
      )}

      <Modal
        open={Boolean(proof)}
        onClose={() => setProof(null)}
        title={`Payment proof · ${proof?.reference ?? ""}`}
        footer={<Btn variant="ghost" onClick={() => setProof(null)}>Close</Btn>}
      >
        {proof && (
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3 text-[13px]">
              {[["AMOUNT", `₹${Number(proof.amount).toLocaleString("en-IN")}`], ["METHOD", proof.method], ["REFERENCE", proof.externalId ?? "—"], ["NOTE", proof.note ?? "—"]].map(([l, v]: any) => (
                <div key={l} className="border-line bg-raised/60 border p-3">
                  <div className="legend text-mute text-[8.5px]">{l}</div>
                  <div className="num text-fore mt-1 break-all">{v}</div>
                </div>
              ))}
            </div>
            {proof.proofUrl && <img src={proof.proofUrl} alt="Uploaded payment proof" className="max-h-[420px] w-full border border-line object-contain" />}
          </div>
        )}
      </Modal>

      <Modal
        open={Boolean(approve)}
        onClose={() => setApprove(null)}
        title="Approve payment"
        footer={
          <>
            <Btn variant="ghost" onClick={() => setApprove(null)}>Cancel</Btn>
            <Btn
              disabled={busy}
              onClick={async () => {
                const target = approve;
                if (!target) return;
                setBusy(true);
                await run(
                  () => api.post("/api/admin/actions", { action: "approve_payment", id: target.id, note: "Verified manually in console" }),
                  "Payment verified — order marked paid.",
                );
                setBusy(false);
                setApprove(null);
              }}
            >
              {busy ? "VERIFYING…" : "CONFIRM RECEIPT"}
            </Btn>
          </>
        }
      >
        <p className="text-fore text-[14px]">
          Confirm that <span className="num text-signal">₹{approve ? Number(approve.amount).toLocaleString("en-IN") : 0}</span>{" "}
          has genuinely settled in the merchant account for order {approve?.orderRef}. Wallet top-ups are credited to the
          customer ledger in the same transaction.
        </p>
      </Modal>

      <Modal
        open={Boolean(reject)}
        onClose={() => setReject(null)}
        title="Reject payment"
        footer={
          <>
            <Btn variant="ghost" onClick={() => setReject(null)}>Cancel</Btn>
            <Btn
              variant="danger"
              disabled={busy || reason.trim().length < 3}
              onClick={async () => {
                const target = reject;
                if (!target) return;
                setBusy(true);
                await run(() => api.post("/api/admin/actions", { action: "reject_payment", id: target.id, reason }), "Payment rejected.");
                setBusy(false);
                setReject(null);
              }}
            >
              {busy ? "WORKING…" : "REJECT"}
            </Btn>
          </>
        }
      >
        <Field label="REJECTION REASON (REQUIRED)" required hint="SHOWN TO THE CUSTOMER IN THEIR PAYMENT HISTORY">
          <textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} className={input} placeholder="UTR does not match the transfer amount." />
        </Field>
      </Modal>
    </div>
  );
}
