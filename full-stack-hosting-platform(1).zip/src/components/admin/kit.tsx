"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  LayoutDashboard,
  Boxes,
  FolderTree,
  Tags,
  ReceiptText,
  CreditCard,
  Users,
  Home,
  Settings as SettingsIcon,
  FileText,
  Search,
  Plus,
  Inbox,
  X,
  CheckCircle2,
  Terminal,
  MapPin,
} from "lucide-react";
import { useToast } from "@/components/ui/Toast";
import { Sidebar, type SidebarItem } from "@/components/dashboard/Sidebar";
import { Wordmark } from "@/components/site/Mark";

/* --------------------------------- API ------------------------------------ */
export function useApi() {
  const { push } = useToast();
  const request = async (method: string, url: string, body?: any) => {
    const res = await fetch(url, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data.error ?? `Request failed (${res.status})`;
      push(msg, "err");
      throw new Error(msg);
    }
    return data;
  };
  return {
    get: (url: string) => request("GET", url),
    post: (url: string, body?: any) => request("POST", url, body),
    put: (url: string, body?: any) => request("PUT", url, body),
    del: (url: string) => request("DELETE", url),
    toast: push,
  };
}

/* -------------------------------- nav ------------------------------------- */
export const NAV: SidebarItem[] = [
  { key: "dashboard", label: "Overview", href: "/admin", icon: LayoutDashboard },
  {
    key: "catalog",
    label: "Catalog",
    href: "/admin/plans",
    icon: Boxes,
    children: [
      { key: "plans", label: "Hosting plans", href: "/admin/plans" },
      { key: "categories", label: "Categories", href: "/admin/categories" },
      { key: "tags", label: "Tags", href: "/admin/tags" },
    ],
  },
  {
    key: "commerce",
    label: "Commerce",
    href: "/admin/orders",
    icon: ReceiptText,
    children: [
      { key: "orders", label: "Orders", href: "/admin/orders" },
      { key: "payments", label: "Payments", href: "/admin/payments" },
      { key: "customers", label: "Customers", href: "/admin/customers" },
    ],
  },
  {
    key: "storefront",
    label: "Storefront",
    href: "/admin/homepage",
    icon: Home,
    children: [
      { key: "homepage", label: "Homepage", href: "/admin/homepage" },
      { key: "content", label: "Content & coupons", href: "/admin/content" },
      { key: "locations", label: "Server locations", href: "/admin/locations" },
      { key: "free-server", label: "Free server demo", href: "/admin/free-server" },
    ],
  },
  { key: "console", label: "Server console", href: "/admin/console", icon: Terminal },
  { key: "settings", label: "Settings", href: "/admin/settings", icon: SettingsIcon },
];


export function Shell({ children, user }: { children: React.ReactNode; user: any }) {
  const { toast } = useApi();

  // Branding: the primary colour set in Admin -> Settings is applied live.
  useEffect(() => {
    fetch("/api/home")
      .then((r) => r.json())
      .then((d) => {
        const c = d?.settings?.theme?.primary;
        if (c && /^#[0-9a-fA-F]{6}$/.test(c)) document.documentElement.style.setProperty("--color-signal", c);
        const a = d?.settings?.theme?.accent;
        if (a && /^#[0-9a-fA-F]{6}$/.test(a)) document.documentElement.style.setProperty("--color-link", a);
      })
      .catch(() => {});
  }, []);

  // Mirrors the server-side RBAC matrix for navigation only — the API still enforces it.
  const role = String(user.role ?? "");
  const grants: Record<string, string[]> = {
    super_admin: ["*"],
    product_manager: ["catalog", "cms"],
    finance_manager: ["orders", "payments", "customers", "settings"],
    support: ["orders", "customers", "cms"],
  };
  const allowed = (scope: string) => (grants[role] ?? []).includes("*") || (grants[role] ?? []).includes(scope);
  const SCOPE_BY_KEY: Record<string, string> = { catalog: "catalog", commerce: "orders", storefront: "cms", console: "orders", settings: "settings", dashboard: "*" };
  const CHILD_SCOPE: Record<string, string> = { plans: "catalog", categories: "catalog", tags: "catalog", orders: "orders", payments: "payments", customers: "customers", homepage: "cms", content: "cms", locations: "catalog", "free-server": "catalog" };
  const visibleNav: SidebarItem[] = NAV.map((item) => ({
    ...item,
    children: item.children?.filter((c) => allowed(CHILD_SCOPE[c.key] ?? "orders")),
  })).filter((item) => allowed(SCOPE_BY_KEY[item.key] ?? "orders") && (item.children ? item.children.length > 0 || item.key !== "commerce" : true));

  return (
    <div className="bg-void min-h-screen">
      {/* Single shared sidebar implementation (also used by the customer dashboard) */}
      <Sidebar items={visibleNav} user={{ name: user.name, email: user.email, role: user.role }} homeHref="/admin" variant="admin" />
      <div className="pt-16 lg:pt-0 lg:pl-[240px]">
        <div className="mx-auto max-w-[1500px] px-4 pb-16 lg:px-8 lg:pt-8">{children}</div>
      </div>
    </div>
  );
}

/* ------------------------------- primitives -------------------------------- */
export function PageHead({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: React.ReactNode }) {
  return (
    <div className="border-line mb-6 flex flex-col gap-4 border-b pb-5 md:flex-row md:items-end md:justify-between">
      <div>
        <h1 className="text-[clamp(1.5rem,3vw,2.1rem)] font-semibold">{title}</h1>
        {subtitle && <p className="text-mute mt-1.5 max-w-2xl text-[13.5px]">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Btn({
  children,
  onClick,
  variant = "primary",
  type = "button",
  disabled,
  className = "",
}: any) {
  const styles: Record<string, string> = {
    primary: "bg-signal text-void hover:bg-signal-2",
    ghost: "border-line text-fore hover:border-line-2 hover:bg-raised",
    danger: "border-signal/50 text-signal hover:bg-signal/10",
    quiet: "text-mute hover:text-fore",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`legend inline-flex items-center justify-center gap-2 px-4 py-2.5 font-semibold transition-all disabled:opacity-50 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  wide = false,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (!open) return;
    document.addEventListener("keydown", onKey);
    // Lock the page behind the modal, restoring whatever was there before.
    const body = document.body;
    const prevOverflow = body.style.overflow;
    const prevTouchAction = body.style.touchAction;
    body.classList.add("scroll-locked");
    body.style.overflow = "hidden";
    body.style.touchAction = "none";
    return () => {
      document.removeEventListener("keydown", onKey);
      body.classList.remove("scroll-locked");
      body.style.overflow = prevOverflow;
      body.style.touchAction = prevTouchAction;
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[90] flex items-start justify-center overflow-y-auto bg-black/72 p-4 backdrop-blur-sm md:p-8"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 320, damping: 30 }}
            onClick={(e) => e.stopPropagation()}
            className={`panel my-auto w-full ${wide ? "max-w-5xl" : "max-w-2xl"}`}
          >
            <div className="border-line sticky top-0 z-10 flex items-center justify-between border-b bg-panel px-5 py-4">
              <h3 className="text-[16px] font-semibold">{title}</h3>
              <button onClick={onClose} className="text-mute hover:text-signal transition-colors" aria-label="Close">
                <X size={17} />
              </button>
            </div>
            <div className="max-h-[70vh] overflow-y-auto p-5 thin-scroll">{children}</div>
            {footer && <div className="border-line flex justify-end gap-2 border-t px-5 py-4">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function Field({ label, children, hint, required }: { label: string; children: React.ReactNode; hint?: string; required?: boolean }) {
  return (
    <label className="block">
      <span className="legend text-mute mb-2 block">
        {label} {required && <span className="text-signal">*</span>}
      </span>
      {children}
      {hint && <span className="legend text-mute/70 mt-1.5 block text-[8.5px] leading-relaxed">{hint}</span>}
    </label>
  );
}

export const input =
  "border-line bg-raised focus:border-signal/70 placeholder:text-mute/50 text-fore w-full border px-3 py-2.5 text-[13.5px] outline-none transition-colors";

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-3"
      aria-pressed={checked}
    >
      <span className={`relative h-5 w-9 border transition-colors ${checked ? "border-signal/70 bg-signal/25" : "border-line bg-raised"}`}>
        <span
          className={`absolute top-0.5 h-3.5 w-3.5 transition-all ${checked ? "bg-signal left-[18px]" : "bg-line-2 left-0.5"}`}
        />
      </span>
      {label && <span className="text-fore text-[13.5px]">{label}</span>}
    </button>
  );
}

export function Toolbar({
  search,
  onSearch,
  children,
  placeholder = "Search…",
}: {
  search?: string;
  onSearch?: (v: string) => void;
  children?: React.ReactNode;
  placeholder?: string;
}) {
  return (
    <div className="mb-4 flex flex-wrap items-center gap-3">
      {onSearch && (
        <div className="border-line bg-panel focus-within:border-signal/60 flex min-w-[220px] flex-1 items-center gap-2 border px-3 py-2">
          <Search size={14} className="text-mute" />
          <input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder={placeholder}
            className="w-full bg-transparent text-[13.5px] text-fore outline-none placeholder:text-mute/60"
          />
        </div>
      )}
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}

export function Table({ head, children }: { head: string[]; children: React.ReactNode }) {
  return (
    <div className="panel overflow-x-auto thin-scroll">
      <table className="w-full min-w-[720px] border-collapse">
        <thead>
          <tr className="border-line border-b">
            {head.map((h) => (
              <th key={h} className="legend text-mute px-4 py-3 text-left font-medium whitespace-nowrap">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export function Row({ children, cols }: { children: React.ReactNode; cols: number }) {
  return (
    <tr className="border-line hover:bg-raised/50 border-b transition-colors last:border-0">
      {Array.from({ length: cols }).map((_, i) => (
        <td key={i} className="px-4 py-3 align-middle">
          {children}
        </td>
      ))}
    </tr>
  );
}

export function Empty({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (
    <div className="border-line border-dashed px-6 py-16 text-center">
      <Inbox size={26} className="text-line-2 mx-auto" />
      <p className="text-chalk mt-4 text-[15px] font-medium">{title}</p>
      {hint && <p className="text-mute mt-1.5 text-[13px]">{hint}</p>}
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

export function Badge({ children, tone = "mute" }: { children: React.ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    mute: "border-line text-mute",
    ok: "border-led/40 text-led bg-led/10",
    warn: "border-signal/40 text-signal bg-signal/10",
    info: "border-link/40 text-link bg-link/10",
    bad: "border-red-500/40 text-red-400 bg-red-500/10",
  };
  return <span className={`legend border px-2 py-0.5 whitespace-nowrap ${tones[tone] ?? tones.mute}`}>{children}</span>;
}

export function Stat({ label, value, hint, tone }: { label: string; value: string; hint?: string; tone?: string }) {
  return (
    <div className="panel p-4">
      <div className="legend text-mute text-[8.5px]">{label}</div>
      <div className={`num mt-2 text-[26px] leading-none font-semibold ${tone ?? "text-chalk"}`}>{value}</div>
      {hint && <div className="legend text-mute/70 mt-2 text-[8.5px]">{hint}</div>}
    </div>
  );
}

export function Confirm({ open, onClose, onConfirm, title, body, busy }: any) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title ?? "Confirm action"}
      footer={
        <>
          <Btn variant="ghost" onClick={onClose}>
            Cancel
          </Btn>
          <Btn variant="danger" onClick={onConfirm} disabled={busy}>
            {busy ? "WORKING…" : "CONFIRM"}
          </Btn>
        </>
      }
    >
      <p className="text-fore text-[14px]">{body}</p>
    </Modal>
  );
}

export function Ok({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-led inline-flex items-center gap-1.5 text-[12px]">
      <CheckCircle2 size={13} /> {children}
    </span>
  );
}
