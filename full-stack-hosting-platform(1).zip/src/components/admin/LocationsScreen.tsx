"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Pencil, Trash2, Activity, Radio } from "lucide-react";
import {
  PageHead, Btn, Modal, Field, input, Toggle, Toolbar, Table, Badge, Empty, useApi, Confirm,
} from "@/components/admin/kit";

type Measurement = {
  id: string;
  ms: number | null;
  status: "online" | "offline" | "timeout" | "unavailable";
  error: string | null;
  checkedAt: string;
  httpStatus: number | null;
};

/**
 * Server location management. Latency shown anywhere on the site is measured
 * against the endpoints configured here — locations without an endpoint report
 * N/A rather than an invented number.
 */
export function LocationsScreen() {
  const api = useApi();
  const [rows, setRows] = useState<any[]>([]);
  const [editing, setEditing] = useState<any>(null);
  const [remove, setRemove] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [measuring, setMeasuring] = useState(false);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [checkedAt, setCheckedAt] = useState<string | null>(null);

  const load = async () => {
    try {
      setRows((await api.get("/api/admin/locations")).rows);
    } catch {
      /* toast */
    }
  };

  const measure = useCallback(async () => {
    setMeasuring(true);
    try {
      const res = await fetch("/api/latency", { cache: "no-store" });
      const data = await res.json();
      setMeasurements(data.locations ?? []);
      setCheckedAt(data.measuredAt ?? null);
      if (res.status === 429) api.toast("Measurement rate-limited — try again shortly.", "err");
    } catch (e: any) {
      api.toast(e?.message ?? "Measurement failed", "err");
    } finally {
      setMeasuring(false);
    }
  }, [api]);

  useEffect(() => {
    load();
    measure();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const save = async () => {
    setBusy(true);
    try {
      if (editing._new) await api.post("/api/admin/locations", editing);
      else await api.put(`/api/admin/locations/${editing.id}`, editing);
      api.toast("Location saved.");
      setEditing(null);
      load();
      measure();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  const mFor = (id: string) => measurements.find((m) => m.id === id);
  const filtered = rows.filter((r) => `${r.name} ${r.city} ${r.code}`.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <PageHead
        title="Server locations"
        subtitle="Each location needs a real health/ping endpoint before latency can be measured. No endpoint, no number — the site displays N/A instead of guessing."
        actions={
          <>
            <Btn variant="ghost" onClick={measure} disabled={measuring}>
              <Activity size={13} className={measuring ? "animate-spin" : ""} /> Measure now
            </Btn>
            <Btn onClick={() => setEditing({ _new: true, name: "", city: "", country: "", code: "", tier: "Edge", endpoint: "", timeoutMs: 4000, sortOrder: rows.length + 1, active: true })}>
              <Plus size={14} /> New location
            </Btn>
          </>
        }
      />

      <div className="mb-4 border-line bg-raised/50 flex flex-wrap items-center justify-between gap-3 border px-4 py-3">
        <span className="legend text-mute">
          {checkedAt ? `LAST MEASUREMENT ${new Date(checkedAt).toLocaleTimeString()}` : "NO MEASUREMENT YET"}
          {" · "}
          {measurements.filter((m) => m.ms != null).length} / {measurements.length || rows.length} REACHABLE
        </span>
        <span className="legend text-mute/70">MEASURED FROM THE APPLICATION SERVER + EVERY VISITOR'S BROWSER</span>
      </div>

      <Toolbar search={search} onSearch={setSearch} placeholder="Search locations…">
        <span className="legend text-mute">{filtered.length} LOCATIONS</span>
      </Toolbar>

      {filtered.length === 0 ? (
        <Empty title="No server locations" hint="Add a location and, optionally, its health endpoint." />
      ) : (
        <Table head={["LOCATION", "CODE", "TIER", "ENDPOINT", "MEASURED RTT", "STATUS", "ORDER", "ACTIONS"]}>
          {filtered.map((loc) => {
            const m = mFor(loc.id);
            const measured = m?.ms ?? null;
            return (
              <tr key={loc.id} className="border-line hover:bg-raised/50 border-b last:border-0">
                <td className="px-4 py-3">
                  <div className="text-chalk text-[13.5px] font-medium">{loc.name}</div>
                  <div className="text-mute text-[11.5px]">
                    {[loc.city, loc.country].filter(Boolean).join(", ")}
                  </div>
                </td>
                <td className="num text-signal px-4 py-3 text-[12.5px]">{loc.code ?? "—"}</td>
                <td className="px-4 py-3">
                  <span className={`legend border px-2 py-0.5 ${loc.tier === "Core" ? "border-link/40 bg-link/8 text-link" : "border-line text-mute"}`}>
                    {loc.tier ?? "Edge"}
                  </span>
                </td>
                <td className="num text-mute max-w-[240px] truncate px-4 py-3 text-[11.5px]" title={loc.endpoint ?? ""}>
                  {loc.endpoint ?? <span className="text-signal">NO ENDPOINT</span>}
                </td>
                <td className="num px-4 py-3 text-[13.5px]">
                  {measured != null ? (
                    <span className="text-chalk">
                      {measured} <span className="legend text-mute">MS</span>
                    </span>
                  ) : (
                    <span className="text-mute">N/A</span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <Badge tone={m?.status === "online" ? "ok" : m?.status === "unavailable" && !loc.endpoint ? "mute" : m ? "warn" : "mute"}>
                    {m ? m.status.toUpperCase() : loc.active ? "PENDING" : "DISABLED"}
                  </Badge>
                </td>
                <td className="num text-mute px-4 py-3 text-[12px]">{loc.sortOrder}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1.5">
                    <button onClick={() => setEditing({ ...loc, _new: false })} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Edit">
                      <Pencil size={13} />
                    </button>
                    <button onClick={() => setRemove(loc)} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Delete">
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </Table>
      )}

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={editing?._new ? "New server location" : `Edit — ${editing?.name ?? ""}`}
        footer={
          <>
            <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn onClick={save} disabled={busy}>{busy ? "SAVING…" : "Save location"}</Btn>
          </>
        }
      >
        {editing && (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="NAME" required>
              <input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className={input} placeholder="Mumbai" />
            </Field>
            <Field label="CODE">
              <input value={editing.code ?? ""} onChange={(e) => setEditing({ ...editing, code: e.target.value })} className={`${input} font-mono`} placeholder="BOM1" />
            </Field>
            <Field label="CITY">
              <input value={editing.city ?? ""} onChange={(e) => setEditing({ ...editing, city: e.target.value })} className={input} />
            </Field>
            <Field label="COUNTRY">
              <input value={editing.country ?? ""} onChange={(e) => setEditing({ ...editing, country: e.target.value })} className={input} />
            </Field>
            <Field label="TIER">
              <select value={editing.tier ?? "Edge"} onChange={(e) => setEditing({ ...editing, tier: e.target.value })} className={input}>
                <option value="Core">Core</option>
                <option value="Edge">Edge</option>
              </select>
            </Field>
            <Field label="DISPLAY ORDER">
              <input type="number" value={editing.sortOrder ?? 0} onChange={(e) => setEditing({ ...editing, sortOrder: Number(e.target.value) })} className={input} />
            </Field>
            <div className="md:col-span-2">
              <Field
                label="MEASUREMENT / HEALTH ENDPOINT"
                hint="ABSOLUTE HTTP(S) URL RETURNING 2xx WHEN THE REGION IS HEALTHY. LEAVE EMPTY TO SHOW 'UNAVAILABLE' RATHER THAN A GUESS."
              >
                <input
                  value={editing.endpoint ?? ""}
                  onChange={(e) => setEditing({ ...editing, endpoint: e.target.value })}
                  className={`${input} font-mono`}
                  placeholder="https://bom1.example.com/health"
                />
              </Field>
            </div>
            <Field label="TIMEOUT (MS)">
              <input type="number" min={1000} max={15000} step={500} value={editing.timeoutMs ?? 4000} onChange={(e) => setEditing({ ...editing, timeoutMs: Number(e.target.value) })} className={input} />
            </Field>
            <div className="flex items-end pb-2">
              <Toggle checked={editing.active} onChange={(v) => setEditing({ ...editing, active: v })} label="Active" />
            </div>
            {editing.endpoint && (
              <div className="md:col-span-2 border-line bg-raised/50 flex items-center gap-3 border p-3">
                <Radio size={14} className="text-signal" />
                <span className="legend text-mute">
                  {mFor(editing.id)
                    ? mFor(editing.id)!.ms != null
                      ? `LAST MEASURED ${mFor(editing.id)!.ms} MS · ${mFor(editing.id)!.status.toUpperCase()}`
                      : `NOT REACHABLE · ${(mFor(editing.id)!.error ?? "no response").toUpperCase()}`
                    : "NOT MEASURED YET"}
                </span>
              </div>
            )}
          </div>
        )}
      </Modal>

      <Confirm
        open={Boolean(remove)}
        onClose={() => setRemove(null)}
        busy={busy}
        title="Delete location"
        body={`Delete "${remove?.name}"? It disappears from the network map and latency list immediately.`}
        onConfirm={async () => {
          const target = remove;
          if (!target) return;
          setBusy(true);
          try {
            await api.del(`/api/admin/locations/${target.id}`);
            api.toast("Location deleted.");
            setRemove(null);
            load();
            measure();
          } catch {
            /* toast */
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}
