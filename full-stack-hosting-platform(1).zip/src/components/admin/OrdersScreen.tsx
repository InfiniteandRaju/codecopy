"use client";

import { useEffect, useMemo, useState } from "react";
import { Eye, RotateCcw, Ban } from "lucide-react";
import {
  PageHead, Btn, Modal, Field, input, Toolbar, Table, Badge, Empty, useApi, Confirm,
} from "@/components/admin/kit";

const STATUSES = ["pending", "awaiting_payment", "paid", "processing", "active", "cancelled", "failed", "refunded"];
const TONE: Record<string, string> = {
  paid: "ok", active: "ok", pending: "warn", awaiting_payment: "warn",
  processing: "info", failed: "bad", cancelled: "mute", refunded: "info",
};

const PAGE = 12;

export function OrdersScreen() {
  const api = useApi();
  const [rows, setRows] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<any>(null);
  const [refund, setRefund] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setRows((await api.get("/api/admin/orders")).rows);
    } catch {
      /* toast */
    }
  };
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(
    () =>
      rows.filter(
        (o) =>
          (status === "all" || o.status === status) &&
          (o.reference.toLowerCase().includes(search.toLowerCase()) ||
            o.planName.toLowerCase().includes(search.toLowerCase()) ||
            (o.customer ?? "").toLowerCase().includes(search.toLowerCase()) ||
            (o.email ?? "").toLowerCase().includes(search.toLowerCase())),
      ),
    [rows, search, status],
  );

  const pageRows = filtered.slice(page * PAGE, page * PAGE + PAGE);
  const revenue = filtered.filter((o) => ["paid", "active", "processing"].includes(o.status)).reduce((s, o) => s + Number(o.total), 0);

  const saveStatus = async () => {
    setBusy(true);
    try {
      await api.put(`/api/admin/orders/${editing.id}`, { status: editing.status, paymentMethod: editing.paymentMethod });
      api.toast("Order updated.");
      setEditing(null);
      load();
    } catch {
      /* toast */
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <PageHead title="Orders" subtitle="Every order with its computed price, payment method and lifecycle status. Statuses are set by payment verification, never by the customer." />

      <Toolbar search={search} onSearch={setSearch} placeholder="Reference, plan, customer…">
        <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }} className="border-line bg-panel text-fore border px-3 py-2 text-[13px] outline-none">
          <option value="all">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s.replace("_", " ")}</option>
          ))}
        </select>
        <span className="legend text-mute">{filtered.length} ORDERS · ₹{Math.round(revenue).toLocaleString("en-IN")} SETTLED</span>
      </Toolbar>

      {pageRows.length === 0 ? (
        <Empty title="No orders match" hint="Change the status filter or clear the search." />
      ) : (
        <>
          <Table head={["REFERENCE", "CUSTOMER", "PLAN", "PERIOD", "AMOUNT", "METHOD", "STATUS", "CREATED", "ACTIONS"]}>
            {pageRows.map((o) => (
              <tr key={o.id} className="border-line hover:bg-raised/50 border-b last:border-0">
                <td className="num text-fore px-4 py-3 text-[12.5px]">{o.reference}</td>
                <td className="px-4 py-3">
                  <div className="text-chalk text-[13px]">{o.customer}</div>
                  <div className="text-mute text-[11.5px]">{o.email ?? "Guest checkout"}</div>
                </td>
                <td className="text-fore max-w-[180px] truncate px-4 py-3 text-[13px]">{o.plan}</td>
                <td className="text-mute px-4 py-3 text-[12.5px]">{o.cycleLabel ?? o.cycleKey}{o.location ? ` · ${o.location}` : ""}</td>
                <td className="num text-chalk px-4 py-3 text-[13.5px]">₹{Number(o.total).toLocaleString("en-IN")}</td>
                <td className="legend text-mute px-4 py-3">{o.paymentMethod ?? "—"}</td>
                <td className="px-4 py-3"><Badge tone={TONE[o.status] ?? "mute"}>{String(o.status).replace("_", " ")}</Badge></td>
                <td className="num text-mute px-4 py-3 text-[11.5px]">{new Date(o.createdAt).toLocaleDateString("en-IN")}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1.5">
                    <button onClick={() => setEditing({ ...o })} className="border-line text-mute hover:text-signal hover:border-signal/40 border p-1.5" aria-label="Edit status"><Eye size={13} /></button>
                    <button onClick={() => setRefund(o)} className="border-line text-mute hover:text-link hover:border-link/40 border p-1.5" aria-label="Refund"><RotateCcw size={13} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>

          <div className="mt-4 flex items-center justify-between">
            <span className="legend text-mute">PAGE {page + 1} / {Math.max(1, Math.ceil(filtered.length / PAGE))}</span>
            <div className="flex gap-2">
              <Btn variant="ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Previous</Btn>
              <Btn variant="ghost" disabled={(page + 1) * PAGE >= filtered.length} onClick={() => setPage((p) => p + 1)}>Next</Btn>
            </div>
          </div>
        </>
      )}

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title={`Order ${editing?.reference ?? ""}`}
        footer={
          <>
            <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
            <Btn onClick={saveStatus} disabled={busy}>{busy ? "SAVING…" : "Save status"}</Btn>
          </>
        }
      >
        {editing && (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="ORDER STATUS">
              <select value={editing.status} onChange={(e) => setEditing({ ...editing, status: e.target.value })} className={input}>
                {STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
              </select>
            </Field>
            <Field label="PAYMENT METHOD">
              <input value={editing.paymentMethod ?? ""} onChange={(e) => setEditing({ ...editing, paymentMethod: e.target.value })} className={input} />
            </Field>
            <div className="md:col-span-2 border-line bg-raised/50 grid grid-cols-2 gap-3 border p-4 text-[13px] md:grid-cols-4">
              {[
                ["PLAN", editing.plan],
                ["SUBTOTAL", `₹${Number(editing.subtotal).toLocaleString("en-IN")}`],
                ["TAX", `₹${Number(editing.tax).toLocaleString("en-IN")}`],
                ["TOTAL", `₹${Number(editing.total).toLocaleString("en-IN")}`],
                ["COUPON", editing.couponCode ?? "—"],
                ["CYCLE", editing.cycleLabel ?? editing.cycleKey],
                ["LOCATION", editing.location ?? "—"],
                ["CREATED", new Date(editing.createdAt).toLocaleString("en-IN")],
              ].map(([label, value]: any) => (
                <div key={label}>
                  <div className="legend text-mute text-[8.5px]">{label}</div>
                  <div className="num text-fore mt-1">{value}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>

      <Confirm
        open={Boolean(refund)}
        onClose={() => setRefund(null)}
        busy={busy}
        title="Refund order"
        body={`Refund ₹${refund ? Number(refund.total).toLocaleString("en-IN") : 0} for ${refund?.planName}? The amount is credited back to the customer's wallet ledger with an audit note, and the order is marked refunded.`}
        onConfirm={async () => {
          const target = refund;
          if (!target) return;
          setBusy(true);
          try {
            await api.post("/api/admin/actions", { action: "refund_order", id: target.id, reason: "Refund issued from console" });
            api.toast("Refunded to customer wallet.");
            setRefund(null);
            load();
          } catch {
            /* toast */
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}
