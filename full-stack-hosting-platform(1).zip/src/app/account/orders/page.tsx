import { currentUser } from "@/lib/auth";
import { getSettings } from "@/lib/data";
import { db } from "@/db";
import { orders, payments, products } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { OrdersTab } from "@/components/site/AccountPanel";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your orders" };

export default async function OrdersPage() {
  const user = await currentUser();
  const [settings, orderRows] = await Promise.all([
    getSettings(),
    db
      .select({ order: orders, product: products })
      .from(orders)
      .leftJoin(products, eq(orders.productId, products.id))
      .where(eq(orders.userId, user!.id))
      .orderBy(desc(orders.createdAt))
      .limit(100),
  ]);
  const payRows = await db.select().from(payments).where(eq(payments.userId, user!.id));
  const list = orderRows.map((r) => ({
    ...r.order,
    planSlug: r.product?.slug ?? ((r.order.meta as any)?.planSlug ?? null),
    payments: payRows.filter((p) => p.orderId === r.order.id),
  }));

  return (
    <div className="pt-6">
      <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Account", href: "/account" }, { label: "Orders" }]} />
      <header className="border-line mb-6 mt-4 border-b pb-5">
        <div className="legend text-signal mb-3">01 / ORDER HISTORY</div>
        <h1 className="text-[clamp(1.5rem,3vw,2.1rem)] font-semibold">Your orders</h1>
      </header>
      <OrdersTab orders={list} symbol={settings.currencySymbol ?? "₹"} />
    </div>
  );
}
