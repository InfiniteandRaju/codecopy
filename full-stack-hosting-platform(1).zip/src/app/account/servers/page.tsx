import { DemoServers } from "@/components/site/DemoServers";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const dynamic = "force-dynamic";
export const metadata = { title: "Demo servers" };

export default function DemoServersPage() {
  return (
    <div className="pt-6">
      <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Account", href: "/account" }, { label: "Demo servers" }]} />
      <header className="border-line mb-6 mt-4 flex flex-wrap items-end justify-between gap-4 border-b pb-5">
        <div>
          <div className="legend text-signal mb-3">01 / FREE DEMO SERVERS</div>
          <h1 className="text-[clamp(1.5rem,3vw,2.1rem)] font-semibold">Your demo servers</h1>
        </div>
        <p className="text-mute max-w-md text-[13px]">
          Start, stop, restart and extend the demo servers you own. Expired demos are stopped or destroyed automatically
          according to the configured policy.
        </p>
      </header>
      <DemoServers />
    </div>
  );
}
