import { currentUser } from "@/lib/auth";
import { getBalance } from "@/lib/wallet";
import { getSettings } from "@/lib/data";
import { WalletTab } from "@/components/site/AccountPanel";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const dynamic = "force-dynamic";
export const metadata = { title: "Wallet & billing" };

export default async function WalletPage() {
  const user = await currentUser();
  const [balance, settings] = await Promise.all([getBalance(user!.id), getSettings()]);
  const symbol = settings.currencySymbol ?? "₹";

  return (
    <div className="pt-6">
      <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Account", href: "/account" }, { label: "Wallet" }]} />
      <header className="border-line mb-6 mt-4 border-b pb-5">
        <div className="legend text-signal mb-3">01 / WALLET & BILLING</div>
        <h1 className="text-[clamp(1.5rem,3vw,2.1rem)] font-semibold">Funds, top-ups and ledger</h1>
      </header>
      <WalletTab balance={balance} symbol={symbol} />
    </div>
  );
}
