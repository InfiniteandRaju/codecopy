import { currentUser } from "@/lib/auth";
import { ProfileTab } from "@/components/site/AccountPanel";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your profile" };

export default async function ProfilePage() {
  const user = await currentUser();

  return (
    <div className="pt-6">
      <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Account", href: "/account" }, { label: "Profile" }]} />
      <header className="border-line mb-6 mt-4 border-b pb-5">
        <div className="legend text-signal mb-3">01 / PROFILE</div>
        <h1 className="text-[clamp(1.5rem,3vw,2.1rem)] font-semibold">Account details</h1>
        <p className="text-mute mt-2 text-[13.5px]">
          Signed in as {user!.email} · role {String(user!.role).replace("_", " ")}
        </p>
      </header>
      <ProfileTab user={{ id: user!.id, name: user!.name, email: user!.email, role: user!.role, status: user!.status }} />
    </div>
  );
}
