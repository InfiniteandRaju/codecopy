import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { getBranding } from "@/lib/branding";
import { getCategoryTree } from "@/lib/data";
import { Sidebar, type SidebarItem } from "@/components/dashboard/Sidebar";

export const dynamic = "force-dynamic";

/**
 * Customer dashboard shell. Uses the exact same Sidebar component as the admin
 * console; nested children are the real categories from the database.
 */
/** Nested category navigation: deeper levels are indented by depth. */
function flattenCategories(list: any[], depth = 0): { key: string; label: string; href: string }[] {
  return list.flatMap((c) => [
    { key: c.id, label: depth > 0 ? `${"\u00b7 ".repeat(depth)}${c.name}` : c.name, href: `/hosting/${c.slug}` },
    ...(c.children?.length ? flattenCategories(c.children, depth + 1) : []),
  ]);
}

export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const user = await currentUser();
  if (!user) redirect("/login?next=/account");

  const cats = await getCategoryTree().catch(() => [] as any[]);
  const items: SidebarItem[] = [
    { key: "overview", label: "Dashboard", href: "/account", icon: "dashboard", children: [
      { key: "wallet", label: "Wallet & billing", href: "/account/wallet" },
      { key: "orders", label: "Orders", href: "/account/orders" },
      { key: "servers", label: "Demo servers", href: "/account/servers" },
      { key: "profile", label: "Profile", href: "/account/profile" },
    ] },
    {
      key: "hosting",
      label: "Browse hosting",
      href: "/pricing",
      icon: "boxes",
      children: flattenCategories(cats).slice(0, 40),
    },
  ];

  return (
    <div className="bg-void min-h-screen">
      <Sidebar items={items} user={{ name: user.name, email: user.email, role: user.role }} homeHref="/account" variant="customer" />
      <div className="pt-16 lg:pt-0 lg:pl-[240px]">
        <div className="mx-auto max-w-[1400px] px-4 pb-16 lg:px-8 lg:pt-8">{children}</div>
      </div>
    </div>
  );
}
