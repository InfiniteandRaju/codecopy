import Link from "next/link";
import { ArrowUpRight, ChevronRight } from "lucide-react";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { getCategoryTreeWithCounts, getAllTags, getSettings } from "@/lib/data";
import { Reveal, SectionHead } from "@/components/ui/Motion";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Hosting services",
  description:
    "Game hosting, VPS, dedicated servers, bot hosting, web hosting, database and cloud hosting — the full Obsidian Node service index.",
};

export default async function ServicesPage() {
  const [categories, tags, settings] = await Promise.all([getCategoryTreeWithCounts(), getAllTags(), getSettings()]);
  const symbol = settings.currencySymbol ?? "₹";

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Services" }]} />

        <header className="mt-4 mb-14 grid gap-8 border-b border-line pb-10 lg:grid-cols-[1.3fr_1fr] lg:items-end">
          <div>
            <div className="legend text-signal mb-4 flex items-center gap-3">
              <span>01 / SERVICE INDEX</span>
              <span className="bg-line-2 h-px w-8" />
              <span className="text-mute">{categories.length} CATEGORIES</span>
            </div>
            <h1 className="text-[clamp(2.2rem,5.4vw,4rem)] font-semibold">
              Every workload,
              <br />
              one catalogue.
            </h1>
          </div>
          <p className="text-mute text-[15.5px] leading-relaxed">
            Categories nest as deep as the catalogue needs — parent, child, grandchild. Each one carries its own icon,
            banner, SEO copy and display order, all maintained from the admin console.
          </p>
        </header>

        <div className="grid gap-4 md:grid-cols-2">
          {categories.map((c: any, i: number) => (
            <Reveal key={c.id} delay={Math.min(i, 6) * 0.05} className={c.children?.length > 3 ? "md:col-span-2" : ""}>
              <Link
                href={`/hosting/${c.slug}`}
                className="panel group relative flex h-full flex-col overflow-hidden p-6 transition-all duration-300 hover:border-signal/40 md:p-7"
              >
                {c.image && (
                  <span className="pointer-events-none absolute inset-0 opacity-25 transition-opacity duration-500 group-hover:opacity-40">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={c.image} alt="" className="h-full w-full object-cover" loading="lazy" />
                    <span className="from-panel absolute inset-0 bg-gradient-to-t via-panel/70 to-panel/30" />
                  </span>
                )}
                <span className="relative">
                <div className="mb-5 flex items-start justify-between gap-4">
                  <div>
                    <span className="legend text-signal">{String(i + 1).padStart(2, "0")}</span>
                    <h2 className="group-hover:text-signal-2 mt-3 text-[clamp(1.35rem,2.4vw,1.9rem)] font-semibold transition-colors">
                      {c.name}
                    </h2>
                  </div>
                  <span className="border-line text-mute group-hover:border-signal group-hover:text-signal border p-2.5 transition-all">
                    <ArrowUpRight size={15} />
                  </span>
                </div>

                <p className="text-mute min-h-[44px] text-[14px] leading-relaxed">{c.description}</p>

                {c.children?.length > 0 && (
                  <div className="mt-5 flex flex-wrap gap-1.5">
                    {c.children.map((sub: any) => (
                      <span
                        key={sub.id}
                        className="border-line text-mute group-hover:border-line-2 group-hover:text-fore border px-2.5 py-1 text-[11.5px] transition-colors"
                      >
                        {sub.name}
                        {sub.children?.length ? ` +${sub.children.length}` : ""}
                      </span>
                    ))}
                  </div>
                )}

                <div className="border-line mt-auto flex items-center justify-between border-t pt-4">
                  <span className="legend text-mute">
                    {c.planCount ?? 0} PLANS · {c.children?.length ?? 0} SUBCATEGORIES
                  </span>
                  <span className="legend text-mute group-hover:text-signal flex items-center gap-1 transition-colors">
                    VIEW PLANS <ChevronRight size={12} />
                  </span>
                </div>
                </span>
              </Link>
            </Reveal>
          ))}
        </div>

        <section className="mt-20">
          <SectionHead
            index="02"
            legend="TAGS"
            title="Filter the catalogue by tag"
            description="Tags are created in the admin console, coloured by hand, and attached to any number of plans."
          />
          <div className="flex flex-wrap gap-2">
            {tags.map((t) => (
              <Link
                key={t.id}
                href={`/hosting?tag=${t.slug}`}
                className="legend border px-3.5 py-2.5 transition-all hover:-translate-y-0.5"
                style={{ color: t.color, borderColor: `${t.color}44`, background: `${t.color}10` }}
              >
                {t.name}
              </Link>
            ))}
          </div>
        </section>

        <section className="border-line bg-panel/50 mt-16 flex flex-col items-start justify-between gap-6 border p-7 md:flex-row md:items-center md:p-9">
          <div>
            <h3 className="text-[clamp(1.4rem,3vw,2rem)] font-semibold">Not sure which unit fits?</h3>
            <p className="text-mute mt-2 max-w-xl text-[14.5px]">
              Tell us the workload and we will size it — including migrations from your current host, free of charge.
            </p>
          </div>
          <div className="flex gap-3">
            <Link href="/pricing" className="bg-signal text-void hover:bg-signal-2 px-6 py-3.5 text-[13.5px] font-semibold transition-colors">
              See pricing {symbol && ""}
            </Link>
            <Link
              href="/register"
              className="border-line text-fore hover:border-chalk hover:text-chalk border px-6 py-3.5 text-[13.5px] transition-all"
            >
              Create account
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
