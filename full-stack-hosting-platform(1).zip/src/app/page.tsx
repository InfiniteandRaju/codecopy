import Link from "next/link";
import {
  ArrowUpRight,
  Zap,
  ShieldCheck,
  Cpu,
  Headphones,
  ChevronRight,
  Mail,
  MessageCircle,
} from "lucide-react";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Telemetry } from "@/components/site/Telemetry";
import { LatencyGrid } from "@/components/site/LatencyGrid";
import { FaqList } from "@/components/site/Faq";
import { RackRail } from "@/components/site/RackRail";
import { Reveal, SectionHead } from "@/components/ui/Motion";
import { getHomepage, getSettings, getCategoryTree } from "@/lib/data";
import { getFreeServerSettings } from "@/lib/freeserver";

export const dynamic = "force-dynamic";

const ICONS: Record<string, any> = { zap: Zap, shield: ShieldCheck, cpu: Cpu, headphones: Headphones };

const RAIL = [
  { id: "services", label: "SERVICES" },
  { id: "why", label: "FEATURES" },
  { id: "infra", label: "INFRASTRUCTURE" },
  { id: "protection", label: "PROTECTION" },
  { id: "network", label: "LOCATIONS" },
  { id: "free-demo", label: "FREE DEMO" },
  { id: "testimonials", label: "CUSTOMERS" },
  { id: "faq", label: "FAQ" },
  { id: "support", label: "SUPPORT" },
];

export default async function HomePage() {
  const [{ sections, testimonials, faqs }, settings, categories, freeCfg] = await Promise.all([
    getHomepage(),
    getSettings(),
    getCategoryTree(),
    getFreeServerSettings(),
  ]);

  const hero = sections.hero;
  const why = sections.whyUs;
  const locations = sections.locations;
  const infra = sections.infrastructure;
  const ddos = sections.ddos;
  const support = sections.support;
  const metrics = settings.heroMetrics ?? { uptime: "99.99", nodes: 4128, blocked: "1.4M" };
  const regionCount = (locations?.items ?? []).length;
  const mitigation = (ddos?.stats ?? [])[0]?.value ?? "\u2014";

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <RackRail items={RAIL} />

      <main className="xl:pl-[88px]">

{/* ------------------------------- HERO ------------------------------- */}
        <section id="top" className="grain relative overflow-hidden">
          <div className="absolute inset-0">
            <img
              src={hero.image || "/images/hero-aisle.jpg"}
              alt=""
              className="h-full w-full object-cover object-center opacity-[0.55]"
            />
            <div className="from-void via-void/86 absolute inset-0 bg-gradient-to-r to-transparent" />
            <div className="from-void absolute inset-0 bg-gradient-to-t via-transparent to-void/70" />
          </div>

          <div className="relative mx-auto max-w-[1440px] px-5 pt-28 pb-16 md:px-10 md:pt-36 md:pb-24">
            <div className="grid items-end gap-12 lg:grid-cols-[1.4fr_400px]">
              <div>
                <Reveal>
                  <div className="legend text-signal mb-7 flex flex-wrap items-center gap-3">
                    <span className="led led-pulse bg-signal text-signal h-1.5 w-1.5 rounded-full" />
                    <span>{hero.eyebrow}</span>
                  </div>
                </Reveal>

                <Reveal delay={0.06}>
                  <h1 className="text-[clamp(2.7rem,7.4vw,5.5rem)] font-bold tracking-[-0.045em] whitespace-pre-line">
                    {hero.title}
                  </h1>
                </Reveal>

                <Reveal delay={0.14}>
                  <p className="text-mute mt-7 max-w-xl text-[16.5px] leading-relaxed">{hero.description}</p>
                </Reveal>

                <Reveal delay={0.2}>
                  <div className="mt-9 flex flex-wrap items-center gap-3">
                    <Link
                      href={hero.primaryCta?.href || "/pricing"}
                      className="bg-signal text-void hover:bg-signal-2 group flex items-center gap-2 px-7 py-4 text-[14px] font-semibold transition-colors"
                    >
                      {hero.primaryCta?.label || "Browse hosting plans"}
                      <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </Link>
                    <Link
                      href={hero.secondaryCta?.href || "/services"}
                      className="border-line-2/70 text-fore hover:border-chalk hover:text-chalk flex items-center gap-2 border px-7 py-4 text-[14px] transition-all"
                    >
                      {hero.secondaryCta?.label || "View services"}
                    </Link>
                  </div>
                </Reveal>

                <Reveal delay={0.28}>
                  <dl className="border-line mt-12 grid max-w-2xl grid-cols-2 gap-px border-t bg-line/50 sm:grid-cols-4">
                    {[
                      ["UPTIME 90D", `${metrics.uptime ?? "—"}%`],
                      ["REGIONS", regionCount ? String(regionCount) : "—"],
                      ["MITIGATION", mitigation],
                      ["SETUP", "< 60s"],
                    ].map(([label, value]) => (
                      <div key={label} className="bg-void/60 px-3 py-4">
                        <dt className="legend text-mute text-[8.5px]">{label}</dt>
                        <dd className="num text-chalk mt-1.5 text-[17px] font-semibold">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </Reveal>
              </div>

              <Reveal delay={0.3} className="w-full">
                <Telemetry configured={{ uptime: String(metrics.uptime ?? "—"), nodes: Number(metrics.nodes ?? 0), blocked: String(metrics.blocked ?? "—") }} />
              </Reveal>
            </div>
          </div>
        </section>


        {/* ---------------------------- CATEGORIES ---------------------------- */}
        <section id="services" className="border-line mx-auto max-w-[1440px] border-t px-5 py-16 md:px-10 md:py-24">
          <SectionHead
            index="01"
            legend="HOSTING SERVICES"
            title="Everything we run, at a glance"
            description="Game servers, VPS, dedicated machines, bot runtimes, web and database hosting — each category opens onto its own plans, specifications and prices."
            right={
              <div className="flex flex-wrap gap-2">
                <Link
                  href="/pricing"
                  className="bg-signal text-void hover:bg-signal-2 legend flex items-center gap-2 px-5 py-3 font-semibold transition-colors"
                >
                  VIEW PRICING <ArrowUpRight size={13} />
                </Link>
                <Link href="/services" className="border-line text-fore hover:border-chalk hover:text-chalk border px-5 py-3 text-[13px] transition-all">
                  All services
                </Link>
              </div>
            }
          />

          <div className="border-line border-t">
            {categories.map((c: any, i: number) => (
              <Reveal key={c.id} delay={Math.min(i, 6) * 0.04}>
                <Link
                  href={`/hosting/${c.slug}`}
                  className="group border-line hover:bg-raised/50 relative grid grid-cols-[auto_1fr_auto] items-center gap-5 border-b px-2 py-6 transition-all md:gap-8 md:px-4"
                >
                  <span className="num text-mute group-hover:text-signal w-8 text-[11px] transition-colors">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                      <h3 className="group-hover:text-signal-2 text-[clamp(1.3rem,2.6vw,2rem)] font-semibold transition-colors">
                        {c.name}
                      </h3>
                      <span className="legend text-mute">{c.children?.length ?? 0} SUBCATEGORIES</span>
                    </div>
                    <p className="text-mute mt-1.5 max-w-2xl truncate text-[14px]">{c.description}</p>
                    {c.children?.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {c.children.slice(0, 5).map((sub: any) => (
                          <span
                            key={sub.id}
                            className="border-line text-mute group-hover:border-signal/40 group-hover:text-fore border px-2 py-1 text-[11px] transition-colors"
                          >
                            {sub.name}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <span className="border-line text-mute group-hover:border-signal group-hover:text-signal border p-2.5 transition-all">
                    <ChevronRight size={16} />
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </section>


        {/* ------------------------------ WHY US ------------------------------ */}
        <section id="why" className="mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
          <div className="grid gap-12 lg:grid-cols-[0.9fr_1.4fr]">
            <div className="lg:sticky lg:top-28 lg:self-start">
              <SectionHead
                index="02"
                legend="OPERATING PRINCIPLES"
                title={why.title}
                description="Four commitments we hold ourselves to in the status page, not the marketing deck."
              />
            </div>
            <div className="grid gap-px bg-line/60 sm:grid-cols-2">
              {(why.items ?? []).map((item: any, i: number) => {
                const Icon = ICONS[item.icon] ?? Zap;
                return (
                  <Reveal key={i} delay={i * 0.07} className="bg-void">
                    <div className="group h-full p-6 transition-colors md:p-8">
                      <div className="border-line group-hover:border-signal/50 group-hover:bg-signal/8 mb-6 flex h-11 w-11 items-center justify-center border transition-all">
                        <Icon size={19} className="text-signal" />
                      </div>
                      <div className="legend text-mute mb-2 text-[9px]">{String(i + 1).padStart(2, "0")} / 04</div>
                      <h3 className="text-[19px] font-semibold">{item.title}</h3>
                      <p className="text-mute mt-3 text-[14px] leading-relaxed">{item.body}</p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </section>


        {/* --------------------------- INFRASTRUCTURE ------------------------- */}
        <section id="infra" className="mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <Reveal className="relative">
              <div className="border-line panel relative overflow-hidden">
                <img src={infra.image || "/images/rack-macro.jpg"} alt="Rack front panel" className="h-[420px] w-full object-cover" loading="lazy" />
                <div className="from-void/85 absolute inset-0 bg-gradient-to-t via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <span className="legend text-signal">FIG. 03 — 1U FRONT PANEL</span>
                </div>
              </div>
            </Reveal>
            <div>
              <SectionHead index="03" legend="HARDWARE" title={infra.title} description={infra.description} />
              <dl className="border-line border-t">
                {(infra.items ?? []).map((item: any, i: number) => (
                  <div key={i} className="border-line flex flex-col gap-1 border-b py-4 sm:flex-row sm:items-center sm:gap-6">
                    <dt className="legend text-signal w-40 shrink-0">{item.label}</dt>
                    <dd className="num text-fore text-[14px]">{item.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </section>


        {/* ------------------------------- DDoS ------------------------------- */}
        <section id="protection" className="grain relative overflow-hidden border-line border-y">
          <img src={ddos.image || "/images/fiber-splash.jpg"} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" loading="lazy" />
          <div className="from-void via-void/70 absolute inset-0 bg-gradient-to-r to-void/80" />
          <div className="relative mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
            <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-end">
              <div>
                <div className="legend text-signal mb-5 flex items-center gap-3">
                  <ShieldCheck size={14} /> 08 / PROTECTION
                </div>
                <h2 className="text-[clamp(2rem,4.6vw,3.5rem)] font-semibold">{ddos.title}</h2>
                <p className="text-mute mt-5 max-w-xl text-[15.5px] leading-relaxed">{ddos.description}</p>
                <Link
                  href="/hosting?tag=ddos-protected"
                  className="border-signal/50 text-signal hover:bg-signal hover:text-void mt-8 inline-flex items-center gap-2 border px-6 py-3.5 text-[13.5px] transition-all"
                >
                  See protected plans <ArrowUpRight size={14} />
                </Link>
              </div>
              <div className="grid grid-cols-2 gap-px bg-line/50">
                {(ddos.stats ?? []).map((s: any) => (
                  <div key={s.label} className="bg-void/85 px-5 py-6">
                    <div className="num text-chalk text-[clamp(1.4rem,3vw,2rem)] font-semibold">{s.value}</div>
                    <div className="legend text-mute mt-2 text-[9px]">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>


        {/* ----------------------------- LOCATIONS ---------------------------- */}
        <section id="network" className="border-line bg-panel/40 border-y">
          <div className="mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
            <SectionHead
              index="05"
              legend="NETWORK FOOTPRINT"
              title={locations.title}
              description={locations.description}
              right={<span className="legend text-mute">REAL ROUND-TRIP TIME · RE-MEASURED CONTINUOUSLY</span>}
            />
            <LatencyGrid />
          </div>
        </section>


        {/* --------------------------- FREE SERVER DEMO ----------------------- */}
        <section id="free-demo" className="border-line border-t">
          <div className="mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
            <div className="grid items-center gap-10 lg:grid-cols-[1.05fr_1fr]">
              <div>
                <div className="legend text-signal mb-5 flex items-center gap-3">
                  <span>06</span>
                  <span className="bg-line-2 h-px w-8" />
                  <span className="text-mute">FREE SERVER DEMO</span>
                </div>
                <h2 className="text-[clamp(1.9rem,4.2vw,3.2rem)] font-semibold">{freeCfg.title}</h2>
                <p className="text-mute mt-4 max-w-xl text-[15.5px]">{freeCfg.description}</p>

                <div className="border-line mt-7 grid gap-px border bg-line/60 sm:grid-cols-4">
                  {[
                    ["RAM", `${freeCfg.ram.freeMb >= 1024 ? freeCfg.ram.freeMb / 1024 + " GB" : freeCfg.ram.freeMb + " MB"}`],
                    ["CPU", `${freeCfg.cpu.freePercent}%`],
                    ["DISK", `${freeCfg.disk.freeMb >= 1024 ? freeCfg.disk.freeMb / 1024 + " GB" : freeCfg.disk.freeMb + " MB"}`],
                    ["RUNTIME", `${Math.round(freeCfg.duration.defaultMinutes / 60) || freeCfg.duration.defaultMinutes} ${freeCfg.duration.defaultMinutes >= 60 ? "hours" : "min"}`],
                  ].map(([label, value]) => (
                    <div key={label} className="bg-void px-4 py-3">
                      <div className="legend text-mute text-[8.5px]">{label} · FREE</div>
                      <div className="num text-chalk mt-1 text-[17px] font-semibold">{value}</div>
                    </div>
                  ))}
                </div>

                <div className="mt-7 flex flex-wrap gap-3">
                  <Link
                    href="/free-server"
                    className="bg-signal text-void hover:bg-signal-2 group flex items-center gap-2 px-7 py-4 text-[14px] font-semibold transition-colors"
                  >
                    {freeCfg.cta}
                    <ArrowUpRight size={16} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </Link>
                  <Link
                    href="/account/servers"
                    className="border-line-2/70 text-fore hover:border-chalk hover:text-chalk flex items-center gap-2 border px-7 py-4 text-[14px] transition-all"
                  >
                    Manage demo servers
                  </Link>
                </div>
                <p className="legend text-mute mt-4">
                  CONFIGURE RAM · CPU · DISK · DURATION · SOFTWARE — PRICE CALCULATED FROM ADMIN SETTINGS, NEVER HARDCODED
                </p>
              </div>

              <div className="panel relative overflow-hidden">
                {freeCfg.banner && (
                  <>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={freeCfg.banner} alt="" className="h-[260px] w-full object-cover opacity-60" />
                    <div className="from-panel absolute inset-0 bg-gradient-to-t via-transparent to-transparent" />
                  </>
                )}
                <div className="border-line grid grid-cols-2 gap-px border-t bg-line/60">
                  {[
                    ["SOFTWARE OPTIONS", String(freeCfg.software.filter((x: any) => x.enabled).length)],
                    ["RAM OPTIONS", String(freeCfg.ram.options.length)],
                    ["DURATION OPTIONS", String(freeCfg.duration.options.length)],
                    ["EXPIRY POLICY", freeCfg.duration.expireAction === "delete" ? "DESTROY" : "STOP"],
                  ].map(([label, value]) => (
                    <div key={label} className="bg-panel px-4 py-3">
                      <div className="legend text-mute text-[8.5px]">{label}</div>
                      <div className="num text-chalk mt-1 text-[15px] font-semibold">{value}</div>
                    </div>
                  ))}
                </div>
                <div className="border-line flex items-center justify-between border-t px-5 py-4">
                  <span className="legend text-mute">FIRST {freeCfg.ram.freeMb >= 1024 ? `${freeCfg.ram.freeMb / 1024} GB` : `${freeCfg.ram.freeMb} MB`} RAM</span>
                  <span className="num text-led text-[20px] font-semibold">FREE</span>
                </div>
              </div>
            </div>
          </div>
        </section>



        {/* --------------------------- TESTIMONIALS --------------------------- */}
        <section id="testimonials" className="overflow-hidden py-16 md:py-24">
          <div className="mx-auto max-w-[1440px] px-5 md:px-10">
            <SectionHead index="07" legend="CUSTOMERS" title="What running on us sounds like" />
          </div>
          <div className="relative">
            <div className="pointer-events-none from-void absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r to-transparent" />
            <div className="pointer-events-none from-void absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l to-transparent" />
            <div className="marquee-track flex w-max gap-4 px-4">
              {[...testimonials, ...testimonials].map((t: any, i: number) => (
                <figure key={`${t.id}-${i}`} className="panel w-[340px] shrink-0 p-6 md:w-[420px]">
                  <div className="text-signal mb-4 flex gap-0.5" aria-label={`${t.rating} out of 5`}>
                    {Array.from({ length: Math.max(1, Math.min(5, t.rating)) }).map((_, s) => (
                      <span key={s} className="text-[13px]">★</span>
                    ))}
                  </div>
                  <blockquote className="text-fore text-[15px] leading-relaxed">“{t.quote}”</blockquote>
                  <figcaption className="border-line mt-5 flex items-center gap-3 border-t pt-4">
                    <span className="bg-signal/15 text-signal legend flex h-9 w-9 items-center justify-center border border-signal/30">
                      {String(t.name ?? "?").slice(0, 1)}
                    </span>
                    <span>
                      <span className="text-chalk block text-[13.5px] font-medium">{t.name}</span>
                      <span className="legend text-mute block text-[9px]">
                        {[t.role, t.company].filter(Boolean).join(" · ")}
                      </span>
                    </span>
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>


        {/* -------------------------------- FAQ ------------------------------- */}
        <section id="faq" className="border-line border-t">
          <div className="mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
            <div className="grid gap-10 lg:grid-cols-[0.75fr_1.4fr]">
              <div>
                <SectionHead index="08" legend="QUESTIONS" title="Frequently asked" />
                <p className="text-mute -mt-6 text-[14px]">
                  Something not covered?{" "}
                  <a href="#support" className="text-signal link-underline">
                    Ask an engineer
                  </a>
                  .
                </p>
              </div>
              <FaqList items={faqs} />
            </div>
          </div>
        </section>


        {/* ------------------------------- SUPPORT ---------------------------- */}
        <section id="support" className="border-line border-t">
          <div className="mx-auto max-w-[1440px] px-5 py-16 md:px-10 md:py-24">
            <div className="grid gap-8 lg:grid-cols-[1.15fr_1fr]">
              <Reveal className="panel relative overflow-hidden">
                <img src={support.image || "/images/noc-console.jpg"} alt="Network operations centre" className="h-full min-h-[300px] w-full object-cover" loading="lazy" />
                <div className="from-void/92 absolute inset-0 bg-gradient-to-t via-transparent to-transparent" />
                <div className="absolute right-5 bottom-5 left-5">
                  <span className="legend text-led flex items-center gap-2">
                    <span className="led led-pulse bg-led text-led h-1.5 w-1.5 rounded-full" />
                    NOC STAFFED · 24 / 7 / 365
                  </span>
                </div>
              </Reveal>

              <div className="flex flex-col justify-center">
                <SectionHead index="09" legend="CONTACT" title={support.title} description={support.description} />
                <div className="-mt-6 flex flex-col gap-3">
                  <a
                    href={`mailto:${support.email}`}
                    className="border-line hover:border-signal/50 hover:bg-signal/6 group flex items-center justify-between border px-5 py-4 transition-all"
                  >
                    <span className="flex items-center gap-3">
                      <Mail size={16} className="text-signal" />
                      <span className="text-fore text-[14.5px]">{support.email}</span>
                    </span>
                    <ArrowUpRight size={15} className="text-mute transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                  <a
                    href={support.discord}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="border-line hover:border-link/50 hover:bg-link/6 group flex items-center justify-between border px-5 py-4 transition-all"
                  >
                    <span className="flex items-center gap-3">
                      <MessageCircle size={16} className="text-link" />
                      <span className="text-fore text-[14.5px]">Join the support Discord</span>
                    </span>
                    <ArrowUpRight size={15} className="text-mute transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                  <p className="legend text-mute mt-2">{support.responseTime}</p>
                  <div className="border-line mt-4 flex flex-wrap gap-3 border-t pt-6">
                    <Link href="/pricing" className="bg-signal text-void hover:bg-signal-2 px-6 py-3.5 text-[13.5px] font-semibold transition-colors">
                      Browse hosting plans
                    </Link>
                    <Link href="/register" className="border-line text-fore hover:border-chalk hover:text-chalk border px-6 py-3.5 text-[13.5px] transition-all">
                      Create an account
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <div className="xl:pl-[88px]">
        <Footer />
      </div>
    </div>
  );
}
