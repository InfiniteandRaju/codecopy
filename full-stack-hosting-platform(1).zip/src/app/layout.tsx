import type { Metadata, Viewport } from "next";
import { Space_Grotesk, IBM_Plex_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { getSettings, type Json } from "@/lib/data";
import { getBranding } from "@/lib/branding";
import { BrandingProvider, type Branding } from "@/components/brand/BrandingProvider";
import { ToastProvider } from "@/components/ui/Toast";
import { ScrollManager } from "@/components/ui/ScrollManager";

const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});
const plex = IBM_Plex_Sans({
  subsets: ["latin"],
  variable: "--font-plex",
  weight: ["300", "400", "500", "600"],
  display: "swap",
});
const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  variable: "--font-plex-mono",
  weight: ["400", "500", "600"],
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const [s, b] = await Promise.all([getSettings().catch(() => null), getBranding().catch(() => null)]);
  const seo = s?.seo ?? {};
  const title = seo.title ?? "Obsidian Node — Game, VPS & Cloud Hosting";
  const description = seo.description ?? "";
  const og = seo.ogImage ?? "/images/hero-aisle.jpg";
  const siteName = b?.siteName || s?.siteName || "Obsidian Node";
  return {
    title: { default: title, template: `%s · ${siteName}` },
    description,
    keywords: ["game hosting", "vps hosting", "dedicated servers", "ddos protected", "minecraft hosting"],
    openGraph: { title, description, images: [{ url: og }], type: "website", siteName },
    twitter: { card: "summary_large_image", title, description, images: [og] },
    robots: { index: true, follow: true },
    // Favicon comes from the branding store, not a hardcoded path.
    icons: b?.favicon
      ? { icon: [{ url: b.favicon, type: b.faviconType }] }
      : { icon: "/favicon.svg" },
  };
}

export const viewport: Viewport = {
  themeColor: "#07090E",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const branding: Branding = await getBranding().catch(() => ({
    siteName: "Obsidian Node",
    tagline: "",
    logo: null,
    logoLight: null,
    logoDark: null,
    favicon: null,
    wordmark: "OBSIDIAN",
    submark: "NODE · INFRA",
    logoWidth: 132,
    logoHeight: 34,
  }));

  return (
    <html lang="en" className={`${grotesk.variable} ${plex.variable} ${plexMono.variable}`}>
      <body className="antialiased">
        <BrandingProvider branding={branding}>
          <ScrollManager />
          <ToastProvider>{children}</ToastProvider>
        </BrandingProvider>
      </body>
    </html>
  );
}
