import { notFound, redirect } from "next/navigation";
import { currentUser, isAdminRole } from "@/lib/auth";
import { Shell } from "@/components/admin/kit";
import { PasswordGate } from "@/components/dashboard/PasswordGate";

export const dynamic = "force-dynamic";

/**
 * Server-side guard for every admin route. Hiding links in the UI is never
 * treated as security — the role check happens here, on the server, per request.
 */
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await currentUser();
  // Case 1 — signed out: send to the single /login page, then back to /admin.
  if (!user) redirect("/login?next=/admin");
  // Case 2 — signed in as a customer: genuine 404. No redirect, no "access
  // denied", nothing that discloses that the console exists.
  if (!isAdminRole(user.role)) notFound();

  // Seeded development accounts must rotate their password before first use.
  if (user.mustChangePassword) {
    return <PasswordGate email={user.email} name={user.name} />;
  }

  return <Shell user={{ id: user.id, name: user.name, email: user.email, role: user.role }}>{children}</Shell>;
}
