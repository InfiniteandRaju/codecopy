import { notFound } from "next/navigation";
import { PlansScreen } from "@/components/admin/PlansScreen";
import { CategoriesScreen, TagsScreen } from "@/components/admin/CatalogScreen";
import { OrdersScreen } from "@/components/admin/OrdersScreen";
import { PaymentsScreen } from "@/components/admin/PaymentsScreen";
import { CustomersScreen } from "@/components/admin/CustomersScreen";
import { HomepageScreen } from "@/components/admin/HomepageScreen";
import { ContentScreen } from "@/components/admin/ContentScreen";
import { SettingsScreen } from "@/components/admin/SettingsScreen";
import { ConsoleScreen } from "@/components/admin/ConsoleScreen";
import { LocationsScreen } from "@/components/admin/LocationsScreen";
import { FreeServerScreen } from "@/components/admin/FreeServerScreen";

export const dynamic = "force-dynamic";

const SCREENS: Record<string, { title: string; Component: () => React.ReactElement }> = {
  plans: { title: "Plans", Component: PlansScreen },
  categories: { title: "Categories", Component: CategoriesScreen },
  tags: { title: "Tags", Component: TagsScreen },
  orders: { title: "Orders", Component: OrdersScreen },
  payments: { title: "Payments", Component: PaymentsScreen },
  customers: { title: "Customers", Component: CustomersScreen },
  homepage: { title: "Homepage", Component: HomepageScreen },
  content: { title: "Content", Component: ContentScreen },
  settings: { title: "Settings", Component: SettingsScreen },
  console: { title: "Server console", Component: ConsoleScreen },
  locations: { title: "Server locations", Component: LocationsScreen },
  "free-server": { title: "Free server demo", Component: FreeServerScreen },
};

export default async function SectionPage({ params }: { params: Promise<{ section: string }> }) {
  const { section } = await params;
  const entry = SCREENS[section];
  if (!entry) notFound();
  const Component = entry.Component;
  return <Component />;
}
