import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

/** The catalogue now lives at /pricing — one implementation, no duplicate page. */
export default function HostingIndex() {
  redirect("/pricing");
}
