import { notFound } from "next/navigation";
import { getCategoryTree, getAllTags, listPlans, getFlatCategories, getSettings, getCategoryTreeWithCounts } from "@/lib/data";
import { Browser } from "@/components/site/Browser";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const dynamic = "force-dynamic";

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const [categories, tags, flat, settings, treeWithCounts] = await Promise.all([
    getCategoryTree(),
    getAllTags(),
    getFlatCategories(),
    getSettings(),
    getCategoryTreeWithCounts(),
  ]);
  const category = flat.find((c) => c.slug === slug);
  if (!category) notFound();

  // Live plan count for this branch of the tree (nested children included).
  const findNode = (list: any[]): any => {
    for (const node of list) {
      if (node.id === category.id) return node;
      const hit = findNode(node.children ?? []);
      if (hit) return hit;
    }
    return null;
  };
  const node = findNode(treeWithCounts);

  const plans = await listPlans({
    category: slug,
    tag: sp.tag,
    search: sp.q,
    sort: sp.sort,
    maxPrice: sp.max ? Number(sp.max) : undefined,
    discounted: sp.discounted === "1",
  });

  const parent = category.parentId ? flat.find((c) => c.id === category.parentId) : null;
  const children = flat.filter((c) => c.parentId === category.id);

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Pricing", href: "/pricing" },
            ...(parent ? [{ label: parent.name, href: `/hosting/${parent.slug}` }] : []),
            { label: category.name },
          ]}
        />
        {category.image && (
          <div className="border-line relative mb-6 h-[180px] overflow-hidden border md:h-[240px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={category.image} alt={`${category.name} banner`} className="h-full w-full object-cover" />
            <div className="from-void absolute inset-0 bg-gradient-to-t via-transparent to-transparent" />
          </div>
        )}
        <header className="border-line mt-4 mb-8 border-b pb-8">
          <div className="legend text-signal mb-4 flex items-center gap-3">
            <span>{category.slug.toUpperCase()}</span>
            <span className="bg-line-2 h-px w-8" />
            <span className="text-mute">{plans.length} PLANS AVAILABLE</span>
          </div>
          <h1 className="text-[clamp(2.1rem,5vw,3.4rem)] font-semibold">{category.name}</h1>
          <p className="text-mute mt-4 max-w-2xl text-[15.5px]">{category.description}</p>
          {(node?.children?.length ?? 0) > 0 && (
            <div className="mt-5 flex flex-col gap-3">
              <span className="legend text-mute">SUBCATEGORIES</span>
              <div className="flex flex-wrap gap-2">
                {node.children.map((c: any) => (
                  <a
                    key={c.id}
                    href={`/hosting/${c.slug}`}
                    className="border-line text-mute hover:border-signal/50 hover:text-signal hover:bg-raised/60 group/sub flex flex-col gap-1 border px-3.5 py-2 transition-all"
                  >
                    <span className="text-fore text-[13px] group-hover/sub:text-signal transition-colors">{c.name}</span>
                    <span className="legend text-mute/70 text-[8.5px]">
                      {c.planCount} PLAN{c.planCount === 1 ? "" : "S"}
                      {c.children?.length ? ` · ${c.children.length} NESTED` : ""}
                    </span>
                  </a>
                ))}
              </div>
            </div>
          )}
          {category.seoDescription && category.seoDescription !== category.description && (
            <p className="text-mute/70 mt-4 max-w-3xl text-[13.5px]">{category.seoDescription}</p>
          )}
        </header>

        <Browser
          categories={categories}
          tags={tags}
          initialPlans={plans}
          symbol={settings.currencySymbol ?? "₹"}
          activeCategory={slug}
        />
      </main>
      <Footer />
    </div>
  );
}
