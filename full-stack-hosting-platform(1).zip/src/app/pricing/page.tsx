import { getCategoryTree, getAllTags, listPlans, getSettings } from "@/lib/data";
import { Browser } from "@/components/site/Browser";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Pricing — hosting plans and prices",
  description:
    "Every individual hosting plan with its real monthly price, billing periods, specifications, features and tags. Filter by category, subcategory, tag, price or popularity.",
};

/**
 * The pricing page: individual products with their own prices, read from the
 * catalogue. Categories and subcategories are navigation, never price tags.
 */
export default async function PricingPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const [categories, tags, settings] = await Promise.all([getCategoryTree(), getAllTags(), getSettings()]);
  const plans = await listPlans({
    category: sp.category,
    tag: sp.tag,
    search: sp.q,
    sort: sp.sort,
    maxPrice: sp.max ? Number(sp.max) : undefined,
    discounted: sp.discounted === "1",
  });

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Pricing" }]} />
        <header className="border-line mt-4 mb-10 border-b pb-9">
          <div className="legend text-signal mb-4 flex flex-wrap items-center gap-3">
            <span>PRICING</span>
            <span className="bg-line-2 h-px w-8" />
            <span className="text-mute">{plans.length} PLANS · LIVE FROM THE CATALOGUE</span>
          </div>
          <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr] lg:items-end">
            <div>
              <h1 className="text-[clamp(2.2rem,5.4vw,4rem)] font-semibold tracking-[-0.04em]">
                Transparent pricing,
                <br />
                per individual plan.
              </h1>
              <p className="text-mute mt-5 max-w-2xl text-[16px] leading-relaxed">
                Every card below is a real product: its own monthly price, billing periods, specifications, features and
                tags. Pick a billing period on the card to reprice instantly, then order through the destination
                configured for that plan.
              </p>
            </div>
            <div className="border-line panel grid grid-cols-2 gap-px border bg-line/60">
              {[
                ["PLANS", String(plans.length)],
                ["CATEGORIES", String(categories.length)],
                ["TAGS", String(tags.filter((t) => t.active).length)],
                ["CYCLES", "MONTHLY → ANNUAL"],
              ].map(([label, value]) => (
                <div key={label} className="bg-panel px-4 py-3">
                  <div className="legend text-mute text-[8.5px]">{label}</div>
                  <div className="num text-chalk mt-1 text-[15px] font-semibold">{value}</div>
                </div>
              ))}
            </div>
          </div>
        </header>

        <Browser
          categories={categories}
          tags={tags.filter((t) => t.active)}
          initialPlans={plans}
          symbol={settings.currencySymbol ?? "₹"}
          activeCategory={sp.category}
        />
      </main>
      <Footer />
    </div>
  );
}
