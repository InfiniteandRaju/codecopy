import Link from "next/link";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";

const DOCS: Record<string, { title: string; updated: string; sections: { h: string; p: string }[] }> = {
  terms: {
    title: "Terms of service",
    updated: "1 January 2026",
    sections: [
      { h: "1. Agreement", p: "By provisioning or using an Obsidian Node service you agree to these terms in full. Where a signed order form exists, that document takes precedence." },
      { h: "2. Billing", p: "Plans are billed in advance for the selected cycle. Renewal invoices are issued three days before the term ends. Non-payment beyond seven days may result in suspension; data is retained for a further fourteen days." },
      { h: "3. Acceptable use", p: "Service capacity is provisioned for the documented workload. Launching attacks, sending spam, hosting malware, or reselling proxy capacity is prohibited and results in immediate termination." },
      { h: "4. Refunds", p: "Shared, bot and game hosting carry a seven-day money-back guarantee. Dedicated servers are excluded because hardware is reserved for the term." },
      { h: "5. Availability", p: "The uptime commitment for each product class is documented in the SLA. Credits must be requested within thirty days of the incident." },
    ],
  },
  privacy: {
    title: "Privacy policy",
    updated: "1 January 2026",
    sections: [
      { h: "1. What we collect", p: "Account details (name, email, hashed password), billing records, wallet ledger entries, and operational telemetry required to run your servers." },
      { h: "2. Payment data", p: "Card and bank credentials are handled entirely by our payment providers. We store only the provider reference, status and amount. Wallet balances and adjustments are recorded in an immutable ledger." },
      { h: "3. Retention", p: "Operational logs are retained for 90 days. Financial records are retained for eight years as required by tax law. Wallet ledger entries are retained indefinitely for audit purposes." },
      { h: "4. Your rights", p: "You may request export or deletion of your personal data by writing to support@obsidiannode.io. We respond within thirty days." },
    ],
  },
  aup: {
    title: "Acceptable use policy",
    updated: "1 January 2026",
    sections: [
      { h: "1. Prohibited activity", p: "Denial-of-service attacks, port scanning of third parties, phishing, malware distribution, unsolicited bulk email, and any activity that is unlawful in the jurisdiction of the serving node." },
      { h: "2. Game servers", p: "You are responsible for the content published on your game server, including mods and community content. Excessive CPU abuse that degrades neighbours will be throttled with notice." },
      { h: "3. Resource fairness", p: "Shared and bot tiers are burstable. Sustained saturation of CPU or I/O for more than four hours may trigger throttling or a migration conversation." },
      { h: "4. Enforcement", p: "We aim to warn first and suspend second, except where immediate action is required to protect the network or other customers." },
    ],
  },
  sla: {
    title: "SLA & uptime",
    updated: "1 January 2026",
    sections: [
      { h: "1. Commitment", p: "99.99% monthly availability for dedicated and cloud products; 99.95% for VPS; 99.9% for shared and bot hosting, measured at the network edge." },
      { h: "2. Maintenance", p: "Scheduled maintenance is announced at least 72 hours in advance and is excluded from the availability calculation when it occurs inside the announced window." },
      { h: "3. Credits", p: "Availability below the commitment entitles you to service credits of 5% of the monthly fee per 0.1% shortfall, up to 100% of that month's fee." },
      { h: "4. Exclusions", p: "Customer-side misconfiguration, upstream internet failures beyond our peering, and attacks that exceed the documented mitigation capacity are excluded." },
    ],
  },
};

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return { title: DOCS[slug]?.title ?? "Legal" };
}

export default async function LegalPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const doc = DOCS[slug];

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[900px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        {doc ? (
          <>
            <div className="legend text-signal mb-4">LEGAL / {doc.title.toUpperCase()}</div>
            <h1 className="text-[clamp(2rem,5vw,3.2rem)] font-semibold">{doc.title}</h1>
            <p className="legend text-mute mt-3">LAST UPDATED {doc.updated.toUpperCase()}</p>
            <div className="mt-10 border-line border-t">
              {doc.sections.map((s) => (
                <section key={s.h} className="border-line border-b py-6">
                  <h2 className="text-[17px] font-semibold">{s.h}</h2>
                  <p className="text-mute mt-2.5 text-[14.5px] leading-relaxed">{s.p}</p>
                </section>
              ))}
            </div>
          </>
        ) : (
          <div className="text-center">
            <h1 className="text-[2rem] font-semibold">Document not found</h1>
            <Link href="/" className="text-signal mt-4 inline-block">
              Back to home
            </Link>
          </div>
        )}
        <p className="text-mute mt-8 text-[13px]">
          Questions? Write to <span className="text-fore">support@obsidiannode.io</span>.
        </p>
      </main>
      <Footer />
    </div>
  );
}
