import Link from "next/link";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";

export default function NotFound() {
  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto flex min-h-[60vh] max-w-[900px] flex-col items-center justify-center px-5 py-32 text-center">
        <span className="legend text-signal">ERROR 404 · NODE NOT FOUND</span>
        <h1 className="mt-5 text-[clamp(2.5rem,8vw,5rem)] font-bold">Rack slot empty</h1>
        <p className="text-mute mt-4 max-w-md text-[15px]">
          The unit you asked for is not provisioned. It may have been archived from the catalogue or the address is mistyped.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/" className="bg-signal text-void px-6 py-3.5 text-[14px] font-semibold">
            Back home
          </Link>
          <Link href="/pricing" className="border-line text-fore hover:border-chalk hover:text-chalk border px-6 py-3.5 text-[14px] transition-all">
            Browse plans
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
