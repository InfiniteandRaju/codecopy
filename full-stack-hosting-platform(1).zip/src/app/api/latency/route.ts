import { json, handleError } from "@/lib/api";
import { measureAllLocations } from "@/lib/locations";

export const dynamic = "force-dynamic";

/**
 * Real latency measurement. Every value comes from an actual HTTP round trip to
 * the endpoint configured for that location in Admin → Server locations.
 * Locations without a reachable endpoint return ms:null (rendered as N/A).
 */
export async function GET(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    const { rateLimit } = await import("@/lib/api");
    if (!rateLimit(`latency:${ip}`, 30, 60_000)) return json({ locations: [], throttled: true }, { status: 429 });
    const locations = await measureAllLocations();
    return json({ locations, measuredAt: new Date().toISOString() });
  } catch (e) {
    return handleError(e);
  }
}
