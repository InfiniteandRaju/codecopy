import {
  enabledMethods,
  payFromWallet,
  createRazorpayOrder,
  createCryptoInvoice,
  submitQrPayment,
  verifyRazorpaySignature,
  settleExternalPayment,
} from "@/lib/checkout";
import { getMethod } from "@/lib/checkout";
import { db } from "@/db";
import { orders, payments } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { json, fail, handleError, rateLimit, ApiError } from "@/lib/api";
import type { Json } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  return json({ methods: await enabledMethods() });
}

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit(`pay:${ip}`, 30, 60_000)) return fail("Too many payment attempts.", 429);
    const user = await currentUser();
    if (!user) return fail("Sign in to complete payment.", 401);
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    if (action === "wallet") {
      const { order, balance } = await payFromWallet(String(body.orderId ?? ""), user.id);
      return json({ ok: true, order, balance, status: order.status });
    }

    if (action === "razorpay_order") {
      const order = await ownedOrder(body.orderId, user.id);
      const result = await createRazorpayOrder(order);
      return json({ ok: true, ...result });
    }

    if (action === "razorpay_verify") {
      const method = await getMethod("razorpay");
      const cfg = (method?.config ?? {}) as Json;
      if (!cfg.keySecret) throw new ApiError("Razorpay keys are not configured.", 503);
      const orderId = String(body.razorpay_order_id ?? "");
      const ok = verifyRazorpaySignature({
        orderId,
        paymentId: String(body.razorpay_payment_id ?? ""),
        signature: String(body.razorpay_signature ?? ""),
        secret: cfg.keySecret,
      });
      if (!ok) throw new ApiError("Payment signature verification failed.", 400);
      const payRows = await db.select().from(payments).where(eq(payments.externalId, orderId)).limit(1);
      if (!payRows[0]?.orderId) throw new ApiError("Payment not found.", 404);
      const order = await settleExternalPayment({
        orderId: payRows[0].orderId,
        method: "razorpay",
        externalId: String(body.razorpay_payment_id),
      });
      return json({ ok: true, order, status: order.status });
    }

    if (action === "crypto") {
      const order = await ownedOrder(body.orderId, user.id);
      const result = await createCryptoInvoice(order);
      return json({ ok: true, ...result });
    }

    if (action === "qr") {
      const payment = await submitQrPayment({
        orderId: String(body.orderId ?? ""),
        userId: user.id,
        utr: String(body.utr ?? ""),
        proofUrl: body.proofUrl ? String(body.proofUrl).slice(0, 2_000_000) : null,
        note: body.note ? String(body.note).slice(0, 500) : null,
      });
      return json({ ok: true, payment, message: "Submitted for verification. An administrator will review it." });
    }

    if (action === "status") {
      const order = await ownedOrder(body.orderId, user.id);
      return json({ ok: true, status: order.status });
    }

    return fail("Unknown payment action.", 422);
  } catch (e) {
    return handleError(e);
  }
}

async function ownedOrder(orderId: unknown, userId: string) {
  const rows = await db.select().from(orders).where(eq(orders.id, String(orderId ?? ""))).limit(1);
  const order = rows[0];
  if (!order) throw new ApiError("Order not found", 404);
  if (order.userId !== userId) throw new ApiError("This order does not belong to you", 403);
  return order;
}
