import { createCheckout, enabledMethods } from "@/lib/checkout";
import { currentUser } from "@/lib/auth";
import { json, fail, handleError, rateLimit, ApiError } from "@/lib/api";
import { getSettings } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit(`checkout:${ip}`, 30, 60_000)) return fail("Too many checkout attempts.", 429);
    const body = await req.json().catch(() => ({}));
    const slug = String(body.slug ?? "").trim();
    if (!slug) return fail("A plan is required.", 422);

    const user = await currentUser();
    const settings = await getSettings();
    if (settings.maintenanceMode && user?.role !== "super_admin") {
      throw new ApiError(settings.maintenanceMessage ?? "Storefront temporarily unavailable.", 503);
    }

    const { order, plan, cycle, billing } = await createCheckout({
      userId: user?.id ?? null,
      slug,
      cycleKey: body.cycleKey ? String(body.cycleKey) : undefined,
      location: body.location ? String(body.location).slice(0, 80) : undefined,
      coupon: body.coupon ? String(body.coupon).slice(0, 40) : undefined,
      meta: { userAgent: req.headers.get("user-agent")?.slice(0, 200) ?? null },
    });

    const methods = await enabledMethods();
    return json({
      order,
      billing,
      plan: { id: plan.id, name: plan.name, slug: plan.slug },
      cycle: { key: cycle.key, label: cycle.label, price: cycle.price },
      methods,
      requiresAccount: !user,
      currencySymbol: settings.currencySymbol,
      taxLabel: settings.taxLabel,
    });
  } catch (e) {
    return handleError(e);
  }
}
