import { json, fail, handleError } from "@/lib/api";
import { sweepExpiredDemoServers } from "@/lib/freeserver";

export const dynamic = "force-dynamic";

/**
 * Scheduled cleanup for expired demo servers.
 * Call it with:  curl -X POST -H "x-cron-secret: $CRON_SECRET" .../api/cron/free-servers
 * The sweep also runs opportunistically whenever a customer opens their list.
 */
export async function POST(req: Request) {
  try {
    const secret = process.env.CRON_SECRET;
    if (!secret) return fail("CRON_SECRET is not configured on this deployment.", 503);
    const provided = req.headers.get("x-cron-secret") ?? new URL(req.url).searchParams.get("secret");
    if (provided !== secret) return fail("Invalid cron secret.", 401);
    const result = await sweepExpiredDemoServers();
    return json({ ok: true, ...result });
  } catch (e) {
    return handleError(e);
  }
}
