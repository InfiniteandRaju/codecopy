import { getCategoryTree, getAllTags, getFlatCategories } from "@/lib/data";
import { json } from "@/lib/api";

export const dynamic = "force-dynamic";

/** Public catalogue: nested tree (+ counts elsewhere) and the active tag list. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const wantFlat = url.searchParams.get("flat") === "1";
  const [tree, flat, tagRows] = await Promise.all([
    getCategoryTree(),
    getFlatCategories(),
    getAllTags(),
  ]);
  return json({
    categories: tree,
    ...(wantFlat ? { flat } : {}),
    tags: tagRows.filter((t) => t.active),
  });
}
