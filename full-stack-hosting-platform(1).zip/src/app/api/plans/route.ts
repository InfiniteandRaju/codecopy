import { listPlans, type PlanFilters } from "@/lib/data";
import { json, handleError } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const p = new URL(req.url).searchParams;
    const filters: PlanFilters = {
      category: p.get("category") ?? undefined,
      tag: p.get("tag") ?? undefined,
      search: p.get("q") ?? undefined,
      sort: p.get("sort") ?? undefined,
      minPrice: p.get("min") ? Number(p.get("min")) : undefined,
      maxPrice: p.get("max") ? Number(p.get("max")) : undefined,
      featured: p.get("featured") === "1",
      discounted: p.get("discounted") === "1",
    };
    const plans = await listPlans(filters);
    return json({ plans, total: plans.length });
  } catch (e) {
    return handleError(e);
  }
}
