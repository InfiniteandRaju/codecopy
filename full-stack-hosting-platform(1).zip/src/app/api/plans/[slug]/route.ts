import { getPlan, resolveBilling, getSettings } from "@/lib/data";
import { json, fail, handleError } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await ctx.params;
    const plan = await getPlan(decodeURIComponent(slug));
    if (!plan) return fail("Plan not found", 404);
    const settings = await getSettings();
    const billing = resolveBilling(plan.billing, plan, {});
    return json({
      plan,
      billing,
      currencySymbol: settings.currencySymbol,
      taxLabel: settings.taxLabel,
      taxRate: settings.taxRate,
    });
  } catch (e) {
    return handleError(e);
  }
}
