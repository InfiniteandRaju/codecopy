import { db } from "@/db";
import { walletAccounts, walletTransactions, orders, paymentMethods } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { json, fail, handleError, ApiError, rateLimit } from "@/lib/api";
import { getBalance, newRef } from "@/lib/wallet";
import { createRazorpayOrder, createCryptoInvoice, getMethod, money2 } from "@/lib/checkout";
import type { Json } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await currentUser();
    if (!user) return fail("Not authenticated", 401);
    const balance = await getBalance(user.id);
    const tx = await db
      .select()
      .from(walletTransactions)
      .where(eq(walletTransactions.userId, user.id))
      .orderBy(desc(walletTransactions.createdAt))
      .limit(100);
    const methods = await db.select().from(paymentMethods);
    const topups = ((methods.find((m) => m.key === "wallet")?.config as Json)?.topups ?? []) as number[];
    return json({ balance, transactions: tx, topups });
  } catch (e) {
    return handleError(e);
  }
}

/**
 * Creates a wallet top-up order. The credit itself only happens when a trusted
 * party confirms the money: a Razorpay signature, a provider IPN, or an admin
 * approving a QR transfer.
 */
export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit(`wallet:${ip}`, 20, 60_000)) return fail("Too many attempts.", 429);
    const user = await currentUser();
    if (!user) return fail("Not authenticated", 401);
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "topup");

    if (action === "topup") {
      const amount = Math.round(Number(body.amount) * 100) / 100;
      if (!Number.isFinite(amount) || amount < 100 || amount > 100000)
        throw new ApiError("Top-up amount must be between ₹100 and ₹100,000.", 422);
      const method = String(body.method ?? "razorpay");
      const order = (
        await db
          .insert(orders)
          .values({
            reference: newRef("ORD").toUpperCase().replace("_", ""),
            userId: user.id,
            productId: null,
            planName: "Wallet top-up",
            cycleKey: "one_time",
            cycleLabel: "One-time",
            subtotal: money2(amount),
            total: money2(amount),
            currency: "INR",
            status: "pending",
            paymentMethod: method,
            meta: { kind: "wallet_topup" },
          })
          .returning()
      )[0];

      if (method === "razorpay") return json({ ok: true, order, ...(await createRazorpayOrder(order)) });
      if (method === "crypto") return json({ ok: true, order, ...(await createCryptoInvoice(order)) });
      if (method === "qr") {
        const cfg = ((await getMethod("qr"))?.config ?? {}) as Json;
        return json({
          ok: true,
          order,
          instructions: cfg.instructions,
          upiId: cfg.upiId,
          qrImage: cfg.qrImage ?? null,
        });
      }
      throw new ApiError("Choose a supported top-up method.", 422);
    }

    if (action === "balance") {
      return json({ balance: await getBalance(user.id) });
    }

    return fail("Unknown wallet action.", 422);
  } catch (e) {
    return handleError(e);
  }
}
