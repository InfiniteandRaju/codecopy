import { getHomepage, getSettings, getCategoryTree, listPlans } from "@/lib/data";
import { json } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  const [home, settings, categories, featured] = await Promise.all([
    getHomepage(),
    getSettings(),
    getCategoryTree(),
    listPlans({ featured: true }),
  ]);
  return json({
    sections: home.sections,
    testimonials: home.testimonials,
    faqs: home.faqs,
    // Everything non-secret; payment credentials live in payment_methods and never here.
    settings,
    categories,
    featuredPlans: featured.slice(0, 6),
  });
}
