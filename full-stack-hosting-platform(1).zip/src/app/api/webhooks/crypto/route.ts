import { json, fail, handleError } from "@/lib/api";
import { verifyCryptoIpn } from "@/lib/checkout";
import type { Json } from "@/lib/data";

export const dynamic = "force-dynamic";

/**
 * Crypto provider IPN. Status transitions are only accepted when the provider's
 * HMAC signature verifies — a customer-submitted transaction hash is never enough.
 */
export async function POST(req: Request) {
  try {
    const raw = await req.text();
    let payload: Json;
    try {
      payload = JSON.parse(raw);
    } catch {
      return fail("Invalid payload", 400);
    }
    const signature =
      req.headers.get("x-nowpayments-sig") ??
      req.headers.get("x-ipn-secret") ??
      req.headers.get("x-cmp-signature");
    const result = await verifyCryptoIpn(payload, signature, raw);
    return json({ received: true, ...result });
  } catch (e) {
    return handleError(e);
  }
}
