import { db } from "@/db";
import { orders, payments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { json, fail, handleError, ApiError } from "@/lib/api";
import { verifyRazorpaySignature, settleExternalPayment, getMethod } from "@/lib/checkout";
import type { Json } from "@/lib/data";

export const dynamic = "force-dynamic";

/** Razorpay webhook — the authoritative confirmation path for card/UPI payments. */
export async function POST(req: Request) {
  try {
    const raw = await req.text();
    const signature = req.headers.get("x-razorpay-signature");
    const method = await getMethod("razorpay");
    const cfg = (method?.config ?? {}) as Json;
    if (!cfg.webhookSecret) return fail("Webhook secret not configured", 400);

    const { createHmac } = await import("crypto");
    const expected = createHmac("sha256", cfg.webhookSecret).update(raw).digest("hex");
    if (!signature || signature !== expected) return fail("Invalid signature", 401);

    const event = JSON.parse(raw);
    const entity = event?.payload?.payment?.entity;
    if (event?.event !== "payment.captured" && event?.event !== "payment.authorized") {
      return json({ received: true, ignored: true });
    }
    const ok = verifyRazorpaySignature({
      orderId: entity.order_id,
      paymentId: entity.id,
      signature: entity.signature ?? "",
      secret: cfg.keySecret ?? "",
    });
    if (!ok && !entity.signature) {
      // Webhook signature already validated above; trust entity linkage.
    }
    const payRows = await db.select().from(payments).where(eq(payments.externalId, entity.order_id)).limit(1);
    if (!payRows[0]?.orderId) throw new ApiError("No payment for this webhook", 404);
    await settleExternalPayment({
      orderId: payRows[0].orderId,
      method: "razorpay",
      externalId: entity.id,
      expectedAmount: Number(entity.amount) / 100,
    });
    return json({ received: true });
  } catch (e) {
    return handleError(e);
  }
}
