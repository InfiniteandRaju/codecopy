import { requireAdmin, json, handleError, fail, logActivity, ApiError } from "@/lib/api";
import { createPlan, updateEntity } from "@/lib/admin";
import { settleExternalPayment } from "@/lib/checkout";
import { applyWalletTx, newRef } from "@/lib/wallet";
import { db } from "@/db";
import {
  payments,
  orders,
  products,
  productTags,
  billingCycles,
  billingConfigurations,
  users,
  walletAccounts,
  categories,
  tags,
} from "@/db/schema";
import { eq, sql, inArray } from "drizzle-orm";
import { getBalance } from "@/lib/wallet";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    if (action === "duplicate_plan") {
      const actor = await requireAdmin("catalog");
      const rows = await db.select().from(products).where(eq(products.id, String(body.id ?? ""))).limit(1);
      const src = rows[0];
      if (!src) return fail("Plan not found", 404);
      const [cycles, tagRows, billing] = await Promise.all([
        db.select().from(billingCycles).where(eq(billingCycles.productId, src.id)),
        db.select({ tagId: productTags.tagId }).from(productTags).where(eq(productTags.productId, src.id)),
        db.select().from(billingConfigurations).where(eq(billingConfigurations.productId, src.id)).limit(1),
      ]);
      const copy = await createPlan(
        {
          name: `${src.name} (Copy)`,
          slug: `${src.slug}-copy-${Date.now().toString(36)}`,
          shortDescription: src.shortDescription,
          description: src.description,
          categoryId: src.categoryId,
          icon: src.icon,
          image: src.image,
          specs: src.specs,
          features: src.features,
          locations: src.locations,
          faqs: src.faqs,
          setupFee: src.setupFee,
          taxRate: src.taxRate,
          currency: src.currency,
          sortOrder: src.sortOrder + 1,
          active: false,
          featured: false,
          bestSeller: false,
          archived: false,
          tags: tagRows.map((t) => t.tagId),
          tagIds: tagRows.map((t) => t.tagId),
          cycles: cycles.map((c) => ({ key: c.key, label: c.label, months: c.months, price: c.price, compareAt: c.compareAt, active: c.active, sortOrder: c.sortOrder })),
          billing: billing[0]
            ? {
                orderingEnabled: billing[0].orderingEnabled,
                billingType: billing[0].billingType,
                destinationUrl: billing[0].destinationUrl,
                urlParams: billing[0].urlParams,
                openIn: billing[0].openIn,
                buttonText: billing[0].buttonText,
                trustedHosts: billing[0].trustedHosts,
              }
            : {},
        },
        actor,
      );
      await logActivity(actor, "plans.duplicate", "plans", copy.id, { from: src.id });
      return json({ row: copy });
    }

    if (action === "approve_payment") {
      const actor = await requireAdmin("payments");
      const rows = await db.select().from(payments).where(eq(payments.id, String(body.id ?? ""))).limit(1);
      const payment = rows[0];
      if (!payment) return fail("Payment not found", 404);
      if (payment.status === "verified") return json({ ok: true, already: true });
      if (!payment.orderId) return fail("This payment is not attached to an order.", 422);
      const order = await settleExternalPayment({
        orderId: payment.orderId,
        method: payment.method,
        externalId: payment.externalId ?? String(body.reference ?? ""),
      });
      if (body.note) await db.update(payments).set({ note: String(body.note).slice(0, 500) }).where(eq(payments.id, payment.id));
      await logActivity(actor, "payments.approve", "payments", payment.id, { order: payment.orderId, amount: payment.amount });
      return json({ ok: true, order, status: order.status });
    }

    if (action === "reject_payment") {
      const actor = await requireAdmin("payments");
      const reason = String(body.reason ?? "").trim();
      if (reason.length < 3) return fail("A rejection reason is required.", 422);
      const rows = await db.select().from(payments).where(eq(payments.id, String(body.id ?? ""))).limit(1);
      const payment = rows[0];
      if (!payment) return fail("Payment not found", 404);
      await db
        .update(payments)
        .set({ status: "rejected", rejectReason: reason.slice(0, 500), updatedAt: new Date() })
        .where(eq(payments.id, payment.id));
      if (payment.orderId) {
        await db.update(orders).set({ status: "failed", updatedAt: new Date() }).where(eq(orders.id, payment.orderId));
      }
      await logActivity(actor, "payments.reject", "payments", payment.id, { reason });
      return json({ ok: true });
    }

    if (action === "adjust_wallet") {
      const actor = await requireAdmin("payments");
      const userId = String(body.userId ?? "");
      const note = String(body.note ?? "").trim();
      if (note.length < 5) return fail("An audit note is mandatory for wallet adjustments.", 422);
      const amount = Math.abs(Math.round(Number(body.amount) * 100) / 100);
      if (!Number.isFinite(amount) || amount === 0) return fail("Enter a non-zero amount.", 422);
      const kind = String(body.kind ?? "credit");
      const type = kind === "debit" ? "debit" : "adjustment";
      const balance = await applyWalletTx({
        userId,
        type,
        amount,
        note: `${kind === "debit" ? "Debit" : "Credit"} — ${note}`,
        actorId: actor.id,
        reference: newRef("adj"),
      });
      await logActivity(actor, "wallet.adjust", "user", userId, { amount, kind, note });
      return json({ ok: true, balance: balance.balance });
    }

    if (action === "refund_order") {
      const actor = await requireAdmin("payments");
      const rows = await db.select().from(orders).where(eq(orders.id, String(body.id ?? ""))).limit(1);
      const order = rows[0];
      if (!order) return fail("Order not found", 404);
      if (!order.userId) return fail("Guest orders cannot be refunded to a wallet.", 422);
      const note = String(body.reason ?? "Refund issued by administrator").slice(0, 500);
      const result = await db.transaction(async (tx) => {
        await tx
          .update(orders)
          .set({ status: "refunded", updatedAt: new Date() })
          .where(eq(orders.id, order.id));
        await tx
          .update(payments)
          .set({ status: "refunded", updatedAt: new Date() })
          .where(eq(payments.orderId, order.id));
        return applyWalletTx({
          userId: order.userId!,
          type: "refund",
          amount: Number(order.total),
          note: `Refund for ${order.planName} — ${note}`,
          orderId: order.id,
          actorId: actor.id,
          reference: newRef("rf"),
        });
      });
      await logActivity(actor, "orders.refund", "orders", order.id, { amount: order.total });
      return json({ ok: true, balance: result.balance });
    }

    if (action === "toggle") {
      const actor = await requireAdmin(String(body.scope ?? "catalog"));
      const table = String(body.table ?? "");
      const map: Record<string, any> = { products, categories, tags };
      const tbl = map[table];
      if (!tbl) return fail("Unsupported toggle target.", 422);
      const rows = await db.select().from(tbl).where(eq(tbl.id, String(body.id ?? ""))).limit(1);
      if (!rows[0]) return fail("Not found", 404);
      const [updated] = await db
        .update(tbl)
        .set({ active: !rows[0].active })
        .where(eq(tbl.id, String(body.id ?? "")))
        .returning();
      await logActivity(actor, `${table}.toggle`, table, String(body.id), { active: updated.active });
      return json({ ok: true, active: updated.active });
    }

    if (action === "reorder") {
      const actor = await requireAdmin(String(body.scope ?? "catalog"));
      const table = String(body.table ?? "");
      const map: Record<string, any> = { products, categories, tags };
      const tbl = map[table];
      if (!tbl) return fail("Unsupported reorder target.", 422);
      const items = Array.isArray(body.items) ? body.items : [];
      for (const item of items) {
        await db.update(tbl).set({ sortOrder: Number(item.sortOrder) }).where(eq(tbl.id, String(item.id)));
      }
      await logActivity(actor, `${table}.reorder`, table);
      return json({ ok: true, count: items.length });
    }

    if (action === "suspend_customer") {
      const actor = await requireAdmin("customers");
      const userId = String(body.id ?? "");
      const rows = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      if (!rows[0]) return fail("Customer not found", 404);
      const status = rows[0].status === "active" ? "suspended" : "active";
      await db.update(users).set({ status, updatedAt: new Date() }).where(eq(users.id, userId));
      await logActivity(actor, "customer.status", "user", userId, { status });
      return json({ ok: true, status });
    }

    return fail("Unknown action.", 422);
  } catch (e) {
    return handleError(e);
  }
}
