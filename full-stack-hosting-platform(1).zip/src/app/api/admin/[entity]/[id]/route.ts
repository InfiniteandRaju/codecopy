import { requireAdmin, json, handleError, fail, logActivity } from "@/lib/api";
import { listEntity, updateEntity, deleteEntity, scopeFor } from "@/lib/admin";
import { db } from "@/db";
import { products, categories, tags, users, orders, payments, settings, homepageSections } from "@/db/schema";
import { eq } from "drizzle-orm";
import { can } from "@/lib/auth";

export const dynamic = "force-dynamic";

async function getOne(entity: string, id: string) {
  switch (entity) {
    case "plans": {
      const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
      if (!rows[0]) return null;
      const all = await listEntity("plans");
      return (all as any[]).find((p) => p.id === id) ?? rows[0];
    }
    case "categories":
      return (await db.select().from(categories).where(eq(categories.id, id)))[0] ?? null;
    case "tags":
      return (await db.select().from(tags).where(eq(tags.id, id)))[0] ?? null;
    case "customers":
      return (await db.select().from(users).where(eq(users.id, id)))[0] ?? null;
    case "orders":
      return (await db.select().from(orders).where(eq(orders.id, id)))[0] ?? null;
    case "payments":
      return (await db.select().from(payments).where(eq(payments.id, id)))[0] ?? null;
    case "settings":
      return (await db.select().from(settings).where(eq(settings.key, id)))[0] ?? null;
    case "homepage":
      return (await db.select().from(homepageSections).where(eq(homepageSections.key, id)))[0] ?? null;
    default:
      return null;
  }
}

export async function GET(_req: Request, ctx: { params: Promise<{ entity: string; id: string }> }) {
  try {
    const { entity, id } = await ctx.params;
    await requireAdmin(scopeFor(entity));
    const row = await getOne(entity, id);
    if (!row) return fail("Not found", 404);
    return json({ row });
  } catch (e) {
    return handleError(e);
  }
}

export async function PUT(req: Request, ctx: { params: Promise<{ entity: string; id: string }> }) {
  try {
    const { entity, id } = await ctx.params;
    const actor = await requireAdmin(scopeFor(entity));
    if (entity === "settings" && !can(actor.role, "*") && actor.role !== "super_admin") {
      const bodyPreview = await req.clone().json().catch(() => ({}));
      if (!["payments", "billing"].includes(String((bodyPreview as any)?.key)))
        return fail("Only a super admin can edit this setting.", 403);
    }
    const body = await req.json().catch(() => ({}));
    const row = await updateEntity(entity, id, body);
    await logActivity(actor, `${entity}.update`, entity, id, { keys: Object.keys(body).slice(0, 20) });
    return json({ row });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ entity: string; id: string }> }) {
  try {
    const { entity, id } = await ctx.params;
    const actor = await requireAdmin(scopeFor(entity));
    const result = await deleteEntity(entity, id);
    await logActivity(actor, `${entity}.delete`, entity, id);
    return json({ ok: true, result });
  } catch (e) {
    return handleError(e);
  }
}
