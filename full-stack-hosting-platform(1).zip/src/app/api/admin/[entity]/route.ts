import { requireAdmin, json, handleError, fail } from "@/lib/api";
import { listEntity, createEntity, scopeFor, createUserAccount } from "@/lib/admin";
import { logActivity } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ entity: string }> }) {
  try {
    const { entity } = await ctx.params;
    const scope = scopeFor(entity);
    await requireAdmin(scope);
    const rows = await listEntity(entity);
    return json({ rows });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST(req: Request, ctx: { params: Promise<{ entity: string }> }) {
  try {
    const { entity } = await ctx.params;
    const scope = scopeFor(entity);
    const actor = await requireAdmin(scope);
    const body = await req.json().catch(() => ({}));
    if (entity === "customers" && body.password) {
      const created = await createUserAccount(body);
      await logActivity(actor, "customer.create", "user", String(created.id), { email: created.email });
      return json({ row: created }, { status: 201 });
    }
    if (entity === "settings" && actor.role !== "super_admin" && body.key !== "homepage") {
      if (!["payments", "billing"].includes(String(body.key))) return fail("Only a super admin can edit this.", 403);
    }
    const row: any = await createEntity(entity, body, actor);
    await logActivity(actor, `${entity}.create`, entity, row?.id ?? row?.key ?? null, {
      name: row?.name ?? row?.key ?? null,
    });
    return json({ row }, { status: 201 });
  } catch (e) {
    return handleError(e);
  }
}
