import { json, fail, handleError, requireAdmin, ApiError } from "@/lib/api";
import { testDatabaseConnection, type DbCandidate, type DbProvider } from "@/lib/dbtest";
import { db } from "@/db";
import { systemConfig } from "@/db/schema";
import { eq } from "drizzle-orm";
import { encryptSecret, decryptSecret } from "@/lib/secrets";

export const dynamic = "force-dynamic";

const SECRET = ["password"];
const KEY = "database";

type StoredConfig = DbCandidate & { backup?: any; appliedAt?: string | null; status?: string };

function publicView(cfg: (StoredConfig & { passwordSet?: boolean }) | null) {
  if (!cfg) return { provider: "postgres", configured: false, password: "", passwordSet: false };
  const { password, ...rest } = cfg;
  return {
    ...rest,
    password: "",
    passwordSet: Boolean(password),
    configured: Boolean(cfg.host || cfg.projectUrl),
    appliedAt: cfg.appliedAt ?? null,
    status: cfg.status ?? "not applied",
  };
}

async function readStored(): Promise<(StoredConfig & { passwordSet?: boolean }) | null> {
  const rows = await db.select().from(systemConfig).where(eq(systemConfig.key, KEY)).limit(1);
  if (!rows[0]) return null;
  const value = { ...((rows[0].value ?? {}) as StoredConfig) } as StoredConfig & { passwordSet?: boolean };
  const plain = decryptSecret(value.password as string);
  value.password = "";
  (value as any).passwordPlain = plain;
  return value;
}

function candidateFrom(body: any, existing: any): DbCandidate {
  const pick = (k: string, fallback: any = "") => (body?.[k] !== undefined && body?.[k] !== null ? body[k] : fallback);
  const provider = (pick("provider", existing?.provider ?? "postgres") as DbProvider) || "postgres";
  // An empty password field means "keep the stored one".
  const password =
    body?.password && body.password !== "••••••••"
      ? String(body.password)
      : ((existing as any)?.passwordPlain ?? "");
  return {
    provider,
    projectUrl: pick("projectUrl", existing?.projectUrl ?? ""),
    host: pick("host", existing?.host ?? ""),
    port: Number(pick("port", existing?.port ?? 5432)) || 5432,
    database: pick("database", existing?.database ?? ""),
    username: pick("username", existing?.username ?? ""),
    password,
    ssl: pick("ssl", existing?.ssl ?? "require") as DbCandidate["ssl"],
    anonKey: pick("anonKey", existing?.anonKey ?? ""),
  };
}

export async function GET() {
  try {
    const actor = await requireAdmin("settings");
    if (actor.role !== "super_admin") throw new ApiError("Only a super administrator can manage database configuration.", 403);
    const stored = await readStored();
    return json({
      current: publicView(stored),
      live: {
        // Non-secret description of what the app is actually running on.
        provider: (process.env.DATABASE_PROVIDER ?? "postgres") as DbProvider,
        host: safeHost(process.env.DATABASE_URL),
        configuredIn: process.env.DATABASE_URL ? "environment (DATABASE_URL)" : "unknown",
      },
      supported: ["postgres", "supabase", "local", "mysql"],
      requiredTables: (await import("@/lib/dbtest")).REQUIRED_TABLES,
    });
  } catch (e) {
    return handleError(e);
  }
}

function safeHost(url?: string) {
  try {
    return new URL(url ?? "").host;
  } catch {
    return null;
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requireAdmin("settings");
    if (actor.role !== "super_admin") throw new ApiError("Only a super administrator can manage database configuration.", 403);
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "test");
    const stored = await readStored();
    const candidate = candidateFrom(body.config ?? body, stored);

    if (action === "test") {
      const result = await testDatabaseConnection(candidate);
      return json({ result });
    }

    if (action === "save" || action === "apply") {
      const result = await testDatabaseConnection(candidate);
      if (!result.ok) {
        // Never store a configuration that cannot connect and verify the schema.
        return json({ applied: false, result }, { status: 422 });
      }
      const previous = stored ? { ...(stored as any), passwordPlain: undefined } : null;
      const toStore: StoredConfig = {
        ...candidate,
        password: encryptSecret(candidate.password ?? ""),
        backup: previous,
        appliedAt: action === "apply" ? new Date().toISOString() : stored?.appliedAt ?? null,
        status: action === "apply" ? "validated — restart required to take effect" : "saved (validated)",
      };
      await db
        .insert(systemConfig)
        .values({ key: KEY, value: toStore as any, updatedBy: actor.id, updatedAt: new Date() })
        .onConflictDoUpdate({ target: systemConfig.key, set: { value: toStore as any, updatedBy: actor.id, updatedAt: new Date() } });
      return json({
        applied: action === "apply",
        result,
        current: publicView(toStore as any),
        note:
          action === "apply"
            ? "Configuration validated, backed up and stored. The running process still holds its original pool: deploy/restart the application to switch connections. If the new connection fails after restart, use Roll back to restore the previous configuration."
            : "Configuration saved and validated. Not applied to the running process.",
      });
    }

    if (action === "rollback") {
      const backup = (stored?.backup ?? null) as StoredConfig | null;
      if (!backup) return fail("No backup available to roll back to.", 404);
      const check = await testDatabaseConnection({ ...backup, password: decryptSecret(backup.password as string) });
      if (!check.ok) return json({ rolledBack: false, result: check }, { status: 422 });
      const restored: StoredConfig = { ...backup, backup: null, status: "rolled back to previous configuration", appliedAt: new Date().toISOString() };
      await db
        .insert(systemConfig)
        .values({ key: KEY, value: restored as any, updatedBy: actor.id, updatedAt: new Date() })
        .onConflictDoUpdate({ target: systemConfig.key, set: { value: restored as any, updatedBy: actor.id, updatedAt: new Date() } });
      return json({ rolledBack: true, result: check, current: publicView(restored as any) });
    }

    if (action === "clear") {
      await db.delete(systemConfig).where(eq(systemConfig.key, KEY));
      return json({ cleared: true });
    }

    return fail("Unknown database configuration action.", 422);
  } catch (e) {
    return handleError(e);
  }
}
