import { json, fail, handleError, requireAdmin, logActivity } from "@/lib/api";
import { getConsoleConfig, saveConsoleConfig, consoleStatus, fetchFromPanel } from "@/lib/console";

export const dynamic = "force-dynamic";

function hasControlChars(value: string): boolean {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code < 32 || code === 127) return true;
  }
  return false;
}

export async function GET() {
  try {
    await requireAdmin("orders");
    return json({ status: await consoleStatus() });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requireAdmin("orders");
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "status");

    if (action === "configure") {
      if (actor.role !== "super_admin") return fail("Only a super administrator can configure the console integration.", 403);
      await saveConsoleConfig(
        {
          enabled: Boolean(body.enabled),
          baseUrl: String(body.baseUrl ?? "").trim(),
          ...(body.token ? { token: String(body.token) } : {}),
          serversPath: String(body.serversPath || "/api/client/servers"),
          commandPath: String(body.commandPath || "/command"),
          logPath: String(body.logPath || "/logs"),
          resourcePath: String(body.resourcePath || "/resources"),
          timeoutMs: Math.min(30000, Math.max(2000, Number(body.timeoutMs) || 8000)),
        },
        actor.id,
      );
      await logActivity(actor, "console.configure", "system", "console", { baseUrl: String(body.baseUrl ?? "") });
      return json({ status: await consoleStatus() });
    }

    const cfg = await getConsoleConfig();
    if (!cfg.configured) {
      return fail(
        "No server-management API configured. Add the panel base URL and API token in Admin -> Settings -> Console integration before using the console.",
        503,
      );
    }

    if (action === "status" || action === "servers") return json({ status: await consoleStatus() });

    const serverId = String(body.serverId ?? "").trim();
    if (!serverId) return fail("Select a server first.", 422);

    if (action === "command") {
      const command = String(body.command ?? "").slice(0, 500).trim();
      if (!command) return fail("Enter a command.", 422);
      if (hasControlChars(command)) return fail("Control characters are not allowed.", 422);
      const result = await fetchFromPanel(cfg, `${cfg.serversPath}/${encodeURIComponent(serverId)}${cfg.commandPath}`, "POST", {
        command,
      });
      await logActivity(actor, "console.command", "server", serverId, { command });
      return json({ ok: true, result });
    }

    if (action === "logs") {
      const result = await fetchFromPanel(cfg, `${cfg.serversPath}/${encodeURIComponent(serverId)}${cfg.logPath}`, "GET");
      return json({ ok: true, result });
    }

    if (action === "resources") {
      const result = await fetchFromPanel(cfg, `${cfg.serversPath}/${encodeURIComponent(serverId)}${cfg.resourcePath}`, "GET");
      return json({ ok: true, result });
    }

    return fail("Unknown console action.", 422);
  } catch (e) {
    return handleError(e);
  }
}
