import { json, fail, handleError, requireAdmin, ApiError, logActivity } from "@/lib/api";
import { getFreeServerSettings, sweepExpiredDemoServers, type FreeServerSettings } from "@/lib/freeserver";
import { provisioningStatus, saveProvisionConfig, stopExternalServer, deleteExternalServer, updateServerLimits, getProvisionConfig } from "@/lib/provision";
import { db } from "@/db";
import { demoServers, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Full demo-server administration: settings, provisioning and the server table. */
export async function GET() {
  try {
    const actor = await requireAdmin("catalog");
    const [settings, provisioning, sweep] = await Promise.all([
      getFreeServerSettings(),
      provisioningStatus(),
      sweepExpiredDemoServers(),
    ]);
    const rows = await db
      .select({
        server: demoServers,
        customer: users.name,
        email: users.email,
        userStatus: users.status,
      })
      .from(demoServers)
      .leftJoin(users, eq(demoServers.userId, users.id))
      .orderBy(desc(demoServers.createdAt))
      .limit(300);
    return json({ settings, provisioning, servers: rows, sweep, actorRole: actor.role });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST(req: Request) {
  try {
    const actor = await requireAdmin("catalog");
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "");

    if (action === "save_settings") {
      // Merge over the stored (and default-filled) configuration first, so a
      // partial payload from the UI can never silently wipe another group.
      const { getFreeServerSettings: readStored } = await import("@/lib/freeserver");
      const base = await readStored();
      const merged = deepMerge(base as any, (body.value ?? {}) as any);
      const value = sanitizeFreeServer(merged as any);
      await db
        .insert((await import("@/db/schema")).settings)
        .values({ key: "freeServer", value: value as any, updatedAt: new Date() })
        .onConflictDoUpdate({
          target: (await import("@/db/schema")).settings.key,
          set: { value: value as any, updatedAt: new Date() },
        });
      await logActivity(actor, "free_server.settings", "settings", "freeServer", { enabled: value.enabled });
      return json({ ok: true, settings: await getFreeServerSettings() });
    }

    if (action === "save_provisioning") {
      if (actor.role !== "super_admin") throw new ApiError("Only a super administrator can configure provisioning credentials.", 403);
      await saveProvisionConfig(
        {
          enabled: Boolean(body.enabled),
          baseUrl: String(body.baseUrl ?? "").trim(),
          ...(body.appKey ? { appKey: String(body.appKey) } : {}),
          ...(body.clientToken ? { clientToken: String(body.clientToken) } : {}),
          nodeStrategy: body.nodeStrategy === "fixed" ? "fixed" : "auto",
          fixedNodeId: Number(body.fixedNodeId) || 0,
          defaultEgg: Number(body.defaultEgg) || 0,
          defaultDockerImage: String(body.defaultDockerImage ?? "").trim(),
          allocationPort: Number(body.allocationPort) || 25565,
          environment: typeof body.environment === "object" && body.environment ? body.environment : {},
        },
        actor.id,
      );
      await logActivity(actor, "free_server.provisioning", "system", "provisioning", { baseUrl: body.baseUrl });
      return json({ ok: true, provisioning: await provisioningStatus() });
    }

    const cfg = await getFreeServerSettings();
    const id = String(body.id ?? "");
    const server = id ? (await db.select().from(demoServers).where(eq(demoServers.id, id)).limit(1))[0] : null;

    if (action === "sweep") {
      const result = await sweepExpiredDemoServers();
      return json({ ok: true, ...result });
    }

    if (!server) return fail("Demo server not found.", 404);

    if (action === "stop") {
      if (server.externalId) await stopExternalServer(server.externalId).catch((e: any) => ({ error: e.message }));
      await db.update(demoServers).set({ status: "stopped", stoppedAt: new Date(), updatedAt: new Date() }).where(eq(demoServers.id, id));
      await logActivity(actor, "free_server.stop", "demo_servers", id);
      return json({ ok: true });
    }

    if (action === "terminate") {
      if (server.externalId) await deleteExternalServer(server.externalId);
      await db.update(demoServers).set({ status: "terminated", stoppedAt: new Date(), updatedAt: new Date() }).where(eq(demoServers.id, id));
      await logActivity(actor, "free_server.terminate", "demo_servers", id);
      return json({ ok: true });
    }

    if (action === "extend") {
      const minutes = Math.min(10080, Math.max(5, Number(body.minutes) || cfg.duration.extensionMinutes));
      const base = Math.max(server.expiresAt?.getTime() ?? Date.now(), Date.now());
      const next = new Date(base + minutes * 60_000);
      await db.update(demoServers).set({ expiresAt: next, status: server.status === "expired" ? "stopped" : server.status, updatedAt: new Date() }).where(eq(demoServers.id, id));
      await logActivity(actor, "free_server.extend", "demo_servers", id, { minutes });
      return json({ ok: true, expiresAt: next.toISOString() });
    }

    if (action === "allocate") {
      // Reallocation is validated against the administrator's own option lists.
      const ram = Number(body.ramMb);
      const cpu = Number(body.cpuPercent);
      const disk = Number(body.diskMb);
      if (!cfg.ram.options.includes(ram)) throw new ApiError("RAM value is not in the configured option list.", 422);
      if (!cfg.cpu.options.includes(cpu)) throw new ApiError("CPU value is not in the configured option list.", 422);
      if (!cfg.disk.options.includes(disk)) throw new ApiError("Disk value is not in the configured option list.", 422);
      if (server.externalId) await updateServerLimits(server.externalId, { memory: ram, cpu, disk: disk });
      await db
        .update(demoServers)
        .set({ ramMb: ram, cpuPercent: cpu, diskMb: disk, updatedAt: new Date() })
        .where(eq(demoServers.id, id));
      await logActivity(actor, "free_server.allocate", "demo_servers", id, { ram, cpu, disk });
      return json({ ok: true });
    }

    if (action === "block_user") {
      if (!server.userId) return fail("This demo has no owner.", 422);
      await db.update(users).set({ status: "suspended", updatedAt: new Date() }).where(eq(users.id, server.userId));
      const owned = await db.select().from(demoServers).where(eq(demoServers.userId, server.userId));
      for (const s of owned) {
        if (s.externalId && ["running", "pending", "stopped"].includes(s.status)) {
          await deleteExternalServer(s.externalId).catch(() => {});
          await db.update(demoServers).set({ status: "terminated", stoppedAt: new Date(), updatedAt: new Date() }).where(eq(demoServers.id, s.id));
        }
      }
      await logActivity(actor, "customer.block", "user", server.userId, { demos: owned.length });
      return json({ ok: true, blocked: owned.length });
    }

    if (action === "unblock_user") {
      if (!server.userId) return fail("This demo has no owner.", 422);
      await db.update(users).set({ status: "active", updatedAt: new Date() }).where(eq(users.id, server.userId));
      await logActivity(actor, "customer.unblock", "user", server.userId);
      return json({ ok: true });
    }

    return fail("Unknown free-server action.", 422);
  } catch (e) {
    return handleError(e);
  }
}

/** Plain object merge used to protect settings groups from partial writes. */
function deepMerge(base: any, patch: any): any {
  if (patch == null) return base;
  if (Array.isArray(base)) return Array.isArray(patch) ? patch : base;
  if (typeof base !== "object" || base === null) return patch ?? base;
  const out: any = { ...base };
  for (const [k, v] of Object.entries(patch)) out[k] = k in base ? deepMerge(base[k], v) : v;
  return out;
}

/** Option lists and limits are normalised before they reach the database. */
export function sanitizeFreeServer(value: Partial<FreeServerSettings>): FreeServerSettings {
  const v = value as any;
  const nums = (list: unknown, fallback: number[]) => {
    const arr = Array.isArray(list) ? list.map(Number).filter((n) => Number.isFinite(n) && n > 0) : [];
    return arr.length ? [...new Set(arr)].sort((a, b) => a - b).slice(0, 40) : fallback;
  };
  const clamped = (n: unknown, min: number, max: number, fb: number) =>
    Number.isFinite(Number(n)) ? Math.min(max, Math.max(min, Number(n))) : fb;

  return {
    enabled: Boolean(v.enabled ?? true),
    title: String(v.title ?? "Build your free demo server").slice(0, 140),
    description: String(v.description ?? "").slice(0, 600),
    banner: String(v.banner ?? "").slice(0, 400),
    cta: String(v.cta ?? "Create Free Server").slice(0, 60),
    requireRegistration: Boolean(v.requireRegistration ?? true),
    currency: String(v.currency ?? "INR").slice(0, 8),
    defaults: {
      ramMb: clamped(v.defaults?.ramMb, 512, 65536, 2048),
      cpuPercent: clamped(v.defaults?.cpuPercent, 25, 1000, 100),
      diskMb: clamped(v.defaults?.diskMb, 1024, 1048576, 10240),
      durationMinutes: clamped(v.defaults?.durationMinutes, 5, 4320, 180),
      software: String(v.defaults?.software ?? "paper").slice(0, 40),
    },
    ram: {
      freeMb: clamped(v.ram?.freeMb, 0, 262144, 2048),
      maxMb: clamped(v.ram?.maxMb, 256, 524288, 8192),
      options: nums(v.ram?.options, [512, 1024, 2048, 4096, 8192]),
      allowPaid: Boolean(v.ram?.allowPaid ?? true),
      pricePerGb: clamped(v.ram?.pricePerGb, 0, 100000, 49),
    },
    cpu: {
      freePercent: clamped(v.cpu?.freePercent, 0, 4000, 100),
      maxPercent: clamped(v.cpu?.maxPercent, 25, 8000, 200),
      options: nums(v.cpu?.options, [50, 100, 150, 200]),
      allowPaid: Boolean(v.cpu?.allowPaid ?? true),
      pricePer100: clamped(v.cpu?.pricePer100, 0, 100000, 39),
    },
    disk: {
      freeMb: clamped(v.disk?.freeMb, 0, 1048576, 10240),
      maxMb: clamped(v.disk?.maxMb, 1024, 4194304, 20480),
      options: nums(v.disk?.options, [5120, 10240, 15360, 20480]),
      allowPaid: Boolean(v.disk?.allowPaid ?? true),
      pricePerGb: clamped(v.disk?.pricePerGb, 0, 100000, 9),
      type: String(v.disk?.type ?? "NVMe SSD").slice(0, 40),
    },
    duration: {
      options: nums(v.duration?.options, [60, 180, 360, 720, 1440, 4320]).filter((n) => n <= 43200),
      defaultMinutes: clamped(v.duration?.defaultMinutes, 5, 4320, 180),
      maxMinutes: clamped(v.duration?.maxMinutes, 5, 43200, 4320),
      allowExtension: Boolean(v.duration?.allowExtension ?? true),
      extensionMinutes: clamped(v.duration?.extensionMinutes, 5, 10080, 180),
      expireAction: v.duration?.expireAction === "delete" ? "delete" : "stop",
      cleanup: v.duration?.cleanup !== false,
    },
    software: Array.isArray(v.software)
      ? v.software
          .map((s: any, i: number) => ({
            id: String(s?.id ?? `sw${i}`).slice(0, 40),
            name: String(s?.name ?? "").slice(0, 80),
            version: String(s?.version ?? "").slice(0, 40),
            enabled: Boolean(s?.enabled ?? true),
            egg: s?.egg ? Number(s.egg) : null,
            dockerImage: String(s?.dockerImage ?? "").slice(0, 200),
            startup: String(s?.startup ?? "").slice(0, 500),
          }))
          .filter((s: any) => s.name)
          .slice(0, 40)
      : [],
    access: {
      oneActivePerUser: v.access?.oneActivePerUser !== false,
      maxPerAccount: clamped(v.access?.maxPerAccount, 1, 20, 1),
      cooldownMinutes: clamped(v.access?.cooldownMinutes, 0, 10080, 60),
      maxActiveGlobal: clamped(v.access?.maxActiveGlobal, 1, 5000, 25),
      ipLimit: clamped(v.access?.ipLimit, 0, 100, 3),
      ipWindowMinutes: clamped(v.access?.ipWindowMinutes, 1, 10080, 60),
    },
  };
}
