import { db } from "@/db";
import {
  users,
  products,
  categories,
  orders,
  payments,
  walletAccounts,
  walletTransactions,
  activityLogs,
} from "@/db/schema";
import { sql, eq, gte, desc, and } from "drizzle-orm";
import { requireAdmin, json, handleError } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await requireAdmin("orders");
    const since = new Date(Date.now() - 30 * 864e5);

    const [
      customerCount,
      planCount,
      activeCategories,
      orderCount,
      pendingPayments,
      successfulPayments,
      revenue,
      walletTotal,
      recentOrders,
      recentPayments,
      recentCustomers,
      activity,
      revenueSeries,
      orderSeries,
      methodMix,
      categoryMix,
      bestPlans,
    ] = await Promise.all([
      db.select({ n: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "customer")),
      db.select({ n: sql<number>`count(*)::int` }).from(products),
      db.select({ n: sql<number>`count(*)::int` }).from(categories).where(eq(categories.active, true)),
      db.select({ n: sql<number>`count(*)::int` }).from(orders),
      db.select({ n: sql<number>`count(*)::int` }).from(payments).where(eq(payments.status, "awaiting_verification")),
      db
        .select({ n: sql<number>`count(*)::int` })
        .from(payments)
        .where(eq(payments.status, "verified")),
      db
        .select({
          total: sql<string>`coalesce(sum(${orders.total}) filter (where ${orders.status} in ('paid','active','processing')), 0)`,
        })
        .from(orders),
      db.select({ total: sql<string>`coalesce(sum(${walletAccounts.balance}), 0)` }).from(walletAccounts),
      db
        .select({ id: orders.id, reference: orders.reference, plan: orders.planName, total: orders.total, status: orders.status, createdAt: orders.createdAt, customer: users.name })
        .from(orders)
        .leftJoin(users, eq(orders.userId, users.id))
        .orderBy(desc(orders.createdAt))
        .limit(8),
      db
        .select({ id: payments.id, reference: payments.reference, method: payments.method, amount: payments.amount, status: payments.status, createdAt: payments.createdAt })
        .from(payments)
        .orderBy(desc(payments.createdAt))
        .limit(8),
      db
        .select({ id: users.id, name: users.name, email: users.email, createdAt: users.createdAt })
        .from(users)
        .where(eq(users.role, "customer"))
        .orderBy(desc(users.createdAt))
        .limit(6),
      db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(12),
      db
        .select({
          day: sql<string>`to_char(date_trunc('day', ${orders.createdAt}), 'YYYY-MM-DD')`,
          total: sql<string>`coalesce(sum(${orders.total}), 0)`,
        })
        .from(orders)
        .where(gte(orders.createdAt, since))
        .groupBy(sql`1`)
        .orderBy(sql`1`),
      db
        .select({
          day: sql<string>`to_char(date_trunc('day', ${orders.createdAt}), 'YYYY-MM-DD')`,
          n: sql<number>`count(*)::int`,
        })
        .from(orders)
        .where(gte(orders.createdAt, since))
        .groupBy(sql`1`)
        .orderBy(sql`1`),
      db
        .select({ method: payments.method, n: sql<number>`count(*)::int` })
        .from(payments)
        .groupBy(payments.method),
      db
        .select({
          name: categories.name,
          n: sql<number>`count(distinct ${products.id})::int`,
        })
        .from(products)
        .innerJoin(categories, eq(products.categoryId, categories.id))
        .where(eq(products.active, true))
        .groupBy(categories.name)
        .orderBy(sql`2 desc`)
        .limit(6),
      db
        .select({ name: products.name, sales: sql<number>`count(${orders.id})::int`, revenue: sql<string>`coalesce(sum(${orders.total}),0)` })
        .from(orders)
        .innerJoin(products, eq(orders.productId, products.id))
        .groupBy(products.name)
        .orderBy(sql`2 desc`)
        .limit(6),
    ]);

    // Fill the 30-day series so the chart has no gaps.
    const revMap = new Map(revenueSeries.map((r) => [r.day, Number(r.total)]));
    const ordMap = new Map(orderSeries.map((r) => [r.day, r.n]));
    const series = Array.from({ length: 30 }, (_, i) => {
      const d = new Date(Date.now() - (29 - i) * 864e5);
      const key = d.toISOString().slice(0, 10);
      return { day: key, revenue: revMap.get(key) ?? 0, orders: ordMap.get(key) ?? 0 };
    });

    const pendingCount = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, "pending"));

    return json({
      totals: {
        customers: customerCount[0].n,
        plans: planCount[0].n,
        activeCategories: activeCategories[0].n,
        orders: orderCount[0].n,
        pendingOrders: pendingCount[0].n,
        pendingPayments: pendingPayments[0].n,
        successfulPayments: successfulPayments[0].n,
        revenue: Number(revenue[0].total),
        walletBalance: Number(walletTotal[0].total),
      },
      series,
      methodMix: methodMix.map((m) => ({ method: m.method || "unknown", count: m.n })),
      categoryMix,
      bestPlans,
      recentOrders,
      recentPayments,
      recentCustomers,
      activity,
    });
  } catch (e) {
    return handleError(e);
  }
}
