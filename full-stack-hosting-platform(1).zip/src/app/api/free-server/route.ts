import { json, fail, handleError, requireUser, rateLimit, ApiError } from "@/lib/api";
import { getFreeServerSettings, validateSelection, assertAccessAllowed, priceSelection, sweepExpiredDemoServers } from "@/lib/freeserver";
import { createDemoServer, provisioningStatus } from "@/lib/provision";
import { getBalance, applyWalletTx, newRef } from "@/lib/wallet";
import { db } from "@/db";
import { demoServers } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** My demo servers, with expired ones swept first so the list is always truthful. */
export async function GET() {
  try {
    const user = await requireUser();
    await sweepExpiredDemoServers().catch(() => ({ processed: 0, errors: [] }));
    const rows = await db
      .select()
      .from(demoServers)
      .where(eq(demoServers.userId, user.id))
      .orderBy(desc(demoServers.createdAt))
      .limit(50);
    const settings = await getFreeServerSettings();
    const provisioning = await provisioningStatus();
    return json({ servers: rows, settings, provisioning });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
    if (!rateLimit(`freeserver:${user.id}`, 6, 300_000)) return fail("You are creating demos too quickly.", 429);

    const body = await req.json().catch(() => ({}));
    const cfg = await getFreeServerSettings();

    // Server-side validation — RAM, CPU, disk, duration and software must all
    // exist in the administrator's configuration. Browser values are inputs, not truth.
    const sel = validateSelection(cfg, body);

    // Availability first: when no backend exists the visitor must see the real
    // reason, not a rate-limit message that hides it.
    const provisioning = await provisioningStatus();
    if (!provisioning.configured) return fail(provisioning.message, 503);

    await assertAccessAllowed(cfg, { userId: user.id, ip });
    const price = priceSelection(cfg, sel);

    // Never charge before the server exists: check the wallet, provision, then debit.
    if (price.total > 0) {
      const balance = await getBalance(user.id);
      if (balance < price.total) {
        return fail(
          `This configuration includes paid upgrades totalling ${price.currency === "INR" ? "₹" : ""}${price.total}. Top up your wallet to activate it.`,
          402,
        );
      }
    }

    const software = cfg.software.find((s) => s.id === sel.software)!;
    const reference = `DEMO${randomRef()}`;
    const created = await createDemoServer({
      reference,
      name: sel.name,
      email: user.email,
      ownerName: user.name,
      ramMb: sel.ramMb,
      cpuPercent: sel.cpuPercent,
      diskMb: sel.diskMb,
      startup: software.startup,
      dockerImage: software.dockerImage || undefined,
      environment: { SERVER_MEMORY: String(sel.ramMb) },
    }).catch(async (e: any) => {
      // No fake server, no charge: surface the real provisioning error.
      throw new ApiError(e?.message ?? "Provisioning failed.", e?.status ?? 502);
    });

    if (price.total > 0) {
      try {
        await applyWalletTx({
          userId: user.id,
          type: "debit",
          amount: price.total,
          note: `Demo server ${reference} — paid upgrade (${sel.ramMb} MB / ${sel.cpuPercent}% CPU / ${sel.diskMb} MB disk)`,
          reference: `demo_${reference}`,
        });
      } catch (e) {
        // Roll back the freshly created server if we cannot take payment.
        const { deleteExternalServer } = await import("@/lib/provision");
        await deleteExternalServer(created.externalId).catch(() => {});
        throw e;
      }
    }

    const expiresAt = new Date(Date.now() + sel.durationMinutes * 60_000);
    const row = (
      await db
        .insert(demoServers)
        .values({
          reference,
          userId: user.id,
          name: sel.name,
          software: software.id,
          version: software.version,
          ramMb: sel.ramMb,
          cpuPercent: sel.cpuPercent,
          diskMb: sel.diskMb,
          durationMinutes: sel.durationMinutes,
          price: price.total.toFixed(2),
          status: "running",
          externalId: created.externalId,
          panelUrl: created.url,
          expiresAt,
          createdIp: ip,
          meta: { lines: price.lines, node: created.nodeId, software: software.name },
        })
        .returning()
    )[0];

    return json({ ok: true, server: row, price, expiresAt: expiresAt.toISOString() }, { status: 201 });
  } catch (e) {
    return handleError(e);
  }
}

function randomRef() {
  let out = "";
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  for (let i = 0; i < 8; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}
