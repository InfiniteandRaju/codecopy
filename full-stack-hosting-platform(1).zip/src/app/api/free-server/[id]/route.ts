import { json, fail, handleError, requireUser, ApiError } from "@/lib/api";
import { getFreeServerSettings } from "@/lib/freeserver";
import { getExternalServer, startExternalServer, stopExternalServer, restartExternalServer } from "@/lib/provision";
import { db } from "@/db";
import { demoServers } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/**
 * Customer-facing control of their OWN demo servers. Ownership is verified on
 * every request — a customer can never reach another customer's server.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const body = await req.json().catch(() => ({}));
    const action = String(body.action ?? "info");

    const rows = await db.select().from(demoServers).where(eq(demoServers.id, id)).limit(1);
    const server = rows[0];
    if (!server) return fail("Demo server not found.", 404);
    if (server.userId !== user.id) return fail("You do not own that demo server.", 403);

    const cfg = await getFreeServerSettings();
    const now = new Date();
    const expired = server.expiresAt ? server.expiresAt.getTime() <= now.getTime() : false;

    if (action === "info") {
      let external: any = null;
      let syncError: string | null = null;
      if (server.externalId) {
        try {
          external = await getExternalServer(server.externalId);
          // Keep the stored status in sync with the panel so the UI is truthful.
          if (external?.status && external.status !== server.status) {
            const mapped = mapPanelStatus(external.status);
            await db
              .update(demoServers)
              .set({ status: mapped, updatedAt: new Date() })
              .where(eq(demoServers.id, server.id));
            server.status = mapped;
          }
        } catch (e: any) {
          syncError = e?.message ?? "Panel unreachable";
        }
      }
      return json({ server, external, syncError, expired });
    }

    if (expired) {
      return fail(
        cfg.duration.expireAction === "delete"
          ? "This demo expired and was destroyed. Create a new one."
          : "This demo has expired. Create a new one or ask an administrator to extend it.",
        410,
      );
    }
    if (["running", "stopped", "pending"].includes(server.status) === false) {
      return fail(`This demo is ${server.status} and cannot be controlled.`, 409);
    }
    if (!server.externalId) return fail("This demo has no provisioned backend server.", 409);

    if (action === "start") {
      await startExternalServer(server.externalId);
      await db.update(demoServers).set({ status: "running", stoppedAt: null, updatedAt: new Date() }).where(eq(demoServers.id, server.id));
      return json({ ok: true, status: "running" });
    }
    if (action === "stop") {
      await stopExternalServer(server.externalId);
      await db.update(demoServers).set({ status: "stopped", stoppedAt: new Date(), updatedAt: new Date() }).where(eq(demoServers.id, server.id));
      return json({ ok: true, status: "stopped" });
    }
    if (action === "restart") {
      await restartExternalServer(server.externalId);
      return json({ ok: true, status: "running" });
    }
    if (action === "extend") {
      if (!cfg.duration.allowExtension) throw new ApiError("Extensions are disabled by the administrator.", 403);
      if (!server.expiresAt) throw new ApiError("This demo has no expiry to extend.", 409);
      const base = Math.max(server.expiresAt.getTime(), Date.now());
      const cap = Date.now() + cfg.duration.maxMinutes * 60_000;
      const next = new Date(Math.min(base + cfg.duration.extensionMinutes * 60_000, cap));
      if (next.getTime() <= server.expiresAt!.getTime()) {
        throw new ApiError(`Maximum demo duration of ${cfg.duration.maxMinutes} minutes reached.`, 409);
      }
      await db.update(demoServers).set({ expiresAt: next, updatedAt: new Date() }).where(eq(demoServers.id, server.id));
      return json({ ok: true, expiresAt: next.toISOString() });
    }

    return fail("Unknown action.", 422);
  } catch (e) {
    return handleError(e);
  }
}

function mapPanelStatus(status: string): string {
  const s = status.toLowerCase();
  if (s === "running") return "running";
  if (s === "starting") return "pending";
  if (s === "stopping" || s === "stopped") return "stopped";
  if (s === "installing") return "pending";
  if (s === "suspended") return "suspended";
  if (s === "failed") return "failed";
  return "stopped";
}
