import { json, handleError } from "@/lib/api";
import { getFreeServerSettings } from "@/lib/freeserver";
import { provisioningStatus } from "@/lib/provision";

export const dynamic = "force-dynamic";

/**
 * Public configurator configuration. Everything here is editable in
 * /admin/free-server — no RAM/CPU/disk/duration option is hardcoded in the UI.
 * The provisioning status tells the browser whether creation is actually
 * possible, so the page never pretends a backend exists.
 */
export async function GET() {
  try {
    const [config, provisioning] = await Promise.all([getFreeServerSettings(), provisioningStatus()]);
    return json({
      config,
      provisioning: {
        configured: provisioning.configured,
        message: provisioning.message,
        baseUrl: provisioning.baseUrl ?? null,
      },
    });
  } catch (e) {
    return handleError(e);
  }
}
