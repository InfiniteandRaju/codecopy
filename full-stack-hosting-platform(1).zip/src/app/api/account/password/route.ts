import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { currentUser, hashPassword, verifyPassword } from "@/lib/auth";
import { json, fail, handleError, rateLimit, logActivity } from "@/lib/api";

/** Password change — also clears the must-change-password flag on seeded accounts. */
export async function PUT(req: Request) {
  try {
    const user = await currentUser();
    if (!user) return fail("Not authenticated", 401);
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit(`pw:${user.id}`, 10, 300_000)) return fail("Too many attempts. Try again in a few minutes.", 429);

    const body = await req.json().catch(() => ({}));
    const current = String(body.currentPassword ?? "");
    const next = String(body.newPassword ?? "");
    if (next.length < 8 || !/[a-zA-Z]/.test(next) || !/\d/.test(next))
      return fail("New password must be at least 8 characters and include a letter and a number.", 422);
    if (next === current) return fail("Choose a password different from the current one.", 422);
    if (!verifyPassword(current, user.passwordHash)) return fail("Current password is incorrect.", 422);

    await db
      .update(users)
      .set({ passwordHash: hashPassword(next), mustChangePassword: false, updatedAt: new Date() })
      .where(eq(users.id, user.id));
    await logActivity({ id: user.id, name: user.name }, "auth.password_change", "user", user.id, {}, ip);
    return json({ ok: true, mustChangePassword: false });
  } catch (e) {
    return handleError(e);
  }
}
