import { db } from "@/db";
import { orders, payments, products } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { json, fail, handleError } from "@/lib/api";
import { resolveBilling, getSettings } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await currentUser();
    if (!user) return fail("Not authenticated", 401);
    const rows = await db
      .select({ order: orders, product: products })
      .from(orders)
      .leftJoin(products, eq(orders.productId, products.id))
      .where(eq(orders.userId, user.id))
      .orderBy(desc(orders.createdAt))
      .limit(100);
    const orderIds = rows.map((r) => r.order.id);
    const payRows = orderIds.length
      ? await db.select().from(payments).where(eq(payments.userId, user.id))
      : [];
    const settings = await getSettings();

    return json({
      orders: rows.map((r) => {
        const billing =
          r.product && r.product.active
            ? resolveBilling(null, r.product, { billing_cycle: r.order.cycleKey })
            : { mode: "manual", url: null, openIn: "same", buttonText: "Contact sales" };
        return {
          ...r.order,
          planSlug: r.product?.slug ?? ((r.order.meta as Record<string, any>)?.planSlug ?? null),
          categorySlug: null,
          payments: payRows.filter((p) => p.orderId === r.order.id),
          repurchaseUrl: billing.url,
        };
      }),
      currencySymbol: settings.currencySymbol,
    });
  } catch (e) {
    return handleError(e);
  }
}
