import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { json, fail, handleError, rateLimit } from "@/lib/api";

export async function PUT(req: Request) {
  try {
    const user = await currentUser();
    if (!user) return fail("Not authenticated", 401);
    if (!rateLimit(`profile:${user.id}`, 20, 60_000)) return fail("Too many attempts.", 429);
    const body = await req.json().catch(() => ({}));
    const name = String(body.name ?? "").trim();
    if (name.length < 2 || name.length > 120) return fail("Enter a valid name.", 422);
    const [updated] = await db
      .update(users)
      .set({ name, updatedAt: new Date() })
      .where(eq(users.id, user.id))
      .returning({ id: users.id, name: users.name, email: users.email });
    return json({ user: updated });
  } catch (e) {
    return handleError(e);
  }
}
