import { currentUser } from "@/lib/auth";
import { getBalance } from "@/lib/wallet";
import { json } from "@/lib/api";

export async function GET() {
  const user = await currentUser();
  if (!user) return json({ user: null });
  const balance = user.role === "customer" || user.role === "super_admin" ? await getBalance(user.id) : 0;
  return json({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
      createdAt: user.createdAt,
      walletBalance: balance,
    },
  });
}
