import { db } from "@/db";
import { users, walletAccounts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, setSessionCookie } from "@/lib/auth";
import { json, fail, rateLimit, logActivity, handleError } from "@/lib/api";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit(`register:${ip}`, 10, 60_000)) return fail("Too many attempts. Try again shortly.", 429);
    const body = await req.json().catch(() => ({}));
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");

    if (name.length < 2 || name.length > 120) return fail("Enter your full name.", 422);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return fail("Enter a valid email address.", 422);
    if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password))
      return fail("Password must be at least 8 characters and include a letter and a number.", 422);

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing[0]) return fail("An account with that email already exists.", 409);

    const inserted = await db
      .insert(users)
      .values({ name, email, passwordHash: hashPassword(password), role: "customer", status: "active" })
      .returning();
    const user = inserted[0];
    await db.insert(walletAccounts).values({ userId: user.id, balance: "0" }).onConflictDoNothing();
    await setSessionCookie(user, req);
    await logActivity({ id: user.id, name: user.name }, "customer.register", "user", user.id, {}, ip);
    return json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (e) {
    return handleError(e);
  }
}
