import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword, setSessionCookie, isAdminRole } from "@/lib/auth";
import { json, fail, rateLimit, logActivity, handleError } from "@/lib/api";

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "local";
    if (!rateLimit(`login:${ip}`, 12, 60_000)) return fail("Too many attempts. Try again shortly.", 429);
    const body = await req.json().catch(() => ({}));
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!email || !password) return fail("Email and password are required.", 422);

    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    // Uniform failure message — do not reveal whether the account exists.
    if (!user || !verifyPassword(password, user.passwordHash)) return fail("Invalid email or password.", 401);
    if (user.status !== "active") return fail("This account has been suspended. Contact support.", 403);

    await setSessionCookie(user, req);
    await logActivity({ id: user.id, name: user.name }, "auth.login", "user", user.id, {}, ip);
    return json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      redirectTo: isAdminRole(user.role) ? "/admin" : "/account",
    });
  } catch (e) {
    return handleError(e);
  }
}
