import { notFound, redirect } from "next/navigation";
import { db } from "@/db";
import { billingConfigurations, products, orders } from "@/db/schema";
import { and, eq, desc, gte } from "drizzle-orm";
import { currentUser } from "@/lib/auth";
import { getSettings, resolveBilling } from "@/lib/data";
import { createCheckout, enabledMethods } from "@/lib/checkout";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { CheckoutClient } from "@/components/site/CheckoutClient";

export const dynamic = "force-dynamic";

/**
 * Internal plan redirect target. A plan configured with an internal path such
 * as /order/minecraft-premium resolves against the canonical domain and lands
 * here, where the order is completed inside this site.
 */
export default async function InternalOrderPage({
  params,
  searchParams,
}: {
  params: Promise<{ path: string[] }>;
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const { path } = await params;
  const sp = await searchParams;
  const requested = "/" + path.map((s) => decodeURIComponent(s)).join("/");
  const normalized = requested.length > 1 && requested.endsWith("/") ? requested.slice(0, -1) : requested;

  const rows = await db
    .select({ config: billingConfigurations, product: products })
    .from(billingConfigurations)
    .innerJoin(products, eq(billingConfigurations.productId, products.id))
    .where(eq(billingConfigurations.redirectPath, normalized))
    .limit(1);

  const row = rows[0];
  if (!row || !row.product.active || row.product.archived) notFound();

  const user = await currentUser();
  if (!user) {
    const qs = new URLSearchParams(
      Object.entries(sp).filter(([, v]) => Boolean(v)) as [string, string][],
    ).toString();
    redirect(`/login?next=${encodeURIComponent(`${normalized}${qs ? `?${qs}` : ""}`)}`);
  }

  const cycleKey = sp.billing_cycle ?? "monthly";
  const location = sp.location ?? "";
  const coupon = sp.coupon ?? "";

  // Reuse a recent pending order for the same configuration instead of
  // creating a duplicate when the customer reloads.
  const existing = await db
    .select()
    .from(orders)
    .where(
      and(
        eq(orders.userId, user.id),
        eq(orders.productId, row.product.id),
        eq(orders.cycleKey, cycleKey),
        eq(orders.status, "pending"),
        gte(orders.createdAt, new Date(Date.now() - 30 * 60_000)),
      ),
    )
    .orderBy(desc(orders.createdAt))
    .limit(1);

  const settings = await getSettings();
  let payload: any;
  if (existing[0]) {
    payload = {
      order: existing[0],
      billing: resolveBilling(row.config, row.product, { billing_cycle: cycleKey, cycle: cycleKey, location, coupon }, settings),
      plan: { id: row.product.id, name: row.product.name, slug: row.product.slug },
      cycle: { key: cycleKey, label: cycleKey, price: "0" },
      methods: await enabledMethods(),
      requiresAccount: false,
      currencySymbol: settings.currencySymbol ?? "₹",
      taxLabel: settings.taxLabel ?? "Tax",
    };
  } else {
    const created = await createCheckout({
      userId: user.id,
      slug: row.product.slug,
      cycleKey,
      location,
      coupon: coupon || undefined,
      meta: { via: "internal_path", path: normalized },
    });
    payload = {
      order: created.order,
      billing: created.billing,
      plan: { id: created.plan.id, name: created.plan.name, slug: created.plan.slug },
      cycle: { key: created.cycle.key, label: created.cycle.label, price: created.cycle.price },
      methods: await enabledMethods(),
      requiresAccount: false,
      currencySymbol: settings.currencySymbol ?? "₹",
      taxLabel: settings.taxLabel ?? "Tax",
    };
  }

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Pricing", href: "/pricing" },
            { label: payload.plan.name, href: `/plans/${payload.plan.slug}` },
            { label: "Order" },
          ]}
        />
        <header className="border-line mt-4 mb-9 border-b pb-7">
          <div className="legend text-signal mb-4 flex flex-wrap items-center gap-3">
            <span>INTERNAL REDIRECT · {normalized}</span>
            <span className="bg-line-2 h-px w-8" />
            <span className="text-mute">CANONICAL DOMAIN: {settings.billing?.canonicalDomain || "CURRENT ORIGIN"}</span>
          </div>
          <h1 className="text-[clamp(1.9rem,4.4vw,3rem)] font-semibold">Order {payload.plan.name}</h1>
        </header>
        <CheckoutClient initial={payload} />
      </main>
      <Footer />
    </div>
  );
}
