import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { CheckoutClient } from "@/components/site/CheckoutClient";

export const dynamic = "force-dynamic";

export const metadata = { title: "Checkout" };

export default function CheckoutPage() {
  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Pricing", href: "/pricing" }, { label: "Checkout" }]} />
        <header className="border-line mt-4 mb-9 border-b pb-7">
          <div className="legend text-signal mb-4 flex items-center gap-3">
            <span>01 / SECURE CHECKOUT</span>
            <span className="bg-line-2 h-px w-8" />
            <span className="text-mute">SERVER-VERIFIED PRICING</span>
          </div>
          <h1 className="text-[clamp(2rem,4.6vw,3.2rem)] font-semibold">Complete your order</h1>
        </header>
        <CheckoutClient />
      </main>
      <Footer />
    </div>
  );
}
