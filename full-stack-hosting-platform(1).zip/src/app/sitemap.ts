import type { MetadataRoute } from "next";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_BASE_URL ?? "https://obsidiannode.io";
  const [cats, plans] = await Promise.all([
    db.select().from(categories).where(eq(categories.active, true)),
    db.select().from(products).where(eq(products.active, true)),
  ]);

  return [
    { url: base, changeFrequency: "daily", priority: 1 },
    { url: `${base}/hosting`, changeFrequency: "hourly", priority: 0.9 },
    { url: `${base}/services`, changeFrequency: "weekly", priority: 0.8 },
    ...cats.map((c) => ({ url: `${base}/hosting/${c.slug}`, changeFrequency: "weekly" as const, priority: 0.7 })),
    ...plans.map((p) => ({
      url: `${base}/plans/${p.slug}`,
      lastModified: p.updatedAt,
      changeFrequency: "daily" as const,
      priority: 0.8,
    })),
  ];
}
