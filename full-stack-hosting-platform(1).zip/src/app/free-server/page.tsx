import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { FreeServerConfigurator } from "@/components/site/FreeServerConfigurator";
import { getFreeServerSettings } from "@/lib/freeserver";
import { provisioningStatus } from "@/lib/provision";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Free server demo configurator",
  description:
    "Configure RAM, CPU, storage, runtime and software for a free demo hosting server, see the live price, and provision it in under a minute.",
};

export default async function FreeServerPage() {
  const [config, provisioning] = await Promise.all([getFreeServerSettings(), provisioningStatus()]);

  return (
    <div className="bg-void min-h-screen">
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Free server demo" }]} />

        <header className="border-line relative mt-4 mb-10 overflow-hidden border pb-10">
          {config.banner && (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={config.banner} alt="" className="absolute inset-0 h-full w-full object-cover opacity-25" />
              <div className="from-void via-void/85 absolute inset-0 bg-gradient-to-r to-void/40" />
            </>
          )}
          <div className="relative px-0 pt-8">
            <div className="legend text-signal mb-4 flex flex-wrap items-center gap-3">
              <span>FREE SERVER DEMO</span>
              <span className="bg-line-2 h-px w-8" />
              <span className="text-mute">
                {config.ram.freeMb >= 1024 ? `${config.ram.freeMb / 1024} GB` : `${config.ram.freeMb} MB`} RAM ·{" "}
                {config.disk.freeMb >= 1024 ? `${config.disk.freeMb / 1024} GB` : `${config.disk.freeMb} MB`} DISK ·{" "}
                {config.cpu.freePercent}% CPU INCLUDED
              </span>
            </div>
            <h1 className="text-[clamp(2.1rem,5vw,3.6rem)] font-semibold">{config.title}</h1>
            <p className="text-mute mt-4 max-w-2xl text-[15.5px]">{config.description}</p>
          </div>
        </header>

        <FreeServerConfigurator initialConfig={{ config, provisioning }} />
      </main>
      <Footer />
    </div>
  );
}
