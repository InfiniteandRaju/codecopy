import Link from "next/link";
import { notFound } from "next/navigation";
import { Nav } from "@/components/site/Nav";
import { Footer } from "@/components/site/Footer";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { PlanDetail } from "@/components/site/PlanDetail";
import { PlanUnit } from "@/components/site/PlanUnit";
import { getPlan, resolveBilling, getSettings, listPlans } from "@/lib/data";
import { money } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const plan = await getPlan(decodeURIComponent(slug)).catch(() => null);
  if (!plan) return { title: "Plan not found" };
  return {
    title: plan.seoTitle ?? plan.name,
    description: plan.seoDescription ?? plan.shortDescription ?? "",
    openGraph: { title: plan.name, description: plan.shortDescription ?? "", images: plan.image ? [plan.image] : undefined },
  };
}

export default async function PlanPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const plan = await getPlan(decodeURIComponent(slug));
  if (!plan || !plan.active || plan.archived) notFound();

  const settings = await getSettings();
  const symbol = settings.currencySymbol ?? "₹";
  const billing = resolveBilling(plan.billing, plan, {});
  const related = (await listPlans({ category: plan.category?.slug ?? "" })).filter((p: any) => p.id !== plan.id).slice(0, 3);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: plan.name,
    description: plan.shortDescription,
    category: plan.category?.name,
    offers: {
      "@type": "AggregateOffer",
      priceCurrency: plan.currency ?? "INR",
      lowPrice: plan.cycles.length ? Math.min(...plan.cycles.map((c: any) => Number(c.price))) : undefined,
      offerCount: plan.cycles.length,
      availability: "https://schema.org/InStock",
    },
    aggregateRating: plan.popularity > 200 ? { "@type": "AggregateRating", ratingValue: 4.9, reviewCount: plan.popularity } : undefined,
  };

  return (
    <div className="bg-void min-h-screen">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Nav />
      <main className="mx-auto max-w-[1440px] px-5 pt-28 pb-20 md:px-10 md:pt-32">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Pricing", href: "/pricing" },
            ...(plan.category
              ? [
                  { label: plan.category.name, href: `/hosting/${plan.category.slug}` },
                ]
              : []),
            { label: plan.name },
          ]}
        />

        {plan.image && (
          <div className="border-line relative mb-6 h-[200px] overflow-hidden border md:h-[280px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={plan.image} alt={`${plan.name}`} className="h-full w-full object-cover" />
            <div className="from-void absolute inset-0 bg-gradient-to-t via-transparent to-transparent" />
          </div>
        )}
        <header className="border-line mt-4 mb-10 border-b pb-9">
          <div className="legend text-signal mb-5 flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-2">
              <span
                className={`led led-pulse h-1.5 w-1.5 rounded-full ${
                  plan.bestSeller ? "bg-signal text-signal" : plan.featured ? "bg-link text-link" : "bg-led text-led"
                }`}
              />
              {plan.bestSeller ? "BEST SELLER" : plan.featured ? "FEATURED UNIT" : "AVAILABLE NOW"}
            </span>
            <span className="bg-line-2 h-px w-8" />
            <span className="text-mute">SKU {plan.slug.toUpperCase()}</span>
          </div>

          <div className="grid gap-8 lg:grid-cols-[1.4fr_auto] lg:items-end">
            <div>
              <h1 className="text-[clamp(2.2rem,5.6vw,4.2rem)] font-semibold tracking-[-0.04em]">{plan.name}</h1>
              <p className="text-mute mt-5 max-w-2xl text-[16px] leading-relaxed">{plan.shortDescription}</p>
            </div>
            <div className="flex items-end gap-3">
              <div className="text-right">
                <div className="legend text-mute">FROM</div>
                <div className="num text-chalk text-[2.4rem] leading-none font-semibold">
                  {symbol}
                  {plan.cycles.length
                    ? Math.round(
                        Math.min(...plan.cycles.map((c: any) => Number(c.price) / (c.months || 1))),
                      ).toLocaleString("en-IN")
                    : "—"}
                </div>
                <div className="legend text-mute mt-1">PER MONTH</div>
              </div>
            </div>
          </div>
        </header>

        <PlanDetail
          plan={plan}
          billing={billing}
          symbol={symbol}
          taxLabel={settings.taxLabel ?? "Tax"}
          taxRate={Number(settings.taxRate ?? 0)}
        />

        {related.length > 0 && (
          <section className="mt-20">
            <div className="mb-6 flex items-center gap-3">
              <span className="legend text-signal">RELATED UNITS</span>
              <span className="bg-line-2 h-px flex-1" />
              <Link href={`/hosting/${plan.category?.slug ?? ""}`} className="legend text-mute hover:text-signal transition-colors">
                VIEW CATEGORY
              </Link>
            </div>
            <div className="flex flex-col gap-4">
              {related.map((p: any, i: number) => (
                <PlanUnit key={p.id} plan={p} index={i} symbol={symbol} />
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer />
    </div>
  );
}
